/**
 * @author Andrew Davison 2007
 */

package lu.fisch.unimozer.compilation;

import java.util.Map;
import javax.tools.JavaFileObject;

public class ByteClassLoader extends ClassLoader
{
    // global
    private Map<String, JavaFileObject> store;

    public ByteClassLoader(Map<String, JavaFileObject> str)
    {
      super( ByteClassLoader.class.getClassLoader() );   // set parent
      store = str;
    }


    @Override
    protected Class<?> findClass(String name) throws ClassNotFoundException
    {
      JavaFileObject jfo = store.get(name);    // load java file object
      if (jfo == null)
        throw new ClassNotFoundException(name);

      byte[] bytes = ((ByteArrayJFO)jfo).getByteArray();
                                     // get byte codes array
      Class cl = defineClass(name, bytes, 0, bytes.length);
                                     // send byte codes to the JVM
      if (cl == null)
        throw new ClassNotFoundException(name);
      return cl;
    } // end of findClass()

}
