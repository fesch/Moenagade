/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lu.fisch.unimozer;

/**
 *
 * @author http://72.5.124.102/thread.jspa?threadID=5237460&messageID=9974737
 */
import java.awt.TextArea;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JTextArea;

/**
 * TextAreaReader allows you to read from the console through a reader object
 * useful in calling System.setIn
 */
public class TextAreaReader extends Reader implements KeyListener {

	JTextArea mJArea;
	TextArea mAWTArea;
	final Object mKeyLock = new Object();
	final Object mLineLock = new Object();
	String mLastLine;
	int mLastKeyCode = 1;

	public TextAreaReader(JTextArea area) {
		super();
		mJArea = area;
		mJArea.addKeyListener(this);
	}

	public TextAreaReader(TextArea area) {
		super();
		mAWTArea = area;
		mAWTArea.addKeyListener(this);
	}

	public void keyPressed(KeyEvent ke) {
		mLastKeyCode = ke.getKeyCode();
		synchronized(mKeyLock) {
			mKeyLock.notifyAll();
		}
		if (ke.getKeyCode() == KeyEvent.VK_ENTER) {
			if (mJArea != null) {
				String txt = mJArea.getText();
				int idx = txt.lastIndexOf('\n', mJArea.getCaretPosition() - 1);
				mLastLine = txt.substring(idx != -1 ? idx : 0, mJArea.getCaretPosition());//txt.length());
				synchronized(mLineLock) {
					mLineLock.notifyAll();
				}
			}
			else {
				String txt = mAWTArea.getText();
				int idx = txt.lastIndexOf('\n', mAWTArea.getCaretPosition() - 1);
				mLastLine = txt.substring(idx != -1 ? idx : 0, mAWTArea.getCaretPosition());//txt.length());
				synchronized(mLineLock) {
					mLineLock.notifyAll();
				}
			}
		}
	}

	public void keyReleased(KeyEvent ke) {

	}

	public void keyTyped(KeyEvent ke) {

	}

	public int read(char[] arg0, int arg1, int arg2) throws IOException {
		throw new IOException("Not supported");
	}

	public String readLine() {
		synchronized(mLineLock) {
			try {
				mLineLock.wait();
			}
			catch (InterruptedException ex)
                        {
			}
		}
		return mLastLine;
	}

        @Override
        public int read() {
		synchronized(mKeyLock) {
			try {
				mKeyLock.wait();
			}
			catch (InterruptedException ex)
                        {
			}
		}
		return mLastKeyCode;
	}

	public void close() throws IOException {
		// TODO Auto-generated method stub
	}

	public static void main(String args[]) {
		JFrame f = new JFrame("TextAreaInput Test");
		JTextArea area = new JTextArea();
		final TextAreaReader tar = new TextAreaReader(area);
		f.add(area);

		Runnable r1 = new Runnable() {
			public void run() {
				while (true) {
					int code = tar.read();
					System.out.println("read: " + code);
				}
			}
		};
		Runnable r2 = new Runnable() {
			public void run() {
				while (true) {
					String line = tar.readLine();
					System.out.println("read line: " + line);
				}
			}
		};
		Thread t1 = new Thread(r1);
		Thread t2 = new Thread(r2);
		t1.start();
		t2.start();
		f.setBounds(100, 100, 200, 200);
		f.setVisible(true);

	}

	public InputStream toInputStream() {
		return new MyInputStream();
	}

	private class MyInputStream extends InputStream
        {
		public int read()
                {
			return TextAreaReader.this.read();
		}
	}

}
