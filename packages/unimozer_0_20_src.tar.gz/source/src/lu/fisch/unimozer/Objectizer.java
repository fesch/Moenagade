/*
    Unimozer
    Unimozer intends to be a universal modelizer for Java™. It allows the user
    to draw UML diagrams and generates the relative Java™ code automatically
    and vice-versa.

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package lu.fisch.unimozer;

import bsh.EvalError;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JSeparator;
import lu.fisch.unimozer.dialogs.MethodInputs;

/**
 *
 * @author robertfisch
 */
public class Objectizer extends JPanel implements MouseListener, ActionListener, WindowListener
{
    private LinkedHashMap<String,MyObject> objects = new LinkedHashMap<String,MyObject>();
    private JPopupMenu popup = new JPopupMenu();
    private MyObject selected = null;
    private Diagram diagram = null;
    private Mainform frame = null;

    public Objectizer()
    {
        super();
        this.addMouseListener(this);
        this.addMouseListener(new PopupListener());
        this.add(popup);
    }


    public MyObject addObject(String objectName, Object object)
    {
        // if it is a JFrame
        if(object instanceof JFrame) 
        {
            // add this class as listener
            ((JFrame) object).addWindowListener(this);
            // set the name
            ((JFrame) object).setName(objectName);
        }
        MyObject myo = new MyObject(objectName,object);
        objects.put(objectName,myo);
        repaint();
        return myo;
    }

    public boolean hasObject(String name)
    {
        return objects.containsKey(name);
    }

    public void removeAllObjects()
    {
        Object [] keys = objects.keySet().toArray();
        for(int i=keys.length-1;i>=0;i--)
        {
            String key = (String) keys[i];
            MyObject myObj = objects.get(key);
            Object obj = myObj.getObject();
            String className = obj.getClass().getSimpleName();
            MyObject o = objects.get(key);
            o.cleanUp();
            objects.remove(key);
            o=null;
        }
        System.gc();
        System.gc();
        repaint();
    }

/*
 public void removeByClassName(MyClass mc)
    {
        String name = mc.getShortName();
        Object [] keys = objects.keySet().toArray();
        for(int i=keys.length-1;i>=0;i--)
        {
            String key = (String) keys[i];
            MyObject myObj = objects.get(key);
            Object obj = myObj.getObject();
            String className = obj.getClass().getSimpleName();
            if(className.equals(name)) 
            {
                MyObject o = objects.get(key);
                o.cleanUp();
                objects.remove(key);
                o=null;
            }
        }
        System.gc();
        System.gc();
        repaint();
    }
*/
    
    @Override
    public void paint(Graphics graphics)
    {
        super.paint(graphics);

        Graphics2D g = (Graphics2D) graphics;
        // set anti-aliasing rendering
        ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);

        // clear background
        g.setColor(Color.LIGHT_GRAY);
        g.fillRect(0,0,getWidth(),getHeight());
        g.setColor(Color.BLACK);
        
        int left = 8;
        Color color = new Color(255,100,100);

        Set<String> set = objects.keySet();
        Iterator<String> itr = set.iterator();
        while (itr.hasNext())
        {
          String objectName = itr.next();
          MyObject myObj = objects.get(objectName);
          Object obj = myObj.getObject();
          String className = obj.getClass().getSimpleName();

          int wo = (int) g.getFont().getStringBounds(objectName, g.getFontRenderContext()).getWidth();
          g.setFont(new Font(g.getFont().getName(),Font.BOLD,g.getFont().getSize()));
          int wc = (int) g.getFont().getStringBounds(className, g.getFontRenderContext()).getWidth();
          g.setFont(new Font(g.getFont().getName(),Font.PLAIN,g.getFont().getSize()));
          int width = Math.max(wo,wc)+2*8;

          myObj.setPosition(new Point(left,8));
          myObj.setWidth(width);
          myObj.setHeight(this.getHeight()-2*8);

          g.setColor(color);
          g.fillRoundRect(left, 8, width, this.getHeight()-2*8, 8,8);
          g.setColor(Color.BLACK);
          g.drawRoundRect(left, 8, width, this.getHeight()-2*8, 8,8);

          g.setColor(Color.BLACK);
          g.setFont(new Font(g.getFont().getName(),Font.BOLD,g.getFont().getSize()));
          g.drawString(className, left+(width-wc)/2, 4*8);
          g.setFont(new Font(g.getFont().getName(),Font.PLAIN,g.getFont().getSize()));
          g.drawString(objectName, left+(width-wo)/2, 6*8);

          left+=width+8;
        }

    }

    public void mouseClicked(MouseEvent e)
    {
    }

    private void fillPopup(JComponent popup, Class c, MyObject myObj)
    {
        Method m[] = c.getDeclaredMethods();
        for (int i = 0; i < m.length; i++)
        {
            String full = "";
            full+= m[i].getReturnType().getSimpleName();
            full+=" ";
            full+= m[i].getName();
            full+= "(";
            Type[] tvm = m[i].getParameterTypes();
            for(int t=0;t<tvm.length;t++)
            {
                String sn = tvm[t].toString();
                sn=sn.substring(sn.lastIndexOf('.')+1,sn.length());
                if(sn.startsWith("class")) sn=sn.substring(5).trim();
                // array is shown as ";"  ???
                if(sn.endsWith(";"))
                {
                    sn=sn.substring(0,sn.length()-1)+"[]";
                }                full+= sn+", ";
            }
            if(tvm.length>0) full=full.substring(0,full.length()-2);
            full+= ")";
            String backup = new String(full);
            String complete = new String(Modifier.toString(m[i].getModifiers())+" "+full);

            //if (base==true) System.err.println("Complete: "+complete);

            // get the real full name from the "MyObject" representation
            MyClass mc = diagram.getClass(c.getName());
            if(mc!=null)
            {
                complete = mc.getCompleteSignatureBySignature(full);
                full = mc.getFullSignatureBySignature(full);
                //if(myObj!=null) myObj.setMyClass(mc);
            }
            if(full.trim().equals("")) full=backup;

            //if((!complete.startsWith("private") || base==true)) // && (!complete.contains("static")))
            if(complete.startsWith("public")==true)
            {
                //System.err.println("Adding: "+complete);
                JMenuItem item = new JMenuItem(full);
                item.addActionListener(this);
                item.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_method.png")));
                popup.add(item);
            }
        }
    }

    private void fillPopupFields(JComponent popup, Class c, MyObject myObj)
    {
        Field m[] = c.getDeclaredFields();
        boolean found = false;
        for (int i = 0; i < m.length; i++)
        {
            if(!m[i].getType().isPrimitive() && Modifier.toString(m[i].getModifiers()).contains("public"))
            {
                String name = m[i].getType().getSimpleName()+" "+m[i].getName();
                JMenu item = new JMenu(name);
                item.addActionListener(this);
                item.setName("field");
                item.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_field.png")));
                popup.add(item);
                fillPopup(item, m[i].getType(), null);
                found=true;
            }
        }
        if (found==true)
        {
            JSeparator sep = new JSeparator();
            popup.add(sep);
        }
    }

    public void mousePressed(MouseEvent e)
    {
        selected=null;
        Set<String> set = objects.keySet();
        Iterator<String> itr = set.iterator();
        while (itr.hasNext())
        {
          String objectName = itr.next();
          MyObject myObj = objects.get(objectName);
          if(myObj.isInside(e.getPoint()))
          {
            Object obj = myObj.getObject();
            selected = myObj;
            //System.out.println("Sel "+selected.getName());
            try
            {
                popup.removeAll();

                Class c = obj.getClass();

                do
                {
                    c=c.getSuperclass();
                    if(c!=null)
                    {
                        JMenu item = new JMenu("inherited from "+c.getSimpleName());
                        item.setFont(new Font(item.getFont().getFontName(),
                                              Font.ITALIC,item.getFont().getSize()));
                        item.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_parent.png")));
                        popup.insert(item,0);

                        fillPopup(item, c, null);
                    }
                }
                while(c!=null);

                JSeparator sep = new JSeparator();
                popup.add(sep);

                fillPopupFields(popup, obj.getClass(), myObj);

                fillPopup(popup, obj.getClass(), myObj);

                sep = new JSeparator();
                popup.add(sep);

                JMenuItem item = new JMenuItem("Remove");
                item.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/gen_del.png")));
                item.addActionListener(this);
                popup.add(item);

            }
            catch (Throwable ee)
            {
                ee.printStackTrace();
            }
          }
        }
    }

    public void actionPerformed(ActionEvent e)
    {
        // get clicked JMenuItem
        JMenuItem sourceMenuItem = (JMenuItem) e.getSource();
        // get the JPopupMenu
        JPopupMenu sourcePopupMenu = (JPopupMenu) sourceMenuItem.getParent();
        // try to the the parent JMenu
        JMenu sourceMenu = null;
        if(sourcePopupMenu.getInvoker() instanceof JMenu) sourceMenu=(JMenu) sourcePopupMenu.getInvoker();
        // if there is a JMenu, get it's name
        String sourceName = "";
        if(sourceMenu!=null) sourceName=sourceMenu.getName();
        if(sourceName==null) sourceName="";
        // also get the text of the JMenu (if any)
        String sourceText = "";
        if(!sourceName.equals("")) sourceText=sourceMenu.getText();
        
        if(((JMenuItem) e.getSource()).getText().equals("Remove") && selected!=null)
        {
            objects.remove(selected.getName());
            selected.cleanUp();
            repaint();
        }
        // call a method on the object
        else if(selected!=null && !sourceName.equals("field"))
        {
            //System.out.println("Sel "+selected.getName());
            // get full signature
            String fullSign = ((JMenuItem) e.getSource()).getText();
            // get signature
            /*System.out.println(selected);
            System.out.println(selected.getMyClass());
            System.out.println(selected.getMyClass().getSignatureByFullSignature(fullSign));*/
            String sign = selected.getMyClass().getSignatureByFullSignature(fullSign);
            String complete = selected.getMyClass().getCompleteSignatureBySignature(sign);

            // find method
            Object obj = selected.getObject();
            Class c = obj.getClass();
            Method m[] = c.getMethods();
            for (int i = 0; i < m.length; i++)
            {
                String full = "";
                full+= m[i].getReturnType().getSimpleName();
                full+=" ";
                full+= m[i].getName();
                full+= "(";
                Class<?>[] tvm = m[i].getParameterTypes();
                LinkedHashMap<String,String> genericInputs = new LinkedHashMap<String,String>();
                for(int t=0;t<tvm.length;t++)
                {
                    String sn = tvm[t].toString();
                    genericInputs.put("param"+t,sn);
                    sn=sn.substring(sn.lastIndexOf('.')+1,sn.length());
                    if(sn.startsWith("class")) sn=sn.substring(5).trim();
                    // array is shown as ";"  ???
                    if(sn.endsWith(";"))
                    {
                        sn=sn.substring(0,sn.length()-1)+"[]";
                    }
                    full+= sn+", ";
                }
                if(tvm.length>0) full=full.substring(0,full.length()-2);
                full+= ")";
                /*
                System.out.println(sign);
                System.out.println(full);
                System.out.println(fullSign);
                 */

                if(full.equals(sign) || full.equals(fullSign))
                {
                    LinkedHashMap<String,String> inputs = selected.getMyClass().getInputsBySignature(sign);
                    if(inputs.size()!=genericInputs.size())
                    {
                        inputs=genericInputs;
                    }
                    MethodInputs mi = null;
                    boolean go = true;
                    if(inputs.size()>0) 
                    {
                        mi = new MethodInputs(frame,inputs,full,selected.getMyClass().getJavaDocBySignature(sign));
                        go = mi.OK;
                    }
                    if(go==true)
                    {
                        try
                        {
                            // generated the command to call
                            // objectname.methodname(
                            String method = selected.getName()+"."+m[i].getName()+"(";
                            if(inputs.size()>0) 
                            {
                                Object[] keys = inputs.keySet().toArray();
                                // add parameters
                                for(int in=0;in<keys.length;in++)
                                {
                                    String name = (String) keys[in];
                                    String val = mi.getValueFor(name);
                                    if (val.equals("")) val="null";
                                    method+=val+",";
                                }
                                // delete the last ","
                                method=method.substring(0, method.length()-1);
                            }
                            // close it
                            method+=")";

                            // Invoke method in a new thread
                            final String myMeth = method;
                            Runnable r = new Runnable()
                            {
                                    public void run()
                                    {
                                        try
                                        {
                                            Object retobj = Runtime.getInstance().executeMethod(myMeth);
                                            if(retobj!=null) JOptionPane.showMessageDialog(frame, retobj.toString(), "Result", JOptionPane.INFORMATION_MESSAGE,Unimozer.IMG_INFO);
                                        }
                                        catch (EvalError ex)
                                        {
                                            JOptionPane.showMessageDialog(frame, ex.toString(), "Invokation error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                                            ex.printStackTrace();
                                        }
                                    }
                            };
                            Thread t = new Thread(r);
                            t.start();

                            // get back the result as generic object
                            //Object retobj = Runtime.getInstance().executeMethod(method);
                            //if(retobj!=null) JOptionPane.showMessageDialog(frame, retobj.toString(), "Result", JOptionPane.INFORMATION_MESSAGE,Unimozer.IMG_INFO);
                        }
                        catch (Throwable ex)
                        {
                            JOptionPane.showMessageDialog(frame, ex.toString(), "Invokation error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                            ex.printStackTrace();
                        }
                    }
                }
             }
        }
        // call a method on a public field
        else if(selected!=null && sourceName.equals("field"))
        {
            try
            {
                // get the object name
                // the name does always contain a space
                String objectType = sourceText.substring(0, sourceText.indexOf(" ")).trim();
                String objectName = sourceText.substring(sourceText.indexOf(" ")).trim();
                // get full signature
                String fullSign = ((JMenuItem) e.getSource()).getText();
                // is it a class we have defined?
                MyClass objectMyClass = diagram.getClass(objectType);
                String sign = "";
                String complete = "";
                if(objectMyClass!=null)
                {
                    sign = objectMyClass.getSignatureByFullSignature(fullSign);
                    complete = objectMyClass.getCompleteSignatureBySignature(sign);
                }


                Class c = Runtime.getInstance().load(objectType);
                Method[] m = c.getMethods();
                for (int i = 0; i < m.length; i++)
                {
                    String full = "";
                    full+= m[i].getReturnType().getSimpleName();
                    full+=" ";
                    full+= m[i].getName();
                    full+= "(";
                    Class<?>[] tvm = m[i].getParameterTypes();
                    LinkedHashMap<String,String> genericInputs = new LinkedHashMap<String,String>();
                    for(int t=0;t<tvm.length;t++)
                    {
                        String sn = tvm[t].toString();
                        genericInputs.put("param"+t,sn);
                        sn=sn.substring(sn.lastIndexOf('.')+1,sn.length());
                        if(sn.startsWith("class")) sn=sn.substring(5).trim();
                        full+= sn+", ";
                    }
                    if(tvm.length>0) full=full.substring(0,full.length()-2);
                    full+= ")";

                    if(full.equals(sign) || full.equals(fullSign))
                    {
                        LinkedHashMap<String,String> inputs = new LinkedHashMap<String,String>();
                        if(objectMyClass!=null) objectMyClass.getInputsBySignature(sign);
                        if(inputs.size()!=genericInputs.size())
                        {
                            inputs=genericInputs;
                        }
                        MethodInputs mi = null;
                        boolean go = true;
                        if(inputs.size()>0)
                        {
                            mi = new MethodInputs(frame,inputs,full,objectMyClass.getJavaDocBySignature(sign));
                            go = mi.OK;
                        }
                        if(go==true)
                        {
                            try
                            {
                                // generated the command to call
                                // objectname.methodname(
                                String method = selected.getName()+"."+objectName+"."+m[i].getName()+"(";
                                if(inputs.size()>0)
                                {
                                    Object[] keys = inputs.keySet().toArray();
                                    // add parameters
                                    for(int in=0;in<keys.length;in++)
                                    {
                                        String name = (String) keys[in];
                                        method+=mi.getValueFor(name)+",";
                                    }
                                    // delete the last ","
                                    method=method.substring(0, method.length()-1);
                                }
                                // close it
                                method+=")";

                                // Invoke method in a new thread
                                final String myMeth = method;
                                Runnable r = new Runnable()
                                {
                                        public void run()
                                        {
                                            try
                                            {
                                                Object retobj = Runtime.getInstance().executeMethod(myMeth);
                                                if(retobj!=null) JOptionPane.showMessageDialog(frame, retobj.toString(), "Result", JOptionPane.INFORMATION_MESSAGE,Unimozer.IMG_INFO);
                                            }
                                            catch (EvalError ex)
                                            {
                                                JOptionPane.showMessageDialog(frame, ex.toString(), "Invokation error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                                                ex.printStackTrace();
                                            }
                                        }
                                };
                                Thread t = new Thread(r);
                                t.start();

                                // get back the result as generic object
                                //Object retobj = Runtime.getInstance().executeMethod(method);
                                //if(retobj!=null) JOptionPane.showMessageDialog(frame, retobj.toString(), "Result", JOptionPane.INFORMATION_MESSAGE,Unimozer.IMG_INFO);
                            }
                            catch (Throwable ex)
                            {
                                JOptionPane.showMessageDialog(frame, ex.toString(), "Invokation error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                                ex.printStackTrace();
                            }
                        }
                    }
                }
            }
            catch (ClassNotFoundException ex)
            {
                JOptionPane.showMessageDialog(frame, ex.toString(), "Invokation error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                ex.printStackTrace();
            }

        }
    }

    /**
     * @param diagram the diagram to set
     */
    public void setDiagram(Diagram diagram)
    {
        this.diagram = diagram;
    }

    /**
     * @param frame the frame to set
     */
    public void setFrame(Mainform frame)
    {
        this.frame = frame;
    }

    public void windowOpened(WindowEvent e)
    {
    }

    public void windowClosing(WindowEvent e)
    {
        if (((JFrame) e.getSource()).getDefaultCloseOperation()==JFrame.DISPOSE_ON_CLOSE)
        {
            objects.remove(((JFrame) e.getSource()).getName());
            repaint();
        }
    }

    public void windowClosed(WindowEvent e)
    {
    }

    public void windowIconified(WindowEvent e)
    {
    }

    public void windowDeiconified(WindowEvent e)
    {
    }

    public void windowActivated(WindowEvent e)
    {
    }

    public void windowDeactivated(WindowEvent e)
    {
    }

	// PopupListener Methods
	class PopupListener extends MouseAdapter
	{ 
        @Override
		public void mousePressed(MouseEvent e)
		{
			showPopup(e);
		}

        @Override
		public void mouseReleased(MouseEvent e)
		{
			showPopup(e);
		}

		private void showPopup(MouseEvent e)
		{
			if (e.isPopupTrigger())
			{
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		}
	}


    public void mouseReleased(MouseEvent e)
    {
    }

    public void mouseEntered(MouseEvent e)
    {
    }

    public void mouseExited(MouseEvent e)
    {
    }

}
