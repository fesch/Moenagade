/*
    Unimozer
    Unimozer intends to be a universal modelizer for Java™. It allows the user
    to draw UML diagrams and generates the relative Java™ code automatically
    and vice-versa.

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package lu.fisch.unimozer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import javax.swing.JLabel;
import javax.swing.JPanel;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rsyntaxtextarea.SyntaxConstants;
import org.fife.ui.rtextarea.RTextScrollPane;

/**
 *
 * @author robertfisch
 */
public class CodeEditor extends JPanel implements KeyListener, MouseMotionListener
{
    private RSyntaxTextArea codeArea;
    private long keyTimeout = 0;

    private Diagram diagram = null;
    private CodeCode code = new CodeCode();
    private JLabel status = null;



    public CodeEditor()
    {
        super();
        this.setLayout(new BorderLayout());
        codeArea = new RSyntaxTextArea();
        codeArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_JAVA);
        codeArea.addKeyListener(this);
        codeArea.addMouseMotionListener(this);
        codeArea.setEnabled(false);
        codeArea.setEditable(false);
        codeArea.setTabSize(4);

        

        //codeArea.setParser(new JavaParser());
        //codeArea.set

        RTextScrollPane sp = new RTextScrollPane(codeArea);


        //codeArea.setParser(org.fife.ui.rsyntaxtextarea.Parser));
        //codeArea.setMatchedBracketBGColor(new Color(196,196,0));
        
        this.add(sp);
    }



    public void setDiagram(Diagram diagram)
    {
        this.diagram=diagram;
    }

    @Override
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
        codeArea.setEnabled(b);
        codeArea.setEditable(b);
    }



    public void setCode(String code)
    {
        codeArea.setText(code);
        codeArea.setCaretPosition(0);
        setEnabled(true);
    }

    public void focusGained(FocusEvent e)
    {
        //System.out.println("Lost");
    }

    public void focusLost(FocusEvent e)
    {
    }

    public void keyTyped(KeyEvent e)
    {
    }

    public void keyPressed(KeyEvent e)
    {
    }

    public void keyReleased(KeyEvent e)
    {
        // this block is a bad work-around for the
        // problem that the autoindentation set the
        // caret to a non existing position
        if(e.getKeyCode() == KeyEvent.VK_ENTER)
        {
            //codeArea.convertTabsToSpaces();
        }

        if(diagram!=null)
        {
            MyClass mc = diagram.getSelectedClass();
            if(mc!=null)
            {
                //long isNow = Calendar.getInstance().getTimeInMillis();
                //if(isNow>keyTimeout+1000)
                //{
                    //mc.loadFromString(codeArea.getText());
                    getCode().setCode(codeArea.getText());
                    diagram.setEnabled(false);
                    status.setBackground(Color.ORANGE);
                    status.setText("Checking syntax ...");
                    diagram.updateFromCode();
                    //diagram.loadClassFromString(mc, codeArea.getText());
                    //diagram.clean(mc);
                    //diagram.repaint();
                    //keyTimeout = isNow;
                //}
            }
        }
    }

    public void mouseDragged(MouseEvent e)
    {

    }

    public void mouseMoved(MouseEvent e)
    {
        //keyReleased(null);
    }

    /**
     * @return the code
     */
    public CodeCode getCode()
    {
        return code;
    }

    /**
     * @return the status
     */
    public JLabel getStatus()
    {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(JLabel status)
    {
        this.status = status;
    }

}
