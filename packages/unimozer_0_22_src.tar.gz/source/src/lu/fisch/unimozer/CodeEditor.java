/*
/*
    Unimozer
    Unimozer intends to be a universal modelizer for Java™. It allows the user
    to draw UML diagrams and generates the relative Java™ code automatically
    and vice-versa.

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package lu.fisch.unimozer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.io.IOException;
import java.net.URL;
import javax.swing.Action;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.Document;
import javax.swing.text.EditorKit;
import lu.fisch.unimozer.compilation.CompilationError;
import lu.fisch.unimozer.dialogs.FindDialog;
import lu.fisch.unimozer.dialogs.ReplaceDialog;
import lu.fisch.unimozer.utils.StringList;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rsyntaxtextarea.SyntaxConstants;
import org.fife.ui.rtextarea.RTextScrollPane;

/**
 *
 * @author robertfisch
 */
public class CodeEditor extends JPanel implements KeyListener, MouseMotionListener, DocumentListener, Printable, ActionListener, HyperlinkListener
{
    private RSyntaxTextArea codeArea = null;
    private RTextScrollPane codeAreaScroll = null;
    /**/
    /*private JEditorPane codeArea = null;
    private JScrollPane codeAreaScroll = null;
    /**/

    private long keyTimeout = 0;

    private Diagram diagram = null;
    private Mainform frame = null;
    private CodeCode code = new CodeCode();
    private JLabel status = null;
    private JPanel topPanel = null;
    private JLabel myClassname = null;
    private JComboBox showWhat = null;
    private JEditorPane javaDoc = null;
    private JScrollPane javaDocScroll = null;

    public static Color DEFAULT_COLOR = Color.LIGHT_GRAY;

    private String lastFindText = null;
    private int lastFindPosition = -1;
    private boolean lastFindMatchCase = false;


    public CodeEditor()
    {
        super();
        this.setLayout(new BorderLayout());
        
        codeArea = new RSyntaxTextArea();
        codeArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_JAVA);
        codeArea.addKeyListener(this);
        codeArea.addMouseMotionListener(this);
        codeArea.setEnabled(false);
        codeArea.setEditable(false);
        codeArea.setTabSize(4);
        codeArea.getDocument().addDocumentListener(this);
        codeAreaScroll = new RTextScrollPane(codeArea);
        /**/
        /*
        codeArea = new JEditorPane();
        EditorKit kit = CloneableEditorSupport.getEditorKit("text/x-java");
        //codeArea.setEditorKit(kit);
        codeArea.addKeyListener(this);
        codeArea.addMouseMotionListener(this);
        codeArea.getDocument().addDocumentListener(this);

        codeAreaScroll = new JScrollPane(codeArea);
        /**/


        //codeArea.setParser(org.fife.ui.rsyntaxtextarea.Parser));
        //codeArea.setMatchedBracketBGColor(new Color(196,196,0));

        this.add(codeAreaScroll,BorderLayout.CENTER);

        // -- top panel --
        topPanel = new JPanel(new BorderLayout());
        topPanel.setPreferredSize(new Dimension(codeAreaScroll.getWidth(),24));
        topPanel.setBackground(Color.decode("#ffffaa"));

        myClassname = new JLabel();
        myClassname.setFont(new Font(myClassname.getFont().getFontName(),Font.BOLD,myClassname.getFont().getSize()));
        topPanel.add(myClassname,BorderLayout.WEST);

        showWhat = new JComboBox();
        showWhat.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Source Code","Documentation" }));
        showWhat.setEditable(false);
        showWhat.addActionListener(this);
        showWhat.setEnabled(false);
        topPanel.add(showWhat,BorderLayout.EAST);

        this.add(topPanel,BorderLayout.NORTH);

        javaDoc = new JTextPane();
        javaDoc.setContentType("text/html");
        javaDoc.setEditable(false);
        javaDoc.setVisible(true);
        javaDoc.addHyperlinkListener(this);

        javaDocScroll = new JScrollPane(javaDoc);
        javaDocScroll.setVisible(false);

    }

    public void setClassName(String classname)
    {
        if(!classname.trim().equals("")) myClassname.setText(" "+classname+".java");
        else myClassname.setText("");
    }

    public void setDiagram(Diagram diagram)
    {
        this.diagram=diagram;
    }

    @Override
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
        codeArea.setEnabled(b);
        codeArea.setEditable(b);

        showWhat.setEnabled(b);
        if(frame!=null) frame.setEnabledEditorActions(b);
    }



    public void setCode(String code)
    {
        if(showWhat.getSelectedIndex()!=0) showWhat.setSelectedIndex(0);
        codeArea.setText(code);
        codeArea.setCaretPosition(0);
        //CODE
        codeArea.discardAllEdits();
        if(status!=null)
        {
            status.setBackground(DEFAULT_COLOR);
            status.setText(" ");
        }
        setEnabled(true);
    }

    public void focusGained(FocusEvent e)
    {
        //System.out.println("Lost");
    }

    public void focusLost(FocusEvent e)
    {
    }

    public void keyTyped(KeyEvent e)
    {
    }

    public void keyPressed(KeyEvent e)
    {
    }

    public void keyReleased(KeyEvent e)
    {
        // catch copy, paste & cut envent (not handeled by the documentChange!
        if((e.getKeyChar()=='x' || e.getKeyChar()=='c' || e.getKeyChar()=='v') && (e.getModifiersEx()==KeyEvent.CTRL_DOWN_MASK || e.getModifiersEx()==KeyEvent.META_DOWN_MASK))
        {
            changedUpdate(null);
        }
        else if(diagram!=null)
        {
            MyClass mc = diagram.getSelectedClass();
            if(mc!=null)
            {
                mc.setContent(StringList.explode(codeArea.getText(),"\n"));
            }
        }
        /*
        // this block is a bad work-around for the
        // problem that the autoindentation set the
        // caret to a non existing position
        if(e.getKeyCode() == KeyEvent.VK_ENTER)
        {
            //codeArea.convertTabsToSpaces();
        }

        if(diagram!=null)
        {
            MyClass mc = diagram.getSelectedClass();
            if(mc!=null)
            {
                //long isNow = Calendar.getInstance().getTimeInMillis();
                //if(isNow>keyTimeout+1000)
                //{
                    //mc.loadFromString(codeArea.getText());

                    if (
                               (e.getKeyCode()!=KeyEvent.VK_ALT)
                               &&
                               (e.getKeyCode()!=KeyEvent.VK_ALT_GRAPH)
                               &&
                               (e.getKeyCode()!=KeyEvent.VK_CAPS_LOCK)
                               &&
                               (e.getKeyCode()!=KeyEvent.VK_DOWN)
                               &&
                               (e.getKeyCode()!=KeyEvent.VK_UP)
                               &&
                               (e.getKeyCode()!=KeyEvent.VK_LEFT)
                               &&
                               (e.getKeyCode()!=KeyEvent.VK_RIGHT)
                               &&

                       )
                    {

                    }
                    JOptionPane.showMessageDialog(null,e.getKeyCode());
                    // if we hit the "save" button, no change is done!
                
                    if(e.getModifiers()==Toolkit.getDefaultToolkit().getMenuShortcutKeyMask() && e.getKeyCode()==KeyEvent.VK_S)
                    {
                        //JOptionPane.showMessageDialog(null,"Ctrl-S");
                        //diagram.setChanged(false);
                    }
                    else // update from the code in any other situation
                    {
                        getCode().setCode(codeArea.getText());
                        diagram.setEnabled(false);
                        status.setBackground(Color.ORANGE);
                        status.setText("Checking syntax ...");
                        diagram.updateFromCode();
                    }
                    //diagram.loadClassFromString(mc, codeArea.getText());
                    //diagram.clean(mc);
                    //diagram.repaint();
                    //keyTimeout = isNow;
                //}
            }
        }
         /**/
    }

    public void mouseDragged(MouseEvent e)
    {

    }

    public void mouseMoved(MouseEvent e)
    {
        //keyReleased(null);
    }

    /**
     * @return the code
     */
    public CodeCode getCode()
    {
        return code;
    }

    /**
     * @return the status
     */
    public JLabel getStatus()
    {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(JLabel status)
    {
        this.status = status;
        if(status!=null)
        {
            DEFAULT_COLOR=status.getBackground();
        }
    }


    public void insertUpdate(DocumentEvent e)
    {
    }

    public void removeUpdate(DocumentEvent e)
    {
    }

    public void setCursorTo(String text)
    {
        if(codeArea.getText()!=null)
            if(codeArea.getText().indexOf(text)>=0) codeArea.setCaretPosition(codeArea.getText().indexOf(text));
    }

    public void changedUpdate(DocumentEvent e)
    {
        if(diagram!=null)
        {
            MyClass mc = diagram.getSelectedClass();
            if(mc!=null)
            {
                getCode().setCode(codeArea.getText());
                diagram.setEnabled(false);
                status.setBackground(Color.ORANGE);
                status.setText("Checking syntax ...");
                diagram.updateFromCode();
            }
        }
    }

    public int print(Graphics grphcs, PageFormat pf, int i) throws PrinterException
    {
        //return Printable.NO_SUCH_PAGE;
        // CODE
        return codeArea.print(grphcs, pf, i);
    }

    public void actionPerformed(ActionEvent ae)
    {
        if (showWhat.getSelectedIndex()==1 && !myClassname.getText().trim().equals("") && diagram.getSelectedClass()!=null)
        {
            if (!javaDocScroll.isVisible())
            if (Unimozer.javaDocDetected && diagram.getSelectedClass().isValidCode())
            {
                status.setBackground(DEFAULT_COLOR);

                this.remove(codeAreaScroll);
                this.remove(javaDocScroll);
                codeAreaScroll.setVisible(false);
                this.add(javaDocScroll,BorderLayout.CENTER);
                javaDoc.setText(" Loading ...");
                javaDocScroll.setVisible(true);

                /*
                javaDoc.setText("<html>Loading...</html>");
                javaDocScroll.invalidate();
                javaDocScroll.validate();
                javaDocScroll.repaint();
                String filename = diagram.getDirectoryName()+System.getProperty("file.separator")+"doc"+System.getProperty("file.separator")+myClassname.getText().trim().replaceAll(".java", ".html");
                try
                {
                    URL url = new URL("file:///" + filename);
                    javaDoc.setPage(url);
                    if (!javaDoc.getPage().equals(url))
                    {
                        javaDoc.getDocument().
                        putProperty(Document.StreamDescriptionProperty, url);
                    }
                }
                catch (IOException ex)
                {
                    ex.printStackTrace();
                }
                javaDocScroll.validate();
                javaDocScroll.repaint();
                */

                Runnable timeConsumingRunnable = new Runnable()
                {
                   public void run()
                   {
                      SwingUtilities.invokeLater(
                         new Runnable()
                         {
                            public void run()
                            {
                               status.setText("Generating documentation ...");
                            }
                         });

                      diagram.createJavaDoc();

                      SwingUtilities.invokeLater(
                         new Runnable()
                         {
                            public void run()
                            {
                                status.setText("Loading documentation ...");
                            }
                         });

                      SwingUtilities.invokeLater(
                         new Runnable()
                         {
                            public void run()
                            {
                                String filename = diagram.getDirectoryName()+System.getProperty("file.separator")+"doc"+System.getProperty("file.separator")+myClassname.getText().trim().replaceAll(".java", ".html");
                                try
                                {
                                    //filename=filename.replaceAll("\\"+System.getProperty("file.separator"), "\\/");
                                    String fullName = "file:///" + filename;
                                    //+ "?salt=" + Math.random();
                                    //fullName = fullName.replaceAll("\\ ","\\%20");
                                    //System.err.println("URL = "+fullName);

                                    Document doc = javaDoc.getDocument();
                                    doc.putProperty(Document.StreamDescriptionProperty, null);
                                    URL url = new URL(fullName);
                                    javaDoc.setPage(url);
                                    if (!javaDoc.getPage().equals(url)) javaDoc.getDocument().putProperty(Document.StreamDescriptionProperty, url);
                                }
                                catch (IOException ex)
                                {
                                    MyError.display(ex);
                                }
                                status.setText(" ");
                                status.repaint();
                            }
                         });
                    }
                };
                new Thread(timeConsumingRunnable).start();
            }
            else if(!diagram.getSelectedClass().isValidCode())
            {
                javaDoc.setText("<html><blockquote><h1>Error</h1><br>Your code contains error.<br>JavaDoc documentation cannot be generated!</blockquote></html>");
                javaDoc.repaint();

                this.remove(codeAreaScroll);
                this.remove(javaDocScroll);
                codeAreaScroll.setVisible(false);
                this.add(javaDocScroll,BorderLayout.CENTER);
                javaDocScroll.setVisible(true);
            }
            else if(myClassname.getText().trim().equals(""))
            {
                javaDoc.setText("<html><blockquote><h1>Error</h1><br>You need to select a class first.</blockquote></html>");
                javaDoc.repaint();

                this.remove(codeAreaScroll);
                this.remove(javaDocScroll);
                codeAreaScroll.setVisible(false);
                this.add(javaDocScroll,BorderLayout.CENTER);
                javaDocScroll.setVisible(true);
            }
            else
            {
                javaDoc.setText("<html><blockquote><h1>Sorry</h1><br>Unimozer was not able to detect a valid JDK installation,<br>so it can't create JavaDoc documentation.</blockquote></html>");
                javaDoc.repaint();

                this.remove(codeAreaScroll);
                this.remove(javaDocScroll);
                codeAreaScroll.setVisible(false);
                this.add(javaDocScroll,BorderLayout.CENTER);
                javaDocScroll.setVisible(true);
            }

            // this is a very bad and ugly tweak to make things drawing correctely!
            Container con = javaDocScroll.getParent();
            while(! (con instanceof JSplitPane)) con=con.getParent();
            ((JSplitPane) con).setDividerLocation(((JSplitPane) con).getDividerLocation());

            javaDocScroll.validate();
            javaDocScroll.repaint();
            javaDoc.repaint();
        }
        else if(!codeAreaScroll.isVisible())
        {
            this.remove(codeAreaScroll);
            this.remove(javaDocScroll);
            codeAreaScroll.setVisible(true);
            this.add(codeAreaScroll,BorderLayout.CENTER);
            javaDocScroll.setVisible(false);
            codeAreaScroll.setBounds(javaDocScroll.getBounds());
            codeAreaScroll.setPreferredSize(javaDocScroll.getPreferredSize());

            // this is a very bad and ugly tweak to make things drawing correctely!
            Container con = codeAreaScroll.getParent();
            while(! (con instanceof JSplitPane)) con=con.getParent();
            ((JSplitPane) con).setDividerLocation(((JSplitPane) con).getDividerLocation());

            codeAreaScroll.validate();
            codeAreaScroll.repaint();
            codeArea.repaint();
        }
    }

    public void hyperlinkUpdate(HyperlinkEvent e)
    {
        HyperlinkEvent.EventType type = e.getEventType();
        if (type == HyperlinkEvent.EventType.ENTERED)
        {
            status.setText(" "+e.getURL().toString());
        }
        else if (type == HyperlinkEvent.EventType.EXITED)
        {
            status.setText(" ");
        }
        else
        {
            ((JTextPane) javaDoc).setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            try
            {
                javaDoc.setPage(e.getURL());
            }
            catch (Exception ex)
            {

            }

        }
    }

    private Action getAction(String name)
    {
            Action action = null;
            Action[] actions = codeArea.getActions();

            for (int i = 0; i < actions.length; i++)
            {
                    if (name.equals( actions[i].getValue(Action.NAME).toString() ) )
                    {
                            action = actions[i];
                            break;
                    }
            }

            return action;
    }


    public void highlightError(CompilationError error)
    {
        String text = codeArea.getText();
        int countEOL = 0;
        int pos = 0;
        while(countEOL!=error.getLine())
        {
            if(text.charAt(pos)=='\n') countEOL++;
            pos++;
        }
        codeArea.setCaretPosition(pos-1);
    }

    private String escape(String expression)
    {
        String result = new String();

        for(int i=0;i<expression.length();i++)
        {
            switch(expression.charAt(i))
            {
                case '^':
                case '[':
                case '.':
                case '$':
                case '{':
                case '*':
                case '(':
                case '\\':
                case '+':
                case ')':
                case '|':
                case '?':
                case '<':
                case '>':
                            result=result+"\\";
                default:    result=result+expression.charAt(i);
            }
        }

        return result;
    }

    public void doReplace()
    {
        ReplaceDialog rd = ReplaceDialog.showModal(frame, "Replace");
        if(rd.OK==true)
        {
            String text = codeArea.getText();
            String what = rd.getWhat();
            String with = rd.getWith();

            int cpos = codeArea.getCaretPosition();


            if(!rd.getMatchCase()) text = text.replaceAll("(?i)"+escape(what), escape(with));
            else text = text.replaceAll(escape(what), escape(with));

            codeArea.setText(text);
            codeArea.setCaretPosition(cpos);

            changedUpdate(null);
        }
    }

    public void doFind()
    {
        FindDialog fd = FindDialog.showModal(frame, "Find");
        if(fd.OK==true)
        {
            String text = codeArea.getText();
            String what = fd.getTextToFind();
            if(!fd.getMatchCase())
            {
                text=text.toLowerCase();
                what=what.toLowerCase();
            }
            int pos = text.indexOf(what);

            if(pos>=0)
            {
                lastFindText = what;
                lastFindPosition = pos;
                lastFindMatchCase = fd.getMatchCase();

                codeArea.setCaretPosition(pos);
            }
        }
    }

    public void doFindAgain()
    {
        if(lastFindText!=null)
        {
            String text = codeArea.getText();
            String what = lastFindText;
            if(!lastFindMatchCase)
            {
                text=text.toLowerCase();
                what=what.toLowerCase();
            }
            int pos = text.indexOf(what,lastFindPosition+1);

            if(pos<0) pos = text.indexOf(what);

            if(pos>=0)
            {
                lastFindPosition = pos;

                codeArea.setCaretPosition(pos);
            }
        }
    }

    /**
     * @param frame the frame to set
     */
    public void setFrame(Mainform frame)
    {
        this.frame = frame;
    }


 }
