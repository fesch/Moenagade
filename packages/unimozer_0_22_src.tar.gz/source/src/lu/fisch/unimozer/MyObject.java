/*
    Unimozer
    Unimozer intends to be a universal modelizer for Java™. It allows the user
    to draw UML diagrams and generates the relative Java™ code automatically
    and vice-versa.

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package lu.fisch.unimozer;

import java.awt.Point;
import java.awt.Window;

/**
 *
 * @author robertfisch
 */
public class MyObject
{
    private Object object;
    private Point position;
    private int width;
    private int height;
    private String className;
    private MyClass myClass;

    public MyObject(String className, Object object)
    {
        //if(object==null) System.err.println("Setting "+className+" as null!");
        this.className=className;
        this.object=object;
    }

    public boolean isInside(Point pt)
    {
        return (position.x<=pt.x && pt.x<=position.x+getWidth() &&
                position.y<=pt.y && pt.y<=position.y+getHeight());
    }

    public void cleanUp()
    {
        // remove if the object is a Window
        if (object instanceof Window) ((Window) object).dispose();
        object = null;
        System.gc();
        System.gc();
    }

    /**
     * @return the object
     */
    public Object getObject()
    {
        return object;
    }

    /**
     * @param object the object to set
     */
    public void setObject(Object object)
    {
        this.object = object;
    }

    /**
     * @return the position
     */
    public Point getPosition()
    {
        return position;
    }

    /**
     * @param position the position to set
     */
    public void setPosition(Point position)
    {
        this.position = position;
    }

    /**
     * @return the width
     */
    public int getWidth()
    {
        return width;
    }

    /**
     * @param width the width to set
     */
    public void setWidth(int width)
    {
        this.width = width;
    }

    /**
     * @return the height
     */
    public int getHeight()
    {
        return height;
    }

    /**
     * @param height the height to set
     */
    public void setHeight(int height)
    {
        this.height = height;
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return className;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name)
    {
        this.className = name;
    }


    /**
     * @return the myClass
     */
    public MyClass getMyClass()
    {
        return myClass;
    }

    /**
     * @param myClass the myClass to set
     */
    public void setMyClass(MyClass myClass)
    {
        this.myClass = myClass;
    }

}
