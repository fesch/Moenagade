/*
    Unimozer
    Unimozer intends to be a universal modelizer for Java™. It allows the user
    to draw UML diagrams and generates the relative Java™ code automatically
    and vice-versa.

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package lu.fisch.unimozer;

import bsh.EvalError;
import japa.parser.ast.body.ConstructorDeclaration;
import japa.parser.ast.body.FieldDeclaration;
import japa.parser.ast.body.JavadocComment;
import japa.parser.ast.body.MethodDeclaration;
import japa.parser.ast.body.ModifierSet;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Properties;
import java.util.Set;
import java.util.Vector;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import lu.fisch.filefilter.PNGFilter;
import lu.fisch.structorizer.gui.PrintPreview;
import lu.fisch.unimozer.compilation.CompilationError;
import lu.fisch.unimozer.dialogs.BlueJPackageFile;
import lu.fisch.unimozer.dialogs.ClassEditor;
import lu.fisch.unimozer.dialogs.ConstructorEditor;
import lu.fisch.unimozer.dialogs.FieldEditor;
import lu.fisch.unimozer.dialogs.MethodEditor;
import lu.fisch.unimozer.dialogs.MethodInputs;
import lu.fisch.unimozer.dialogs.OpenFile;
import lu.fisch.unimozer.dialogs.OpenProject;
import lu.fisch.unimozer.dialogs.PackageFile;
import lu.fisch.unimozer.dialogs.PrintOptions;
import lu.fisch.unimozer.utils.StringList;
import net.iharder.dnd.FileDrop;
import org.codehaus.janino.CompileException;
import org.codehaus.janino.Parser.ParseException;
import org.codehaus.janino.Scanner.ScanException;

/**
 *
 * @author robertfisch
 */
public class Diagram extends JPanel implements MouseListener, MouseMotionListener, ActionListener, Printable
{
    private Hashtable<String,MyClass> classes = new Hashtable<String,MyClass>();
    private Point mousePoint = new Point(0,0);
    private Point mouseRelativePoint = new Point(0,0);
    private boolean mousePressed = false;
    private MyClass mouseClass = null;

    private Point commentPoint = null;
    private String commentString = null;

    private CodeEditor editor = null;
    private Mainform frame = null;
    private Objectizer objectizer = null;
    private Diagram diagram = this;
    private JLabel status = null;

    private JPopupMenu popup = new JPopupMenu();

    private String directoryName = null;
    private String containingDirectoryName = null;

    private CodeReader codeReader = null;

    private boolean showHeritage = true;
    private boolean showComposition = true;
    private boolean showAggregation = true;

    private boolean isUML = true;

    private final boolean allowEdit = false;
    private boolean hasChanged = true;

    private static final float dash[] = {5.0f, 2.0f};
    private static final BasicStroke dashed = new BasicStroke(1.0f, BasicStroke.CAP_BUTT,
                                                              BasicStroke.JOIN_MITER, 10.0f, dash, 0.0f);

    private lu.fisch.structorizer.gui.Mainform structorizer = null;
    private lu.fisch.structorizer.gui.Diagram nsd = null;

    private Vector<String> pageList = new Vector<String>();
    private PrintOptions printOptions = new PrintOptions();

    private int mostRight;
    private int mostBottom;

    public Diagram()
    {
        super();


        this.setLayout(new BorderLayout());
        this.addMouseListener(this);
        this.addMouseMotionListener(this);

        this.addMouseListener(new PopupListener());
        this.add(popup);

        // set the filedropper for the diagram
        new  FileDrop( this, new FileDrop.Listener()
        {
            public void  filesDropped( java.io.File[] files )
            {
                boolean found = false;
                for (int i = 0; i < files.length; i++)
                {
                    String filename = files[i].toString();
                    File f = new File(filename);
                    if(filename.substring(filename.length()-5, filename.length()).toLowerCase().equals(".java"))
                    {
                        try
                        {
                            //MyClass mc = new MyClass(new FileInputStream(filename));
                            MyClass mc = new MyClass(filename,Unimozer.FILE_ENCODING);
                            mc.setPosition(new Point(0, 0));
                            addClass(mc);
                            setChanged(true);
                        }
                        catch (Exception ex)
                        {
                            MyError.display(ex);
                        }
                    }
                    else if (f.isDirectory())
                    {
                        if((PackageFile.exists(f)==true) || (BlueJPackageFile.exists(f)==true) || (f.isDirectory()))
                        {
                            if(askToSave()==true) diagram.open(filename);
                        }
                    }
               }
               diagram.repaint();
               frame.setTitleNew();
            }
        });

    }

    private void drawExtends(Graphics2D g, Point pFrom, Point pTo)
    {
        int ARROW_SIZE = 16;
        double ARROW_ANGLE = Math.PI / 6;

        g.setColor(Color.BLACK);
        double angle = Math.atan2(-(pFrom.y - pTo.y), pFrom.x - pTo.x);

        Point pArrow = new Point(pTo.x + (int) ((ARROW_SIZE - 2) * Math.cos(angle)), pTo.y
                - (int) ((ARROW_SIZE - 2) * Math.sin(angle)));

        // draw the arrow head
        int[] xPoints = {pTo.x, pTo.x + (int) ((ARROW_SIZE) * Math.cos(angle + ARROW_ANGLE)),
                pTo.x + (int) (ARROW_SIZE * Math.cos(angle - ARROW_ANGLE))};
        int[] yPoints = {pTo.y, pTo.y - (int) ((ARROW_SIZE) * Math.sin(angle + ARROW_ANGLE)),
                pTo.y - (int) (ARROW_SIZE * Math.sin(angle - ARROW_ANGLE))};

        g.drawPolygon(xPoints, yPoints, 3);
        g.drawLine(pFrom.x, pFrom.y, pArrow.x, pArrow.y);
    }

    public Point2D getIntersection(Point2D p1, Point2D p2, Point2D p3, Point2D p4)
    {
        double x1 = p1.getX();
        double y1 = p1.getY();
        double x2 = p2.getX();
        double y2 = p2.getY();
        double x3 = p3.getX();
        double y3 = p3.getY();
        double x4 = p4.getX();
        double y4 = p4.getY();

        double xD1,yD1,xD2,yD2,xD3,yD3;
        double dot,deg,len1,len2;
        double segmentLen1,segmentLen2;
        double ua,ub,div;
        double xi,yi;

        // calculate differences
        xD1=p2.getX()-p1.getX();
        xD2=p4.getX()-p3.getX();
        yD1=p2.getY()-p1.getY();
        yD2=p4.getY()-p3.getY();
        xD3=p1.getX()-p3.getX();
        yD3=p1.getY()-p3.getY();

        // calculate the lengths of the two lines
        len1=Math.sqrt(xD1*xD1+yD1*yD1);
        len2=Math.sqrt(xD2*xD2+yD2*yD2);

        // calculate angle between the two lines.
        dot=(xD1*xD2+yD1*yD2); // dot product
        deg=dot/(len1*len2);

        // if abs(angle)==1 then the lines are parallell,
        // so no intersection is possible
        if(Math.abs(deg)==1) return null;

        div=yD2*xD1-xD2*yD1;
        ua=(xD2*yD3-yD2*xD3)/div;
        ub=(xD1*yD3-yD1*xD3)/div;

        xi = (p1.getX()+ua*xD1);
        yi = (p1.getY()+ua*yD1);
        Point2D pt = new Point2D.Double(xi,yi);

        // calculate the combined length of the two segments
        // between Pt-p1 and Pt-p2
        xD1=pt.getX()-p1.getX();
        xD2=pt.getX()-p2.getX();
        yD1=pt.getY()-p1.getY();
        yD2=pt.getY()-p2.getY();
        segmentLen1=Math.sqrt(xD1*xD1+yD1*yD1)+Math.sqrt(xD2*xD2+yD2*yD2);

        // calculate the combined length of the two segments
        // between Pt-p3 and Pt-p4
        xD1=pt.getX()-p3.getX();
        xD2=pt.getX()-p4.getX();
        yD1=pt.getY()-p3.getY();
        yD2=pt.getY()-p4.getY();
        segmentLen2=Math.sqrt(xD1*xD1+yD1*yD1)+Math.sqrt(xD2*xD2+yD2*yD2);


        // if the lengths of both sets of segments are the same as
        // the lenghts of the two lines the point is actually
        // on the line segment.
        // if the point isn't on the line, return null
        if(Math.abs(len1-segmentLen1)>0.01 || Math.abs(len2-segmentLen2)>0.01) return null;
        return pt;
    }

    private void drawLine(Graphics g, Point a, Point b)
    {
        g.drawLine(a.x, a.y, b.x, b.y);
    }

    private Point getCons(MyClass thisClass, MyClass otherClass, Hashtable<MyClass,Vector<MyClass>> classUsings)
    {
        int otherDIR, thisDIR, otherCON, thisCON;

        if(otherClass.getPosition().y+otherClass.getHeight()/2 < thisClass.getPosition().y+thisClass.getHeight()/2)
        { // top
            thisDIR = 1;
        }
        else
        { // bottom
            thisDIR = -1;
        }

        if(otherClass.getPosition().x+otherClass.getWidth()/2 < thisClass.getPosition().x+thisClass.getWidth()/2)
        { // left
            otherDIR = 1;
        }
        else
        { // right
            otherDIR = -1;
        }

        // create an empty list
        Vector<MyClass> otherUsers = new Vector<MyClass>();
        // iterate through all usages
        Set<MyClass> set = classUsings.keySet();
        Iterator<MyClass> itr = set.iterator();
        while (itr.hasNext())
        {
            // get the actual class ...
            MyClass actual = itr.next();
            // ... and the list of classes it uses
            Vector<MyClass> actualUses = classUsings.get(actual);
            // iterate through that list
            for(MyClass used : actualUses)
            {
                // add the actual class if
                // - it usesd the "otherClass"
                // - and the actual class has not yet been captured
                if(used==otherClass && !otherUsers.contains(actual)) otherUsers.add(actual);
            }
        }

        if (otherDIR==-1 && thisDIR==1) // Q1 (top-right)
        {
            Vector<MyClass> others = classUsings.get(thisClass);
            thisCON = 0;
            for(MyClass other : others)
            {
                if (
                    (other.getPosition().y+other.getHeight()/2 < thisClass.getPosition().y+thisClass.getHeight()/2)
                    &&
                    (other.getPosition().x+other.getWidth()/2 >= thisClass.getPosition().x+thisClass.getWidth()/2)
                    &&
                    (other.getPosition().y+other.getHeight()/2 < otherClass.getPosition().y+otherClass.getHeight()/2)
                   ) thisCON++;
            }
            thisCON*=12;

            // other Q3
            otherCON = 0;
            for(MyClass other : otherUsers)
            {
                if (
                    (other.getPosition().y+other.getHeight()/2 >= otherClass.getPosition().y+otherClass.getHeight()/2)
                    &&
                    (other.getPosition().x+other.getWidth()/2 < otherClass.getPosition().x+otherClass.getWidth()/2)
                    &&
                    (other.getPosition().x+other.getWidth()/2 < thisClass.getPosition().x+thisClass.getWidth()/2)
                   ) otherCON++;
            }
            otherCON*=12;
        }
        else if(otherDIR==1 && thisDIR==1) // Q2 (top-left)
        {
            Vector<MyClass> others = classUsings.get(thisClass);
            thisCON = 1;
            for(MyClass other : others)
            {
                if (
                    (other.getPosition().y+other.getHeight()/2 < thisClass.getPosition().y+thisClass.getHeight()/2)
                    &&
                    (other.getPosition().x+other.getWidth()/2 < thisClass.getPosition().x+thisClass.getWidth()/2)
                    &&
                    (other.getPosition().y+other.getHeight()/2 < otherClass.getPosition().y+otherClass.getHeight()/2)
                   ) thisCON++;
            }
            thisCON*=-12;

            // other Q4
            otherCON = 0;
            for(MyClass other : otherUsers)
            {
                if (
                    (other.getPosition().y+other.getHeight()/2 >= otherClass.getPosition().y+otherClass.getHeight()/2)
                    &&
                    (other.getPosition().x+other.getWidth()/2 >= otherClass.getPosition().x+otherClass.getWidth()/2)
                    &&
                    (other.getPosition().x+other.getWidth()/2 > thisClass.getPosition().x+thisClass.getWidth()/2)
                   ) otherCON++;
            }
            otherCON*=12;
        }
        else if(otherDIR==1 && thisDIR==-1) // Q3 (bottom-right)
        {
            Vector<MyClass> others = classUsings.get(thisClass);
            thisCON = 1;
            for(MyClass other : others)
            {
                if (
                    (other.getPosition().y+other.getHeight()/2 >= thisClass.getPosition().y+thisClass.getHeight()/2)
                    &&
                    (other.getPosition().x+other.getWidth()/2 < thisClass.getPosition().x+thisClass.getWidth()/2)
                    &&
                    (other.getPosition().y+other.getHeight()/2 > otherClass.getPosition().y+otherClass.getHeight()/2)
                   ) thisCON++;
            }
            thisCON*=-12;

            // other Q1
            otherCON = 1;
            for(MyClass other : otherUsers)
            {
                if (
                    (other.getPosition().y+other.getHeight()/2 < otherClass.getPosition().y+otherClass.getHeight()/2)
                    &&
                    (other.getPosition().x+other.getWidth()/2 >= otherClass.getPosition().x+otherClass.getWidth()/2)
                    &&
                    (other.getPosition().x+other.getWidth()/2 > thisClass.getPosition().x+thisClass.getWidth()/2)
                   ) otherCON++;
            }
            otherCON*=-12;
        }
        else // Q4 (bottom-right)
        {
            Vector<MyClass> others = classUsings.get(thisClass);
            thisCON = 0;
            for(MyClass other : others)
            {
                if (
                    (other.getPosition().y+other.getHeight()/2 >= thisClass.getPosition().y+thisClass.getHeight()/2)
                    &&
                    (other.getPosition().x+other.getWidth()/2 >= thisClass.getPosition().x+thisClass.getWidth()/2)
                    &&
                    (other.getPosition().y+other.getHeight()/2 > otherClass.getPosition().y+otherClass.getHeight()/2)
                   ) thisCON++;
            }
            thisCON*=12;

            // other Q2
            otherCON = 1;
            for(MyClass other : otherUsers)
            {
                if (
                    (other.getPosition().y+other.getHeight()/2 < otherClass.getPosition().y+otherClass.getHeight()/2)
                    &&
                    (other.getPosition().x+other.getWidth()/2 < otherClass.getPosition().x+otherClass.getWidth()/2)
                    &&
                    (other.getPosition().x+other.getWidth()/2 < thisClass.getPosition().x+thisClass.getWidth()/2)
                   ) otherCON++;
            }
            otherCON*=-12;
        }
        return new Point(thisCON, otherCON);
    }

    private void drawCompoAggregation(Graphics2D g, MyClass thisClass, MyClass otherClass, Hashtable<MyClass,Vector<MyClass>> classUsings,boolean isComposition)
    {
        Point start;
        Point stop;
        Point stopUp;
        Point stopDown;
        boolean inter =false;

        int destY;
        Point step;

        Point cons = getCons(thisClass, otherClass, classUsings);
        int thisCON = cons.x;
        int otherCON = cons.y;

        if(otherClass.getPosition().y+otherClass.getHeight()/2 < thisClass.getPosition().y+thisClass.getHeight()/2)
        { // top
            Polygon p = new Polygon();
            //thisCON = thisClass.getConnector().getNewTop(otherDIR);
            p.addPoint(thisCON+thisClass.getPosition().x+thisClass.getWidth()/2, thisClass.getPosition().y);
            p.addPoint(thisCON+thisClass.getPosition().x+thisClass.getWidth()/2-4, thisClass.getPosition().y-8);
            p.addPoint(thisCON+thisClass.getPosition().x+thisClass.getWidth()/2, thisClass.getPosition().y-16);
            p.addPoint(thisCON+thisClass.getPosition().x+thisClass.getWidth()/2+4, thisClass.getPosition().y-8);
            if(isComposition) g.fillPolygon(p);
            else g.drawPolygon(p);

            start = new Point(thisCON+thisClass.getPosition().x+thisClass.getWidth()/2,
                              thisClass.getPosition().y-16);
        }
        else
        { // bottom
            Polygon p = new Polygon();
            //thisCON = thisClass.getConnector().getNewBottom(otherDIR);
            p.addPoint(thisCON+thisClass.getPosition().x+thisClass.getWidth()/2, thisClass.getPosition().y+thisClass.getHeight());
            p.addPoint(thisCON+thisClass.getPosition().x+thisClass.getWidth()/2-4, thisClass.getPosition().y+thisClass.getHeight()+8);
            p.addPoint(thisCON+thisClass.getPosition().x+thisClass.getWidth()/2, thisClass.getPosition().y+thisClass.getHeight()+16);
            p.addPoint(thisCON+thisClass.getPosition().x+thisClass.getWidth()/2+4, thisClass.getPosition().y+thisClass.getHeight()+8);
            if(isComposition) g.fillPolygon(p);
            else g.drawPolygon(p);

            start = new Point(thisCON+thisClass.getPosition().x+thisClass.getWidth()/2,
                              thisClass.getPosition().y+thisClass.getHeight()+16);
        }

        Stroke oldStroke = g.getStroke();
        g.setStroke(dashed);

        if(otherClass.getPosition().x+otherClass.getWidth()/2 > thisClass.getPosition().x+thisClass.getWidth()/2)
        { // left
            //otherCON = otherClass.getConnector().getNewLeft(thisDIR);
            stop = new Point(otherClass.getPosition().x,
                              otherCON+otherClass.getPosition().y+otherClass.getHeight()/2);
            stopUp = new Point(otherClass.getPosition().x-8,
                              otherCON+otherClass.getPosition().y+otherClass.getHeight()/2-4);
            stopDown = new Point(otherClass.getPosition().x-8,
                              otherCON+otherClass.getPosition().y+otherClass.getHeight()/2+4);
            destY = otherCON+otherClass.getPosition().y+otherClass.getHeight()/2;
        }
        else
        { // right
            //otherCON = otherClass.getConnector().getNewRight(thisDIR);
            stop = new Point(otherClass.getPosition().x+otherClass.getWidth(),
                              otherCON+otherClass.getPosition().y+otherClass.getHeight()/2);
            stopUp = new Point(otherClass.getPosition().x+otherClass.getWidth()+8,
                              otherCON+otherClass.getPosition().y+otherClass.getHeight()/2-4);
            stopDown = new Point(otherClass.getPosition().x+otherClass.getWidth()+8,
                              otherCON+otherClass.getPosition().y+otherClass.getHeight()/2+4);
            destY = otherCON+otherClass.getPosition().y+otherClass.getHeight()/2;
        }

        if(otherClass.getPosition().y+otherClass.getHeight()/2 < thisClass.getPosition().y+thisClass.getHeight()/2)
        { // top
            if(destY>thisClass.getPosition().y-24)
            {
                step = new Point(thisCON+thisClass.getPosition().x+thisClass.getWidth()/2,
                                 thisClass.getPosition().y-24);
                inter = true;
            }
            else
            {
                step = new Point(thisCON+thisClass.getPosition().x+thisClass.getWidth()/2,destY);
            }
        }
        else
        { // bottom
            if(destY<thisClass.getPosition().y+thisClass.getHeight()+24)
            {
                step = new Point(thisCON+thisClass.getPosition().x+thisClass.getWidth()/2,
                                 thisClass.getPosition().y+thisClass.getHeight()+24);
                inter = true;
            }
            else
            {
                step = new Point(thisCON+thisClass.getPosition().x+thisClass.getWidth()/2,destY);
            }

        }


        drawLine(g,start,step);

        if(inter==true)
        {
            int middle;
            if(otherClass.getPosition().x+otherClass.getWidth()/2 > thisClass.getPosition().x+thisClass.getWidth()/2)
            { // left
                middle = (-(thisClass.getPosition().x+thisClass.getWidth())+(otherClass.getPosition().x))/2+thisClass.getPosition().x+thisClass.getWidth();
            }
            else
            { // right
                middle = (-(otherClass.getPosition().x+otherClass.getWidth())+(thisClass.getPosition().x))/2+otherClass.getPosition().x+otherClass.getWidth();
            }
            Point next = new Point(middle,step.y);
            drawLine(g,step,next);
            step = new Point(middle,stop.y);
            drawLine(g,step,next);
        }

        drawLine(g,step,stop);

        g.setStroke(oldStroke);
        drawLine(g,stopUp,stop);
        drawLine(g,stopDown,stop);
    }

    private void drawComposition(Graphics2D g, MyClass thisClass, MyClass otherClass, Hashtable<MyClass,Vector<MyClass>> classUsings)
    {
        drawCompoAggregation(g,thisClass,otherClass,classUsings,true);
    }

    private void drawAggregation(Graphics2D g, MyClass thisClass, MyClass otherClass, Hashtable<MyClass,Vector<MyClass>> classUsings)
    {
        drawCompoAggregation(g,thisClass,otherClass,classUsings,false);
    }

    @Override
    public void paint(Graphics graphics)
    {
            super.paint(graphics);
            Graphics2D g = (Graphics2D) graphics;
            // set anti-aliasing rendering
            ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);

            g.setFont(new Font(g.getFont().getFontName(),g.getFont().getStyle(),Unimozer.DRAW_FONT_SIZE));

            // clear background
            g.setColor(Color.WHITE);
            g.fillRect(0,0,getWidth()+1,getHeight()+1);
            g.setColor(Color.BLACK);

            Set<String> set;
            Iterator<String> itr;

            // draw classes
            /*
            set = classes.keySet();
            itr = set.iterator();
            while (itr.hasNext())
            {
              String str = itr.next();
              classes.get(str).draw(graphics);
            }/**/
            
            mostRight = 0;
            mostBottom = 0;

            set = classes.keySet();
            itr = set.iterator();
            while (itr.hasNext())
            {
              String str = itr.next();
              MyClass thisClass = classes.get(str);
            }

            // draw inheritance
            if(isShowHeritage())
            {
                itr = set.iterator();
                while (itr.hasNext())
                {
                  String str = itr.next();
                  MyClass thisClass = classes.get(str);

                  if(thisClass.getPosition().x+thisClass.getWidth()>mostRight) mostRight=thisClass.getPosition().x+thisClass.getWidth();
                  if(thisClass.getPosition().y+thisClass.getHeight()>mostBottom) mostBottom=thisClass.getPosition().y+thisClass.getHeight();

                  String extendsClass = thisClass.getExtendsClass();
                  if (!extendsClass.equals(""))
                  {
                    MyClass otherClass = classes.get(extendsClass);
                    if(otherClass!=null)
                    {
                        thisClass.setExtendsMyClass(otherClass);
                        // draw arrow from thisClass to otherClass

                        // get the center point of each class
                        Point fromP = new Point(thisClass.getPosition().x+thisClass.getWidth()/2,
                                                thisClass.getPosition().y+thisClass.getHeight()/2);
                        Point toP = new Point(otherClass.getPosition().x+otherClass.getWidth()/2,
                                              otherClass.getPosition().y+otherClass.getHeight()/2);

                        // get the corner 4 points of the desstination class
                        // (outer margin = 4)
                        Point toP1 = new Point(otherClass.getPosition().x-4,
                                              otherClass.getPosition().y-4);
                        Point toP2 = new Point(otherClass.getPosition().x+otherClass.getWidth()+4,
                                              otherClass.getPosition().y-4);
                        Point toP3 = new Point(otherClass.getPosition().x+otherClass.getWidth()+4,
                                              otherClass.getPosition().y+otherClass.getHeight()+4);
                        Point toP4 = new Point(otherClass.getPosition().x-4,
                                              otherClass.getPosition().y+otherClass.getHeight()+4);

                        // get the intersection with the center line an one of the
                        // sedis of the destination class
                        Point2D toDraw = getIntersection(fromP, toP, toP1, toP2);
                        if(toDraw==null) toDraw = getIntersection(fromP, toP, toP2, toP3);
                        if(toDraw==null) toDraw = getIntersection(fromP, toP, toP3, toP4);
                        if(toDraw==null) toDraw = getIntersection(fromP, toP, toP4, toP1);

                        // draw the arrowed line
                        if(toDraw!=null)
                            drawExtends((Graphics2D) graphics,fromP,new Point((int) toDraw.getX(),(int) toDraw.getY()));

                    }
                  }
                }
            }

            // setup a hastable to store the relations
            //Hashtable<String,StringList> classUsage = new Hashtable<String,StringList>();

            // store compositions
            Hashtable<MyClass,Vector<MyClass>> classCompositions = new Hashtable<MyClass,Vector<MyClass>>();
            // store aggregations
            Hashtable<MyClass,Vector<MyClass>> classAggregations= new Hashtable<MyClass,Vector<MyClass>>();
            // store all relations
            Hashtable<MyClass,Vector<MyClass>> classUsings = new Hashtable<MyClass,Vector<MyClass>>();

            // iterate through all classes to find compositions
            itr = set.iterator();
            while (itr.hasNext())
            {
              // get the actual classname
              String str = itr.next();
              // get the corresponding "MyClass" object
              MyClass thisClass = classes.get(str);
              // setup a list to store the relations with this class
              Vector<MyClass> theseCompositions = new Vector<MyClass>();

              // get all fileds of this class
              StringList uses = thisClass.getFieldTypes();
              for(int u = 0; u<uses.count(); u++)
              {
                // try to find the other (used) class
                MyClass otherClass = classes.get(uses.get(u));
                if(otherClass!=null) // means this class uses the other ones
                {
                    // add the other class to the list
                    theseCompositions.add(otherClass);
                }
              }

              // add the list of used classes to the MyClass object
              thisClass.setUsesMyClass(theseCompositions);
              // store the composition in the general list
              classCompositions.put(thisClass,theseCompositions);
              // store the compositions int eh global relation list
              classUsings.put(thisClass,new Vector<MyClass>(theseCompositions));
              //                        ^^^^^^^^^^^^^^^^^^^^
              //    important !! => create a new vector, otherwise the list
              //                    are the same ...
            }


            // iterate through all classes to find aggregations
            itr = set.iterator();
            while (itr.hasNext())
            {
              // get the actual class
              String str = itr.next();
              // get the corresponding "MyClass" object
              MyClass thisClass = classes.get(str);
              // we need a list to store the aggragations with this class
              Vector<MyClass> theseAggregations = new Vector<MyClass>();
              // try to get the list of compositions for this class
              // init if not present
              Vector<MyClass> theseCompositions = classCompositions.get(thisClass);
              if (theseCompositions==null) theseCompositions=new Vector<MyClass>();
              // try to get the list of all relations for this class
              // init if not present
              Vector<MyClass> theseClasses = classUsings.get(thisClass);
              if (theseClasses==null) theseClasses=new Vector<MyClass>();
              
              // get the names of the classes that thisclass uses
              StringList foundUsage = thisClass.getUsesWho();
              // go through the list an check to find a corresponding MyClass
              for(int f=0;f<foundUsage.count();f++)
              {
                  // get the name of the used class
                  String usedClass = foundUsage.get(f);

                  MyClass otherClass = classes.get(usedClass);
                  if(otherClass!=null && thisClass!=otherClass)
                  // meanint "otherClass" is a class used by thisClass
                  {
                        if(!theseCompositions.contains(otherClass)) theseAggregations.add(otherClass);
                        if(!theseClasses.contains(otherClass)) theseClasses.add(otherClass);
                  }
              }

              // store the relations to the class
              thisClass.setUsesMyClass(theseClasses);
              // store the aggregation to the global list
              classAggregations.put(thisClass, theseAggregations);
              // store all relations to the global list
              classUsings.put(thisClass, theseClasses);
            }


            if (isShowComposition() )
            {
                Set<MyClass> set2 = classCompositions.keySet();
                Iterator<MyClass> itr2 = set2.iterator();
                while (itr2.hasNext())
                {
                  MyClass thisClass = itr2.next();
                  Vector<MyClass> otherClasses = classCompositions.get(thisClass);
                  for(MyClass otherClass : otherClasses) drawComposition(g, thisClass, otherClass, classUsings);
                }
            }

            if (isShowAggregation())
            {
                Set<MyClass> set2 = classAggregations.keySet();
                Iterator<MyClass> itr2 = set2.iterator();
                while (itr2.hasNext())
                {
                  MyClass thisClass = itr2.next();
                  Vector<MyClass> otherClasses = classAggregations.get(thisClass);
                  for(MyClass otherClass : otherClasses) drawAggregation(g, thisClass, otherClass, classUsings);
                }
            }
            
            // draw classes again to put them on top
            // of the arrows
            set = classes.keySet();
            itr = set.iterator();
            while (itr.hasNext())
            {
              String str = itr.next();
              classes.get(str).draw(graphics);
            }

            // comments
            if(commentString!=null)
            {
                String fontName = g.getFont().getName();
                g.setFont(new Font("Courier",g.getFont().getStyle(),Unimozer.DRAW_FONT_SIZE));


                if(!commentString.trim().equals(""))
                {
                    String myCommentString = new String(commentString);
                    Point myCommentPoint = new Point(commentPoint);
                    //System.out.println(myCommentString);

                    // adjust comment
                    myCommentString=myCommentString.trim();
                    // adjust position
                    myCommentPoint.y=myCommentPoint.y+16;

                    // explode comment
                    StringList sl = StringList.explode(myCommentString,"\n");
                    // calculate totals
                    int totalHeight = 0;
                    int totalWidth = 0;
                    for(int i=0;i<sl.count();i++)
                    {
                        String line = sl.get(i).trim();
                        int h = (int) g.getFont().getStringBounds(line, g.getFontRenderContext()).getHeight();
                        int w = (int) g.getFont().getStringBounds(line, g.getFontRenderContext()).getWidth();
                        totalHeight+=h;
                        totalWidth=Math.max(totalWidth, w);
                    }


                    // get comment size
                    // draw background
                    g.setColor(new Color(255,255,128,255));
                    g.fillRoundRect(myCommentPoint.x, myCommentPoint.y,totalWidth+8,totalHeight+8,4,4);
                    // draw border
                    g.setColor(Color.BLACK);
                    g.drawRoundRect(myCommentPoint.x, myCommentPoint.y,totalWidth+8,totalHeight+8,4,4);

                    // draw text
                    totalHeight=0;
                    for(int i=0;i<sl.count();i++)
                    {
                        String line = sl.get(i).trim();
                        int h = (int) g.getFont().getStringBounds(myCommentString, g.getFontRenderContext()).getHeight();
                        g.drawString(line, myCommentPoint.x+4, myCommentPoint.y+h+2+totalHeight);
                        totalHeight+=h;
                    }

                }

                g.setFont(new Font(fontName,g.getFont().getStyle(),Unimozer.DRAW_FONT_SIZE));

            }

            if(!isEnabled())
            {
                g.setColor(new Color(128,128,128,128));
                g.fillRect(0,0,getWidth(),getHeight());

            }

            this.setPreferredSize(new Dimension(mostRight+32, mostBottom+32));
            // THE NEXT LINE MAKES ALL DIALOGUES DISAPEAR!!
            //this.setSize(mostRight+32, mostBottom+32);
            this.validate();
            ((JScrollPane)this.getParent().getParent()).revalidate();
    }

    public void addClass()
    {
        ClassEditor ce = ClassEditor.showModal(this.frame, "Add a new class", true);
        Ini.set("javaDocCClass", Boolean.toString(ce.genDoc()));
        Ini.set("mainClass", Boolean.toString(ce.genMain()));
        if (ce.OK==true)
        {
            MyClass mc = new MyClass(ce);
            mc.setExtendsClass(ce.getExtends());
            mc.setExtendsMyClass(this.getClass(ce.getExtends()));
            mc.setUML(isUML);

            /*
             * automatic code generation
             */

            // add "public static void mains (String[] args)
            MethodDeclaration md = null;
            if(ce.genMain())
            {
                Vector<String> param = new Vector<String>();
                param.add("String[]");
                param.add("args");
                Vector<Vector<String>> args = new Vector<Vector<String>>();
                args.add(param);
                //md=mc.addMethod("void", "main", ModifierSet.PUBLIC+ModifierSet.STATIC, args);
                mc.addMethod("void", "main", ModifierSet.PUBLIC+ModifierSet.STATIC, args,ce.genDoc());
            }
            // add JavaDOC Comments
            if(ce.genDoc())
            {
                mc.addClassJavaDoc();
                /*
                DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                java.util.Date date = new java.util.Date();
                String today = dateFormat.format(date);
                JavadocComment jdc = new JavadocComment(
                     "\n"+
                     " * Write a description of class “"+ce.getClassName()+"“ here."+"\n"+
                     " * "+"\n"+
                     " * @author     "+System.getProperty("user.name")+"\n"+
                     " * @version    "+today+"\n"+
                     " "
                );
                mc.getNode().setJavaDoc(jdc);
                if(ce.genMain() && (md!=null))
                {
                    jdc = new JavadocComment(
                         "\n"+
                         "     * The main entry point for executing this program."+"\n"+
                         "     "
                    );
                    md.setJavaDoc(jdc);
                }
                 */
            }
            mc.updateContent();

            this.addClass(mc);
            this.selectClass(mc);
            updateEditor();
            this.repaint();
            setChanged(true);
        }
    }

    public void addClass(MyClass myClass)
    {
        if(!classes.containsKey(myClass.getShortName()))
        {
            classes.put(myClass.getShortName(), myClass);
            setChanged(true);
            if(Unimozer.javaCompileOnTheFly)
            {
                new Thread(new Runnable() {

                    public void run()
                    {
                        diagram.compile(null);
                    }
                }).start();
            }
        }
        else
        {
            JOptionPane.showMessageDialog(frame, "Sorry, but you already have a class named “"+myClass.getShortName()+"“." , "Error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
        }
    }

    public MyClass getSelectedClass()
    {
        return mouseClass;
    }

    private MyClass getMouseClass(Point pt)
    {
        deselectAll();
        MyClass ret = null;
        Set<String> set = classes.keySet();
        Iterator<String> itr = set.iterator();
        while (itr.hasNext())
        {
          String str = itr.next();
          if (classes.get(str).isInside(pt))
          {
              ret=classes.get(str);
          }
        }
        if(ret!=null) ret.select(pt);
        repaint();
        return ret;
    }

    private MyClass getMouseClassNoSelect(Point pt)
    {
        MyClass ret = null;
        Set<String> set = classes.keySet();
        Iterator<String> itr = set.iterator();
        while (itr.hasNext())
        {
          String str = itr.next();
          if (classes.get(str).isInside(pt))
          {
              ret=classes.get(str);
          }
        }
        repaint();
        return ret;
    }

    private void deselectAll()
    {
        MyClass ret = null;
        Set<String> set = classes.keySet();
        Iterator<String> itr = set.iterator();
        while (itr.hasNext())
        {
          String str = itr.next();
          classes.get(str).deselect();
        }
    }

    public void selectClass(MyClass myClass)
    {
        deselectAll();
        if(myClass!=null)
        {
            myClass.select(null);
            mouseClass=myClass;
            if (editor!=null)
            {
                this.updateEditor();
                //editor.setCode(myClass.getJavaCode());
                codeReader = new CodeReader(diagram, mouseClass, editor.getCode());
            }
        }
        frame.setButtons(mouseClass!=null);
        repaint();
    }

    public Vector<MyClass> getChildClasses(String of)
    {
        Vector<MyClass> ret = new Vector<MyClass>();
        
        Set<String> set = classes.keySet();
        Iterator<String> itr = set.iterator();
        while (itr.hasNext())
        {
          String str = itr.next();
          MyClass mc = classes.get(str);
          if(mc.getExtendsClass()!=null)
          {
              if(mc.getExtendsClass().equals(of))
              {
                  ret.add(mc);
                  ret.addAll(getChildClasses(str));
              }
          }
          Vector<MyClass> uses = mc.getUsesMyClass();
          for(MyClass mac : uses)
          {
            if(mac.getShortName().equals(of))
            {
                ret.add(mc);
                ret.addAll(getChildClasses(str));
            }
          }
        }
        return ret;
    }

    public void updateEditor()
    {
        if (editor!=null)
        {
            if(mouseClass!=null)
            {
                if(allowEdit==true)
                {
                    // laod the code into the editor and enable it
                    editor.setClassName(mouseClass.getShortName());
                    editor.setCode(mouseClass.getJavaCode());
                    if(mouseClass.getSelected()!=null)
                    {
                        editor.setCursorTo(mouseClass.getSelected().getFullName());
                    }
                    //if(frame.showComments()) editor.setCode(mouseClass.getJavaCode());
                    //else editor.setCode(mouseClass.getJavaCodeCommentless());
                }
                else
                {
                    editor.setCode(mouseClass.getContent().getText());
                    editor.setClassName(mouseClass.getShortName());
                    if(mouseClass.getSelected()!=null)
                    {
                        editor.setCursorTo(mouseClass.getSelected().getFullName());
                    }
                }
                editor.setEnabled(true);
            }
            else
            { 
                cleanEditor();
            }
        } 
    }

    private void cleanEditor()
    {
        // clean the editor and dissable it
        if (editor!=null)
        {
            editor.setCode("");
            editor.setClassName("");
            editor.setEnabled(false);
        }
    }

    public void mouseClicked(MouseEvent e)
    {
        if(isEnabled())
        {
            mousePoint = e.getPoint();
            mousePressed = true;
            mouseClass = getMouseClass(mousePoint);
            //System.out.println(e.getButton());
            if(e.getClickCount()<=1 && e.getButton()==MouseEvent.BUTTON1)
            {
                if(mouseClass!=null)
                {
                    frame.setButtons(mouseClass.isValidCode());
                }
                updateEditor();
            }
            else if(e.getClickCount()==2  && e.getButton()==MouseEvent.BUTTON1 )
            {
                if(mouseClass!=null)
                {
                    Element ele = mouseClass.getSelected();
                    if (ele!=null && allowEdit==true)
                    {
                        if(ele.getType()==Element.CLASS)
                        {
                            ClassEditor cd = ClassEditor.showModal(frame, "Edit class", ele, mouseClass.getExtendsClass());
                            // remove the class from the hashtable
                            classes.remove(mouseClass.getShortName());
                            // update the class
                            mouseClass.update(ele, cd.getClassName(), cd.getModifier(), cd.getExtends());
                            mouseClass.setExtendsClass(cd.getExtends());
                            mouseClass.setExtendsMyClass(getClass(cd.getExtends()));
                            // add the class again to the hashtable
                            classes.put(mouseClass.getShortName(), mouseClass);
                            // set changed state
                            setChanged(true);
                        }
                        else if(ele.getType()==Element.METHOD)
                        {
                            MethodEditor md = MethodEditor.showModal(frame, "Edit method", ele);
                            mouseClass.update(ele, md.getMethodType(), md.getMethodName(), md.getModifier(), md.getParams());
                            // set changed state
                            setChanged(true);
                        }
                        else if(ele.getType()==Element.FIELD)
                        {
                            FieldEditor fd = FieldEditor.showModal(frame, "Edit field", ele);
                            mouseClass.update(ele, fd.getFieldType(), fd.getFieldName(), fd.getModifier());
                            // set changed state
                            setChanged(true);
                        }
                        else if(ele.getType()==Element.CONSTRUCTOR)
                        {
                            ConstructorEditor cd = ConstructorEditor.showModal(frame, "Edit constructor", ele);
                            mouseClass.update(ele, cd.getModifier(), cd.getParams());
                            // set changed state
                            setChanged(true);
                        }
                    }
                    repaint();
                    updateEditor();
                }
            }
            frame.setButtons(mouseClass!=null);
            if(mouseClass!=null) frame.setButtons(mouseClass.isValidCode());
         }
    }

    public void actionPerformed(ActionEvent e)
    {
        
        if(isEnabled())
        {
            if (e.getSource() instanceof JMenuItem)
            {
                JMenuItem item = (JMenuItem) e.getSource();
                if(item.getText().equals("Compile") && mouseClass!=null)
                {
                    compile(mouseClass);
                }
                else if(item.getText().equals("Remove") && mouseClass!=null)
                {
                    int answ = JOptionPane.showConfirmDialog(frame, "Are you shure to remove the class “"+mouseClass.getShortName()+"“", "Remove a class", JOptionPane.YES_NO_OPTION);
                    if (answ == JOptionPane.YES_OPTION)
                    {
                        cleanAll();// clean(mouseClass);
                        classes.remove(mouseClass.getShortName());
                        mouseClass=null;
                        updateEditor();
                        repaint();
                        objectizer.repaint();
                    }
                }
                else if(mouseClass.getName().contains("abstract"))
                {
                    JOptionPane.showMessageDialog(frame, "Can't create an object of an “abstract“ class ...", "Instatiation error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                }
                else if (item.getText().startsWith("new")) // we have constructor
                {
                    // get full signature
                    String fSign = item.getText();
                    if(fSign.startsWith("new")) fSign=fSign.substring(3).trim();
                    // get signature
                    final String fullSign = fSign;
                    final String sign = mouseClass.getSignatureByFullSignature(fullSign);


                    Runnable r = new Runnable()
                    {
                            public void run()
                            {
                                //System.out.println("Calling method (full): "+fullSign);
                                //System.out.println("Calling method       : "+sign);
                                try
                                {
                                    Class<?> cla = Runtime.getInstance().load(mouseClass.getShortName()); //mouseClass.load();
                                    Constructor[] constr = cla.getConstructors();
                                    for(int c = 0;c<constr.length;c++)
                                    {
                                        // get signature
                                        String full = constr[c].getName();
                                        full+="(";
                                        Class<?>[] tvm = constr[c].getParameterTypes();
                                        for(int t=0;t<tvm.length;t++)
                                        {
                                            String sn = tvm[t].toString();
                                            sn=sn.substring(sn.lastIndexOf('.')+1,sn.length());
                                            if(sn.startsWith("class")) sn=sn.substring(5).trim();
                                            // array is shown as ";"  ???
                                            if(sn.endsWith(";"))
                                            {
                                                sn=sn.substring(0,sn.length()-1)+"[]";
                                            }
                                            full+= sn+", ";
                                        }
                                        if(tvm.length>0) full=full.substring(0,full.length()-2);
                                        full+= ")";

                                        //System.out.println("Found: "+full);

                                        if(full.equals(sign) || full.equals(fullSign))
                                        {
                                            editor.setEnabled(false);
                                            String name;
                                            do
                                            {
                                                String propose = mouseClass.getShortName().substring(0, 1).toLowerCase()+mouseClass.getShortName().substring(1);
                                                int count = 0;
                                                String prop = propose+count;
                                                while(objectizer.hasObject(prop)==true)
                                                {
                                                    count++;
                                                    prop = propose+count;
                                                }

                                                name = (String) JOptionPane.showInputDialog(frame, "Please enter the name for you new instance of “"+mouseClass.getShortName()+"“", "Create object", JOptionPane.QUESTION_MESSAGE,null,null,prop);
                                                if (Java.isIdentifierOrNull(name)==false)
                                                {
                                                    JOptionPane.showMessageDialog(frame, "“"+name+"“ is not a correct identifier." , "Error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                                                }
                                                else if (objectizer.hasObject(name)==true)
                                                {
                                                    JOptionPane.showMessageDialog(frame, "An object with the name “"+name+"“ already exists.\nPlease choose another name ..." , "Error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                                                }
                                            } while (Java.isIdentifierOrNull(name)==false || objectizer.hasObject(name)==true);

                                            if(name!=null)
                                            {

                                                LinkedHashMap<String,String> inputs = mouseClass.getInputsBySignature(sign);
                                                MethodInputs mi = null;
                                                boolean go = true;
                                                if(inputs.size()>0)
                                                {
                                                    mi = new MethodInputs(frame,inputs,full,mouseClass.getJavaDocBySignature(sign));
                                                    go = mi.OK;
                                                }
                                                if(go==true)
                                                {
                                                    //Object arglist[] = new Object[inputs.size()];
                                                    String constructor = "new "+mouseClass.getShortName()+"(";
                                                    if(inputs.size()>0)
                                                    {
                                                        Object[] keys = inputs.keySet().toArray();
                                                        for(int in=0;in<keys.length;in++)
                                                        {
                                                            String kname = (String) keys[in];
                                                            //String type = inputs.get(kname);

                                                            //if(type.equals("int"))  { arglist[in] = Integer.valueOf(mi.getValueFor(kname)); }
                                                            //else if(type.equals("short"))  { arglist[in] = Short.valueOf(mi.getValueFor(kname)); }
                                                            //else if(type.equals("byte"))  { arglist[in] = Byte.valueOf(mi.getValueFor(kname)); }
                                                            //else if(type.equals("long"))  { arglist[in] = Long.valueOf(mi.getValueFor(kname)); }
                                                            //else if(type.equals("float"))  { arglist[in] = Float.valueOf(mi.getValueFor(kname)); }
                                                            //else if(type.equals("double"))  { arglist[in] = Double.valueOf(mi.getValueFor(kname)); }
                                                            //else if(type.equals("boolean"))  { arglist[in] = Boolean.valueOf(mi.getValueFor(kname)); }
                                                            //else arglist[in] = mi.getValueFor(kname);
                                                            constructor+=mi.getValueFor(kname)+",";
                                                        }
                                                        constructor=constructor.substring(0, constructor.length()-1);
                                                    }
                                                    //System.out.println(arglist);
                                                    constructor+=")";
                                                    //System.out.println(constructor);

                                                    Object obj = Runtime.getInstance().getInstance(name, constructor); //mouseClass.getInstance(name, constructor);
                                                    //System.out.println(obj.getClass().getSimpleName());
                                                    //Object obj = constr[c].newInstance(arglist);
                                                    MyObject myo = objectizer.addObject(name, obj);
                                                    myo.setMyClass(mouseClass);
                                                    obj = null;
                                                    cla = null;
                                                }

                                                objectizer.repaint();
                                                repaint();
                                            }
                                            editor.setEnabled(true);

                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    MyError.display(ex);
                                    JOptionPane.showMessageDialog(frame, ex.toString(), "Instantiation error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                                }
                            }
                    };
                    Thread t = new Thread(r);
                    t.start();


                }
                else // we have a static method
                {
                    try
                    {
                        // get full signature
                        String fullSign = ((JMenuItem) e.getSource()).getText();
                        // get signature
                        String sign = mouseClass.getSignatureByFullSignature(fullSign);
                        String complete = mouseClass.getCompleteSignatureBySignature(sign);

                        //System.out.println("Calling method (full): "+fullSign);
                        //System.out.println("Calling method       : "+sign);

                        // find method
                        Class c = Runtime.getInstance().load(mouseClass.getShortName());
                        Method m[] = c.getMethods();
                        for (int i = 0; i < m.length; i++)
                        {
                            String full = "";
                            full+= m[i].getReturnType().getSimpleName();
                            full+=" ";
                            full+= m[i].getName();
                            full+= "(";
                            Class<?>[] tvm = m[i].getParameterTypes();
                            LinkedHashMap<String,String> genericInputs = new LinkedHashMap<String,String>();
                            for(int t=0;t<tvm.length;t++)
                            {
                                String sn = tvm[t].toString();
                                genericInputs.put("param"+t,sn);
                                sn=sn.substring(sn.lastIndexOf('.')+1,sn.length());
                                if(sn.startsWith("class")) sn=sn.substring(5).trim();
                                // array is shown as ";"  ???
                                if(sn.endsWith(";"))
                                {
                                    sn=sn.substring(0,sn.length()-1)+"[]";
                                }
                                full+= sn+", ";
                            }
                            if(tvm.length>0) full=full.substring(0,full.length()-2);
                            full+= ")";

                            //System.out.println("Found: "+full);

                            if(full.equals(sign) || full.equals(fullSign))
                            {
                                LinkedHashMap<String,String> inputs = mouseClass.getInputsBySignature(sign);
                                if(inputs.size()!=genericInputs.size())
                                {
                                    inputs=genericInputs;
                                }
                                MethodInputs mi = null;
                                boolean go = true;
                                if(inputs.size()>0)
                                {
                                    mi = new MethodInputs(frame,inputs,full,mouseClass.getJavaDocBySignature(sign));
                                    go = mi.OK;
                                }
                                if(go==true)
                                {
                                    try
                                    {
                                        String method = mouseClass.getShortName()+"."+m[i].getName()+"(";
                                        if(inputs.size()>0)
                                        {
                                            Object[] keys = inputs.keySet().toArray();
                                            //int cc = 0;
                                            for(int in=0;in<keys.length;in++)
                                            {
                                                String name = (String) keys[in];
                                                String val = mi.getValueFor(name);
                                                if (val.equals("")) val="null";
                                                method+=val+",";
                                            }
                                            method=method.substring(0, method.length()-1);
                                        }
                                        method+=")";

                                        // Invoke method in a new thread
                                        final String myMeth = method;
                                        Runnable r = new Runnable()
                                        {
                                                public void run()
                                                {
                                                    try
                                                    {
                                                        Object retobj = Runtime.getInstance().executeMethod(myMeth);
                                                        if(retobj!=null) JOptionPane.showMessageDialog(frame, retobj.toString(), "Result", JOptionPane.INFORMATION_MESSAGE,Unimozer.IMG_INFO);
                                                    }
                                                    catch (EvalError ex)
                                                    {
                                                        JOptionPane.showMessageDialog(frame, ex.toString(), "Invokation error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                                                        MyError.display(ex);
                                                    }
                                                }
                                        };
                                        Thread t = new Thread(r);
                                        t.start();

                                        //System.out.println(method);
                                        //Object retobj = Runtime.getInstance().executeMethod(method);
                                        //if(retobj!=null) JOptionPane.showMessageDialog(frame, retobj.toString(), "Result", JOptionPane.INFORMATION_MESSAGE,Unimozer.IMG_INFO);
                                    }
                                    catch (Throwable ex)
                                    {
                                        JOptionPane.showMessageDialog(frame, ex.toString(), "Execution error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                                        MyError.display(ex);
                                    }
                                }
                            }
                        }
                    }
                    catch(Exception ex)
                    {
                        JOptionPane.showMessageDialog(frame, ex.toString(), "Execution error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                        MyError.display(ex);
                    }
                }
            }
        }
    }

    public void updateFromCode()
    {
        if(codeReader!=null) 
        {
            codeReader.doUpdate();
            setChanged(true);
        }
    }

    public void mousePressed(MouseEvent e)
    {
        if(isEnabled())
        {
            mousePoint = e.getPoint();
            mousePressed = true;
            mouseClass = getMouseClass(mousePoint);
            if (mouseClass!=null)
            {
                mouseRelativePoint = mouseClass.getRelative(mousePoint);
                codeReader = new CodeReader(diagram, mouseClass, editor.getCode());
                mouseClass.updateNSD(getNsd());
                frame.setButtons(mouseClass.isValidCode());
            }
        }
    }

    public void mouseReleased(MouseEvent e)
    {
        if(isEnabled())
        {
            if(mousePressed==true) mouseClicked(e);
            mousePressed = false;
            mouseClass = null;
        }
    }

    public void mouseEntered(MouseEvent e)
    {
    }

    public void mouseExited(MouseEvent e)
    {
    }

    public void mouseDragged(MouseEvent e)
    {
        if (mousePressed == true && isEnabled())
        {
            if(mouseClass!=null)
            {
                mouseClass.setPosition(new Point(e.getX()-mouseRelativePoint.x,
                                                 e.getY()-mouseRelativePoint.y));
                repaint();
            }
        }
    }

    public void mouseMoved(MouseEvent e)
    {
        if(isEnabled())
        {
            // reset
            commentString=null;
            commentPoint=null;
            // get position
            mousePoint = e.getPoint();
            MyClass mouseAtCursor = getMouseClassNoSelect(mousePoint);
            if(mouseAtCursor!=null)
            {
                Element ele = mouseAtCursor.getHover(mousePoint);
                if(ele!=null)
                {
                    if(ele.getJavaDoc()!=null)
                    {
                        commentString=ele.getJavaDoc();
                        commentPoint=mousePoint;
                    }
                }
            }
            repaint();
        }
    }

    public MyClass getClass(String className)
    {
        return classes.get(className);
    }

    /**
     * @return the editor
     */
    public CodeEditor getEditor()
    {
        return editor;
    }

    /**
     * @param editor the editor to set
     */
    public void setEditor(CodeEditor editor)
    {
        this.editor = editor;
    }

    /**
     * @param frame the frame to set
     */
    public void setFrame(Mainform frame)
    {
        this.frame = frame;
    }
    /*
    public void clean(MyClass mc)
    {
        if(objectizer!=null) objectizer.removeByClassName(mc);
        mc.setCompiled(false);
        Vector<MyClass> remThem = getChildClasses(mc.getShortName());
        for(MyClass myc : remThem)
        {
            if(objectizer!=null) objectizer.removeByClassName(myc);
            myc.setCompiled(false);
        }
    }
    */

    public void cleanAll()
    {
        // clean objectizer
        if(objectizer!=null) objectizer.removeAllObjects();
        // set all classes to be not compiled
        Set<String> set = classes.keySet();
        Iterator<String> itr = set.iterator();
        while (itr.hasNext())
        {
          String str = itr.next();
          classes.get(str).setCompiled(false);
        }
    }

    public void clear()
    {
        mouseClass = null;
        if(objectizer!=null) objectizer.removeAllObjects();
        if(nsd!=null)
        {
            nsd.root=MyClass.setErrorNSD();
            nsd.getParent().getParent().repaint();
        }
        /*
        Set<String> set = classes.keySet();
        Iterator<String> itr = set.iterator();
        while (itr.hasNext())
        {
          String str = itr.next();
          if(objectizer!=null)
          {
            objectizer.removeByClassName(classes.get(str));
          }
        }
        */
        classes.clear();
        directoryName=null;

        frame.setCompilationErrors(new Vector<CompilationError>());

        repaint();
        if(objectizer!=null) objectizer.repaint();
        updateEditor();
        setEnabled(true);
        setChanged(false);
    }

    public void about()
    {
        About a = new About();
        a.setLocationRelativeTo(frame);
        a.setVisible(true);
    }

    /**
     * @param objectizer the objectizer to set
     */
    public void setObjectizer(Objectizer objectizer)
    {
        this.objectizer = objectizer;
    }

    /**
     * @return the directoryName
     */
    public String getDirectoryName()
    {
        return directoryName;
    }

    /**
     * @return the directoryName
     */
    public String getContainingDirectoryName()
    {
        return containingDirectoryName;
    }

    /**
     * @param directoryName the directoryName to set
     */
    public void setDirectoryName(String directoryName)
    {
        this.directoryName = directoryName;

        String dir = new String(directoryName);
        if(dir.endsWith(System.getProperty("file.separator"))) dir=dir.substring(0,dir.length()-2);
        dir = dir.substring(0,dir.lastIndexOf(System.getProperty("file.separator")));
        setContainingDirectoryName(dir);
    }

    /**
     * @return the status
     */
    public JLabel getStatus()
    {
        return status;
    }

    @Override
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
        frame.setEnabledActions(b);
        if(mouseClass!=null) frame.setButtons(mouseClass.isValidCode());
        if(b==false) frame.setButtons(false);
        repaint();
    }

    /**
     * @param status the status to set
     */
    public void setStatus(JLabel status)
    {
        this.status = status;
    }

    /**
     * @return the showHeritage
     */
    public boolean isShowHeritage()
    {
        return showHeritage;
    }

    /**
     * @param showHeritage the showHeritage to set
     */
    public void setShowHeritage(boolean showHeritage)
    {
        this.showHeritage = showHeritage;
    }

    /**
     * @return the showComposition
     */
    public boolean isShowComposition()
    {
        return showComposition;
    }

    /**
     * @param showComposition the showComposition to set
     */
    public void setShowComposition(boolean showComposition)
    {
        this.showComposition = showComposition;
    }

    /**
     * @return the showAggregation
     */
    public boolean isShowAggregation()
    {
        return showAggregation;
    }

    /**
     * @param showAggregation the showAggregation to set
     */
    public void setShowAggregation(boolean showAggregation)
    {
        this.showAggregation = showAggregation;
    }

    /**
     * @return the allowEdit
     */
    public boolean isAllowEdit()
    {
        return allowEdit;
    }

    /**
     * @param allowEdit the allowEdit to set
     */
    /*
    public void setAllowEdit(boolean allowEdit)
    {
        this.allowEdit = allowEdit;
    }
     */

    /**
     * @return the structorizer
     */
    public lu.fisch.structorizer.gui.Mainform getStructorizer()
    {
        return structorizer;
    }

    /**
     * @param structorizer the structorizer to set
     */
    public void setStructorizer(lu.fisch.structorizer.gui.Mainform structorizer)
    {
        this.structorizer = structorizer;
    }

    /**
     * @return the nsd
     */
    public lu.fisch.structorizer.gui.Diagram getNsd()
    {
        return nsd;
    }

    /**
     * @param nsd the nsd to set
     */
    public void setNsd(lu.fisch.structorizer.gui.Diagram nsd)
    {
        this.nsd = nsd;
    }

    /**
     * @return the hasChanged
     */
    public boolean isChanged()
    {
        return hasChanged;
    }

    /**
     * @param hasChanged the hasChanged to set
     */
    public void setChanged(boolean hasChanged)
    {
        this.hasChanged = hasChanged;
        if(frame!=null) frame.setTitleNew();
    }

    /**
     * @return the isUML
     */
    public boolean isUML()
    {
        return isUML;
    }

    /**
     * @param isUML the isUML to set
     */
    public void setUML(boolean isUML)
    {

        this.isUML = isUML;
        
        // draw classes again to put them on top
        // of the arrows
        Set<String> set;
        Iterator<String> itr;
        set = classes.keySet();
        itr = set.iterator();
        while (itr.hasNext()) 
        {
          String str = itr.next();
          classes.get(str).setUML(isUML);
        }
    }

    /**
     * @param containingDirectoryName the containingDirectoryName to set
     */
    public void setContainingDirectoryName(String containingDirectoryName)
    {
        this.containingDirectoryName = containingDirectoryName;
    }

    public void printDiagram()
    {
        printOptions = PrintOptions.showModal(frame, "Print options");
        if(printOptions.OK==true)
        {
            this.deselectAll();
            this.cleanAll();
            this.repaint();

            PrintPreview pp = new PrintPreview(frame,this);
            pp.setLocation(Math.round((frame.getWidth()-pp.getWidth())/2+frame.getLocation().x),
                                       (frame.getHeight()-pp.getHeight())/2+frame.getLocation().y);
            pp.setVisible(true);
        }
    }

    private void printHeaderFooter(Graphics g, PageFormat pageFormat, int page, String className)
    {
        int origPage = page+1;

        // Add header
        g.setColor(Color.BLACK);
        int xOffset = (int)pageFormat.getImageableX();
        int yOffset = (int)pageFormat.getImageableY();
        g.drawLine(xOffset, yOffset+25, xOffset+(int)pageFormat.getImageableWidth(), yOffset+25);
        g.drawLine(xOffset,                                    yOffset+(int)pageFormat.getImageableHeight()-15,
                  xOffset+(int)pageFormat.getImageableWidth(), yOffset+(int)pageFormat.getImageableHeight()-15);
        g.setFont(new Font(Font.SANS_SERIF,Font.ITALIC,10));

        Graphics2D gg = (Graphics2D) g;
        String pageString = "Page "+origPage;
        int tw = (int) gg.getFont().getStringBounds(pageString,gg.getFontRenderContext()).getWidth();
        g.drawString(pageString, xOffset+(int)pageFormat.getImageableWidth()-tw, yOffset+(int)pageFormat.getImageableHeight()-5);

        if(directoryName!=null)
        {
            g.setFont(new Font(g.getFont().getFontName(),Font.ITALIC,10));
            String filename = directoryName;
            if(!className.equals("")) filename+=System.getProperty("file.separator")+className+".java";
            g.drawString(filename, xOffset, yOffset+20);
            File f = new File(filename);
            if(f.exists())
            {
                DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                java.util.Date date = new java.util.Date();
                date.setTime(f.lastModified());
                String myDate = dateFormat.format(date);
                int w = (int) gg.getFont().getStringBounds(myDate,gg.getFontRenderContext()).getWidth();
                g.drawString(myDate, xOffset+(int)pageFormat.getImageableWidth()-w, yOffset+20);
            }
        }
    }

    public int print(Graphics g, PageFormat pageFormat, int page) throws PrinterException
    {
                if(page==0)
                {
                    pageList.clear();
                    if(printOptions.printCode()==true)
                    {
                        Set<String> set = classes.keySet();
                        Iterator<String> itr = set.iterator();
                        while (itr.hasNext())
                        {
                          String str = itr.next();
                          MyClass thisClass = classes.get(str);
                          CodeEditor edit = new CodeEditor();

                          String code = "";
                          // get code, depending on JavaDoc filter
                          if(printOptions.printJavaDoc()) code=thisClass.getContent().getText();
                          else code=thisClass.getJavaCodeCommentless();

                          // filter double lines
                          if(printOptions.filterDoubleLines())
                          {
                            StringList sl = StringList.explode(code, "\n");
                            sl.removeDoubleEmptyLines();
                            code=sl.getText();
                          }

                          edit.setCode(code);

                          int p = 0;
                          BufferedImage img = new BufferedImage(1,1,BufferedImage.TYPE_INT_RGB );
                          while(edit.print(img.createGraphics(), pageFormat, p)==PAGE_EXISTS)
                          {
                            pageList.add(str);
                            p++;
                          }

                          edit.print(g, pageFormat, p);
                        }
                    }
                }

		if (page == 0 && printOptions.printDiagram()==true)
		{
                        Graphics2D g2d = (Graphics2D) g;

                        int yOffset = (int)pageFormat.getImageableY();

			g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

                        double sX = (pageFormat.getImageableWidth()-1)/getDiagramWidth();
                        double sY = (pageFormat.getImageableHeight()-1-60)/getDiagramHeight();
                        double sca = Math.min(sX,sY);
                        if (sca>1) {sca=1;}
                        g2d.translate(0, 30);
                        g2d.scale(sca,sca);

			paint(g2d);
                        
                        g2d.scale(1/sca,1/sca);
                        g2d.translate(0, -(30));
			g2d.translate(-pageFormat.getImageableX(), -pageFormat.getImageableY());
                        printHeaderFooter(g2d,pageFormat,page,new String());


                        // find out what class to print on what page

                        return (PAGE_EXISTS);
		}
		else
		{
                        int origPage = page;

                        if(printOptions.printDiagram()==true) page--;

                        if(page>=pageList.size() || printOptions.printCode()==false) return (NO_SUCH_PAGE);
                        else
                        {

                            String mc = pageList.get(page);
                            page--;
                            int p = 0;
                            while(page>=0)
                            {
                                if(pageList.get(page).equals(mc)) p++;
                                page--;
                            }
                            MyClass thisClass = classes.get(mc);
                            CodeEditor edit = new CodeEditor();
                            
                              String code = "";
                              // get code, depending on JavaDoc filter
                              if(printOptions.printJavaDoc()) code=thisClass.getContent().getText();
                              else code=thisClass.getJavaCodeCommentless();

                              // filter double lines
                              if(printOptions.filterDoubleLines())
                              {
                                StringList sl = StringList.explode(code, "\n");
                                sl.removeDoubleEmptyLines();
                                code=sl.getText();
                              }

                              edit.setCode(code);

                            edit.print(g, pageFormat, p);

                            printHeaderFooter(g,pageFormat,origPage,thisClass.getShortName());

                            return (PAGE_EXISTS);
                        }
		}
    }

    public boolean loadClassFromFile()
    {
        OpenFile op = new OpenFile(new File(getContainingDirectoryName()),false);
        int result = op.showOpenDialog(frame);
        if(result==OpenProject.APPROVE_OPTION)
        {
            try
            {
                String filename = op.getSelectedFile().getAbsolutePath().toString();
                MyClass mc = new MyClass(filename, Unimozer.FILE_ENCODING);
                mc.setPosition(new Point(0, 0));
                addClass(mc);
                setChanged(false);
                return true;
            }
            catch (FileNotFoundException ex)
            {
                MyError.display(ex);
            }
            catch (japa.parser.ParseException ex)
            {
                MyError.display(ex);
            }
            catch (IOException ex)
            {
                MyError.display(ex);
            }
            catch (URISyntaxException ex)
            {
                MyError.display(ex);
            }
            return false;
        } else return false;
  }

    private double getDiagramWidth()
    {
        return mostRight;
    }

    private double getDiagramHeight()
    {
        return mostBottom;
    }




	// PopupListener Methods
	class PopupListener extends MouseAdapter
	{
                @Override
		public void mousePressed(MouseEvent e)
		{
                        showPopup(e);
		}

                @Override
		public void mouseReleased(MouseEvent e)
		{
			showPopup(e);
		}

    private void fillPopup(JComponent popup, Class c)
    {
        Method m[] = c.getDeclaredMethods();
        boolean found = false;
        for (int i = 0; i < m.length; i++)
        {
            String full = "";
            full+= m[i].getReturnType().getSimpleName();
            full+=" ";
            full+= m[i].getName();
            full+= "(";
            Type[] tvm = m[i].getParameterTypes();
            for(int t=0;t<tvm.length;t++)
            {
                String sn = tvm[t].toString();
                sn=sn.substring(sn.lastIndexOf('.')+1,sn.length());
                if(sn.startsWith("class")) sn=sn.substring(5).trim();
                // array is shown as ";"  ???
                if(sn.endsWith(";"))
                {
                    sn=sn.substring(0,sn.length()-1)+"[]";
                }
                full+= sn+", ";
            }
            if(tvm.length>0) full=full.substring(0,full.length()-2);
            full+= ")";
            String backup = new String(full);
            String complete = new String(Modifier.toString(m[i].getModifiers())+" "+full);

            //if (base==true) System.err.println("Complete: "+complete);

            // get the real full name from the "MyObject" representation
            MyClass mc = diagram.getClass(c.getName());
            if(mc!=null)
            {
                complete = mc.getCompleteSignatureBySignature(full);
                full = mc.getFullSignatureBySignature(full);
            }
            if(full.trim().equals("")) full=backup;

            //System.err.println(c.getSimpleName()+" >> "+complete);
            //if((!complete.startsWith("private") || base==true)) // && (!complete.contains("static")))
            if(complete.startsWith("public")==true && complete.contains("static"))
            {
                //System.err.println("Adding: "+complete);
                found=true;
                JMenuItem item = new JMenuItem(full);
                item.addActionListener(diagram);
                item.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_method_static.png")));
                popup.add(item);
            }
        }

        // add separator if there is at leat one static method
        if (found==true)
        {
            JSeparator sep = new JSeparator();
            popup.add(sep);
        }
    }

    private void showPopup(MouseEvent e)
    {
        if(diagram.isEnabled())
        {
            mousePoint = e.getPoint();
            mousePressed = true;
            mouseClass = getMouseClass(mousePoint);
            //updateEditor;
            cleanEditor();
	    if (e.isPopupTrigger())
	    {
                // clear the popup menu
                popup.removeAll();
                // fill with what is needed
                if(mouseClass!=null)
                {
                    if(mouseClass.isCompiled())
                    {
                        try
                        {
                            // just make shure everthing _is_ right,
                            // so we compile the class (and all subclasses)
                            //mouseClass.compile();
                            // now load the class (and all subclasses)
                            //Class<?> cla = mouseClass.load();
                            Class<?> cla = Runtime.getInstance().load(mouseClass.getShortName());
                            Constructor[] constr = cla.getConstructors();
                            for(int c = 0;c<constr.length;c++)
                            {
                                // get signature
                                String full = constr[c].getName();
                                full+="(";
                                Class<?>[] tvm = constr[c].getParameterTypes();
                                for(int t=0;t<tvm.length;t++)
                                {
                                    String sn = tvm[t].toString();
                                    sn=sn.substring(sn.lastIndexOf('.')+1,sn.length());
                                    if(sn.startsWith("class")) sn=sn.substring(5).trim();
                                    // array is shown as ";"  ???
                                    if(sn.endsWith(";"))
                                    {
                                        sn=sn.substring(0,sn.length()-1)+"[]";
                                    }
                                    full+= sn+", ";
                                }
                                if(tvm.length>0) full=full.substring(0,full.length()-2);
                                full+= ")";
                                String backup = new String(full);
                                String complete = new String(full);

                                // get full signature
                                full = mouseClass.getFullSignatureBySignature(full);
                                complete = mouseClass.getCompleteSignatureBySignature(full);
                                if(full.trim().equals("")) full=backup;

                                if(!complete.startsWith("private") && !mouseClass.getName().contains("abstract"))
                                {
                                    JMenuItem item = new JMenuItem("new "+full);
                                    item.addActionListener(diagram);
                                    item.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_constructor.png")));
                                    popup.add(item);
                                }
                            }

                            // add separator if there is at least one constructor
                            if(constr.length>0)
                            {
                                JSeparator sep = new JSeparator();
                                popup.add(sep);
                            }

                            // add static methods
                            fillPopup(popup,(Class) cla);
                            
                            JMenuItem item = new JMenuItem("Remove");
                            item.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/gen_del.png")));
                            item.addActionListener(diagram);
                            popup.add(item);


                        }
                        catch (Exception ex)
                        {
                            MyError.display(ex);
                            repaint();
                            JOptionPane.showMessageDialog(frame, ex.toString(), "Class load error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                        }
                    }
                    else
                    {
                        JMenuItem item = new JMenuItem("Compile");
                        item.addActionListener(diagram);
                        item.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/gen_proc.png")));
                        popup.add(item);

                        JSeparator sep = new JSeparator();
                        popup.add(sep);

                        item = new JMenuItem("Remove");
                        item.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/gen_del.png")));
                        item.addActionListener(diagram);
                        popup.add(item);
                    }

                    // allowEdit &&
                    if(mouseClass.isValidCode())
                    {
                        JSeparator sep = new JSeparator();
                        popup.add(sep);

                        JMenuItem item = new JMenuItem("Add constructor ...");
                        item.addActionListener(
                                   new java.awt.event.ActionListener()
                                   {
                                        public void actionPerformed(java.awt.event.ActionEvent evt)
                                        {
                                            diagram.addConstructor();
                                        }
                                   }
                        );
                        item.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_constructor.png")));
                        popup.add(item);

                        item = new JMenuItem("Add method ...");
                        item.addActionListener(
                                   new java.awt.event.ActionListener()
                                   {
                                        public void actionPerformed(java.awt.event.ActionEvent evt)
                                        {
                                            diagram.addMethod();
                                        }
                                   }
                        );
                        item.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_method.png")));
                        popup.add(item);

                        item = new JMenuItem("Add field ...");
                        item.addActionListener(
                                   new java.awt.event.ActionListener()
                                   {
                                        public void actionPerformed(java.awt.event.ActionEvent evt)
                                        {
                                            diagram.addField();
                                        }
                                   }
                        );
                        item.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_field.png")));
                        popup.add(item);
                    }

                }
                else // click on the empty space
                {
                    JMenuItem item = new JMenuItem("Add class ...");
                    item.addActionListener(
                               new java.awt.event.ActionListener()
                               {
                                    public void actionPerformed(java.awt.event.ActionEvent evt)
                                    {
                                        diagram.addClass();
                                    } 
                               }
                    );
                    item.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_class.png")));
                    popup.add(item);
                }
                popup.show(e.getComponent(), e.getX(), e.getY());
			}
		}
	}
    }

    private StringList getSaveContent()
    {
        StringList content = new StringList();
        content.add((new Boolean(allowEdit)).toString());
        content.add((new Boolean(showHeritage)).toString());
        content.add((new Boolean(showComposition)).toString());
        content.add((new Boolean(showAggregation)).toString());

        Set<String> set = classes.keySet();
        Iterator<String> itr = set.iterator();
        while (itr.hasNext())
        {
          String str = itr.next();
          StringList line = new StringList();
          line.add(str);
          line.add(String.valueOf(classes.get(str).getPosition().x));
          line.add(String.valueOf(classes.get(str).getPosition().y));
          content.add(line.getCommaText());
        }

        return content;
    }

    private StringList getBlueJSaveContent()
    {
        StringList content = new StringList();
        content.add("#BlueJ package file");

        // dependency
        int dependencyCounter = 0;
        // composition
        Set<String> set = classes.keySet();
        Hashtable<String,StringList> classUsage = new Hashtable<String,StringList>();
        Iterator<String> itr = set.iterator();
        while (itr.hasNext())
        {
          String str = itr.next();
          MyClass thisClass = classes.get(str);
          Vector<MyClass> useWho = new Vector<MyClass>();
          StringList usesClassNames = new StringList();

          StringList uses = thisClass.getFieldTypes();
          for(int u = 0; u<uses.count(); u++)
          {
            MyClass otherClass = classes.get(uses.get(u));
            if(otherClass!=null) // means this class uses the other ones
            {
                useWho.add(otherClass);
                usesClassNames.add(otherClass.getShortName());

                dependencyCounter++;
                content.add("dependency"+dependencyCounter+".from="+thisClass.getShortName());
                content.add("dependency"+dependencyCounter+".to="+otherClass.getShortName());
                content.add("dependency"+dependencyCounter+".type=UsesDependency");
            }
          }
          thisClass.setUsesMyClass(useWho);
          classUsage.put(thisClass.getShortName(), usesClassNames);
        }
        // usage
        
        itr = set.iterator();
        while (itr.hasNext())
        {
          String str = itr.next();
          MyClass thisClass = classes.get(str);
          Vector<MyClass> useWho = new Vector<MyClass>();
          useWho.addAll(thisClass.getUsesMyClass());
          StringList usesClassNames = classUsage.get(thisClass.getShortName());

          StringList foundUsage = thisClass.getUsesWho();
          for(int f=0;f<foundUsage.count();f++)
          {
              String usage = foundUsage.get(f);
              if(!usesClassNames.contains(usage))
              {
                MyClass otherClass = getClass(usage);
                if(otherClass!=null) // menange "otherClass" is a class used by thisClass
                {
                    useWho.add(otherClass);
                    
                    dependencyCounter++;
                    content.add("dependency"+dependencyCounter+".from="+thisClass.getShortName());
                    content.add("dependency"+dependencyCounter+".to="+otherClass.getShortName());
                    content.add("dependency"+dependencyCounter+".type=UsesDependency");
                }
              }
          }
          thisClass.setUsesMyClass(useWho);
       }
       /**/

       content.add("package.editor.height=900");
       content.add("package.editor.width=700");
       content.add("package.editor.x=0");
       content.add("package.editor.y=0");
       content.add("package.numDependencies="+dependencyCounter);
       content.add("package.numTargets="+classes.size());
       content.add("package.showExtends=true");
       content.add("package.showUses=true");

       itr = set.iterator();
       int count = 0;
       while (itr.hasNext())
       {
           String str = itr.next();
           MyClass thisClass = classes.get(str);
           count++;
           String type = "ClassTarget";
           if (thisClass.getName().contains("abstract")) type = "AbstractTarget";
           content.add("target"+count+".editor.height=700");
           content.add("target"+count+".editor.width=400");
           content.add("target"+count+".editor.x=0");
           content.add("target"+count+".editor.y=0");
           content.add("target"+count+".height=50");
           content.add("target"+count+".name="+thisClass.getShortName());
           content.add("target"+count+".showInterface=false");
           content.add("target"+count+".type="+type);
           content.add("target"+count+".width=80");
           content.add("target"+count+".x="+thisClass.getPosition().x);
           content.add("target"+count+".y="+thisClass.getPosition().y);

       }

       return content;
    }

    private void saveFiles()
    {
        if(directoryName!=null)
        {
            Set<String> set = classes.keySet();
            Iterator<String> itr = set.iterator();
            while (itr.hasNext())
            {
                try
                {
                    String str = itr.next();
                    //System.out.println("Saving source ... "+classes.get(str).getShortName());
                    String code;
                    if(allowEdit==true) code = classes.get(str).getJavaCode();
                    else code = classes.get(str).getContent().getText();
                    String filename = directoryName + System.getProperty("file.separator") + classes.get(str).getShortName() + ".java";

                    FileOutputStream fos = new FileOutputStream(filename);
                    Writer out = new OutputStreamWriter(fos, Unimozer.FILE_ENCODING);
                    out.write(code);
                    out.close();

                    /*
                    File file = new File(filename);
                    FileWriter fStream = new FileWriter(file);
                    fStream.write(code);
                    fStream.close();
                    */
                    /*
                    BTextfile file = new BTextfile(filename);
                    file.rewrite();
                    file.write(code);
                    file.close();
                     * */
                }
                catch (IOException ex)
                {
                    System.err.println("Error while saving ...");
                    System.err.println(ex.getMessage());
                }
            }
        }
    }

    private void emptyDir()
    {
        File dir = new File(directoryName);
        if (!dir.exists())
        {
          //System.err.println(directoryName + " does not exist");
          return;
        }

        String[] info = dir.list();
        for (int i = 0; i < info.length; i++)
        {
          File n = new File(directoryName + File.separator + info[i]);
          if (!n.isFile()) continue;
          //System.err.println("removing " + n.getPath());
          //if (!n.delete()) System.err.println("Couldn't remove " + n.getPath());
        }
    }

    boolean save()
    {
        if(directoryName!=null)
        {
            emptyDir();
            //System.out.println("Saving package ...");
            // save the "package"
            String filename = directoryName+"/"+Unimozer.U_PACKAGENAME;
            StringList content = getSaveContent();
            content.saveToFile(filename);
            // save BlueJ Package
            filename = directoryName+"/"+Unimozer.B_PACKAGENAME;
            content = getBlueJSaveContent();
            content.saveToFile(filename);
            // save the java files
            saveFiles();
            return true;
        } //else System.out.println("Dirname is null???");
        else return saveWithAskingLocation();
    }

    public void loadClassFromString(MyClass mc, String code)
    {
        // remove the class from the hashtable
        classes.remove(mc.getShortName());
        // reload it from the new code
        //System.err.println(code);
        String ret = mc.loadFromString(code);
        // add it back to the hashtable
        classes.put(mc.getShortName(), mc);
        if(ret.equals(MyClass.NO_SYNTAX_ERRORS))
        {
            status.setBackground(new Color(135,255,135));
            this.setEnabled(true);
        }
        else
        {
            status.setBackground(new Color(255,135,135));
            this.setEnabled(true);
        }
        if(ret.length()>100) status.setText(ret.substring(0, 100).trim());
        else status.setText(ret);
        status.setToolTipText("<html><pre>"+ret+"</pre></html>");
    }

    private void doCompilationOnly(MyClass myClass) throws ClassNotFoundException
    {
        if(!classes.isEmpty())
        {
            // get the code for all classes
            Hashtable<String,String> codes = new Hashtable<String,String>();
            Set<String> set = classes.keySet();
            Iterator<String> itr = set.iterator();
            while (itr.hasNext())
            {
              String str = itr.next();
              MyClass mc = classes.get(str);

              //mc.getCodePositions(); // just to test it

              if(allowEdit)
              {
                  //System.err.println("---[ Using tree :\n"+mc.getJavaCode());
                  codes.put(mc.getShortName(), mc.getJavaCode());
              }
              else 
              {
                  //System.err.println("---[ Using content:\n"+mc.getContent().getText());
                  codes.put(mc.getShortName(), mc.getContent().getText());
              }
            }

            if(myClass==null) Runtime.getInstance().compileAndLoad(codes, null);
            else Runtime.getInstance().compileAndLoad(codes, myClass.getShortName());

            // set compiled flag
            set = classes.keySet();
            itr = set.iterator();
            while (itr.hasNext())
            {
              String str = itr.next();
              MyClass mc = classes.get(str);
              mc.setCompiled(true);
            }

            repaint();
        }
    }

    public void compile(MyClass myClass)
    {
        try
        {
            doCompilationOnly(myClass);
            frame.setCompilationErrors(new Vector<CompilationError>());
        }
        catch (Exception ex)
        {
            //ex.printStackTrace();
            String error = ex.toString();
            error=error.replaceAll("java\\.lang\\.ClassNotFoundException:", "");

            // split up the error messags
            Vector<CompilationError> errors = new Vector<CompilationError>();
            StringList sl = StringList.explode(error.trim(),"\n");
            for(int i=0;i<sl.count();i++)
            {
                // we only need each third line
                if(i%3==0)
                {
                    StringList msl = StringList.explode(sl.get(i).trim(), ":");
                    errors.add(new CompilationError(
                                msl.get(0).trim(),
                                Integer.valueOf(msl.get(1).trim()),
                                msl.get(2).trim()
                            ));
                }
            }
            frame.setCompilationErrors(errors);

            //JOptionPane.showMessageDialog(frame, error.trim(), "Compilation error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
        }

    }

    public void make()
    {
        makeInteractive(true,null,true);
        // now recompile everthing as well!
        compile(null);
    }

    public boolean makeInteractive(boolean showMessages, String target, boolean compile)
    {

        try
        {
            // first we need to compile all classes
            // to make shure there are no more errors

            if(compile) doCompilationOnly(null);

            // repaint the diagram
            repaint();

            // for now, we need to save the project
            if (save())
            {

                // next we can do and create the class files

                // create emtpy array
                File[] files = new File[classes.size()];
                // control dirname
                String dirname = getDirectoryName();
                if (!dirname.endsWith("/"))
                {
                    dirname += "/";
                }
                // make the "bin" directory
                File binDir = new File(dirname+"bin/");
                binDir.mkdir();
                // add the files to the array
                Set<String> set = classes.keySet();
                Iterator<String> itr = set.iterator();
                int i = 0;
                while (itr.hasNext())
                {
                    String classname = itr.next();
                    files[i] = new File(dirname + classname + ".java");
                    i++;
                }
                try
                {
                    Runtime.getInstance().compileToPath(files, dirname+"bin/", target);
                    if(showMessages) JOptionPane.showMessageDialog(frame, "All CLASS-files have been generated ...", "Success", JOptionPane.INFORMATION_MESSAGE,Unimozer.IMG_INFO);
                    return true;
                }
                catch (IOException ex)
                {
                    JOptionPane.showMessageDialog(frame, "There was an error during the make process ...", "Compilation error :: IOException", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                    return false;
                }
                catch (ScanException ex)
                {
                    JOptionPane.showMessageDialog(frame, "There was an error during the make process ...", "Compilation error :: ScanException", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                    return false;
                }
                catch (ParseException ex)
                {
                    JOptionPane.showMessageDialog(frame, "There was an error during the make process ...", "Compilation error :: ParseException", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                    return false;
                }
                catch (CompileException ex)
                {
                    JOptionPane.showMessageDialog(frame, "There was an error during the make process ...", "Compilation error :: CompileException", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                    return false;
                }
                catch (ClassNotFoundException ex)
                {
                    JOptionPane.showMessageDialog(frame, "There was an error during the make process ...", "Compilation error :: ClassNotFoundException", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                    return false;
                }
            }
            else return false;
        }
        catch (ClassNotFoundException ex)
        {
            JOptionPane.showMessageDialog(frame, "The creation of the CLASS-files failed because\nyour project contains some errors.\nPlease correct them and try again ...", "Compilation error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);

            String error = ex.toString();
            error=error.replaceAll("java\\.lang\\.ClassNotFoundException:", "");
            JOptionPane.showMessageDialog(frame, error.trim(), "Compilation error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
            return false;
        }
    }

    public void run()
    {
        try
        {
            // compile all
            doCompilationOnly(null);

            Vector<String> mains = getMains();
            String runnable = null;
            if(mains.size()==0)
            {
                JOptionPane.showMessageDialog(
                    frame,
                    "Sorry, but your project does not contain any runnable public class ...",
                    "Error",
                    JOptionPane.ERROR_MESSAGE,
                    Unimozer.IMG_ERROR
                );
            }
            else 
            {

                if(mains.size()==1)
                {
                    runnable = mains.get(0);
                }
                else
                {
                    String[] classNames = new String[mains.size()];
                    for(int c=0;c<mains.size();c++) classNames[c]=mains.get(c);
                    runnable = (String) JOptionPane.showInputDialog(
                                       frame,
                                       "Unimozer detected more than one runnable class.\n"
                                       +"Please select which one you want to run.",
                                       "Run",
                                       JOptionPane.QUESTION_MESSAGE,
                                       Unimozer.IMG_QUESTION,
                                       classNames,
                                       "");
                }

                // we know now what to run
                MyClass runnClass = classes.get(runnable);

                // set full signature
                String fullSign = "void main(String[] args)";
                // get signature
                String sign = runnClass.getSignatureByFullSignature(fullSign);
                String complete = runnClass.getCompleteSignatureBySignature(sign);

                //System.out.println("Calling method (full): "+fullSign);
                //System.out.println("Calling method       : "+sign);

                // find method
                Class c = Runtime.getInstance().load(runnClass.getShortName());
                Method m[] = c.getMethods();
                for (int i = 0; i < m.length; i++)
                {
                    String full = "";
                    full+= m[i].getReturnType().getSimpleName();
                    full+=" ";
                    full+= m[i].getName();
                    full+= "(";
                    Class<?>[] tvm = m[i].getParameterTypes();
                    LinkedHashMap<String,String> genericInputs = new LinkedHashMap<String,String>();
                    for(int t=0;t<tvm.length;t++)
                    {
                        String sn = tvm[t].toString();
                        genericInputs.put("param"+t,sn);
                        sn=sn.substring(sn.lastIndexOf('.')+1,sn.length());
                        if(sn.startsWith("class")) sn=sn.substring(5).trim();
                        // array is shown as ";"  ???
                        if(sn.endsWith(";"))
                        {
                            sn=sn.substring(0,sn.length()-1)+"[]";
                        }
                        full+= sn+", ";
                    }
                    if(tvm.length>0) full=full.substring(0,full.length()-2);
                    full+= ")";

                    //System.out.println("Found: "+full);

                    if(full.equals(sign) || full.equals(fullSign))
                    {
                        LinkedHashMap<String,String> inputs = runnClass.getInputsBySignature(sign);
                        if(inputs.size()!=genericInputs.size())
                        {
                            inputs=genericInputs;
                        }
                        MethodInputs mi = null;
                        boolean go = true;
                        if(inputs.size()>0)
                        {
                            mi = new MethodInputs(frame,inputs,full,runnClass.getJavaDocBySignature(sign));
                            go = mi.OK;
                        }
                        if(go==true)
                        {
                            try
                            {
                                String method = runnClass.getShortName()+"."+m[i].getName()+"(";
                                if(inputs.size()>0)
                                {
                                    Object[] keys = inputs.keySet().toArray();
                                    //int cc = 0;
                                    for(int in=0;in<keys.length;in++)
                                    {
                                        String name = (String) keys[in];
                                        String val = mi.getValueFor(name);
                                        if (val.equals("")) val="null";
                                        method+=val+",";
                                    }
                                    method=method.substring(0, method.length()-1);
                                }
                                method+=")";

                                // Invoke method in a new thread
                                final String myMeth = method;
                                Runnable r = new Runnable()
                                {
                                        public void run()
                                        {
                                            try
                                            {
                                                Object retobj = Runtime.getInstance().executeMethod(myMeth);
                                                if(retobj!=null) JOptionPane.showMessageDialog(frame, retobj.toString(), "Result", JOptionPane.INFORMATION_MESSAGE,Unimozer.IMG_INFO);
                                            }
                                            catch (EvalError ex)
                                            {
                                                JOptionPane.showMessageDialog(frame, ex.toString(), "Execution error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                                                MyError.display(ex);
                                            }
                                        }
                                };
                                Thread t = new Thread(r);
                                t.start();

                                //System.out.println(method);
                                //Object retobj = Runtime.getInstance().executeMethod(method);
                                //if(retobj!=null) JOptionPane.showMessageDialog(frame, retobj.toString(), "Result", JOptionPane.INFORMATION_MESSAGE,Unimozer.IMG_INFO);
                            }
                            catch (Throwable ex)
                            {
                                JOptionPane.showMessageDialog(frame, ex.toString(), "Execution error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                                MyError.display(ex);
                            }
                        }
                    }
                }
            }
        }
        catch (ClassNotFoundException ex)
        {
            JOptionPane.showMessageDialog(frame, "There was an error while running your project ...", "Error :: ClassNotFoundException", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
        }
    }

    public void jar()
    {
        try
        {
            // compile all
            doCompilationOnly(null);

            if(save())
            {

                // adjust the dirname
                String dir = getDirectoryName();
                if (!dir.endsWith("/"))
                {
                    dir += "/";
                }

                // adjust the filename
                String name = getDirectoryName();
                if (name.endsWith("/"))
                {
                    name = name.substring(0, name.length() - 1);
                }
                name = name.substring(name.lastIndexOf("/")+1);

                /*String[] classNames = new String[classes.size()+1];
                Set<String> set = classes.keySet();
                Iterator<String> itr = set.iterator();
                classNames[0]=null;
                int c = 1;
                while (itr.hasNext())
                {
                    classNames[c]=itr.next();
                    c++;
                }/**/
                Vector<String> mains = getMains();
                String[] classNames = new String[mains.size()];
                for(int c=0;c<mains.size();c++) classNames[c]=mains.get(c);
                // default class to launch
                String mc = "";
                {
                    if(classNames.length==0) mc="";
                    else if(classNames.length==1) mc=classNames[0];
                    else mc= (String) JOptionPane.showInputDialog(
                                       frame,
                                       "Unimozer detected more than one runnable class.\n"
                                       +"Please select which one you want to be launched\n"
                                       +"automatically with the JAR-archive.",
                                       "Autostart",
                                       JOptionPane.QUESTION_MESSAGE,
                                       Unimozer.IMG_QUESTION,
                                       classNames,
                                       "");
                }
                // target JVM
                String target = null;
                if(Runtime.getInstance().usesSunJDK() && mc!=null)
                {
                    target= (String) JOptionPane.showInputDialog(
                                       frame,
                                       "Please enter version of the JVM you want to target.",
                                       "Target JVM",
                                       JOptionPane.QUESTION_MESSAGE,
                                       Unimozer.IMG_QUESTION,
                                       new String[]{"1.1","1.2","1.3","1.5","1.6"},
                                       "1.5");
                }
                // make the class-files and all
                // related stuff
                if (
                        (
                            (Runtime.getInstance().usesSunJDK() && target!=null)
                            ||
                            (!Runtime.getInstance().usesSunJDK())
                        )
                        &&
                        (mc!=null)
                   )
                if (makeInteractive(false,target,false)==true)
                {

                    StringList manifest = new StringList();
                    manifest.add("Manifest-Version: 1.0");
                    manifest.add("Created-By: "+Unimozer.E_VERSION+" "+Unimozer.E_VERSION);
                    manifest.add("Name: "+name);
                    if(mc!=null)
                    {
                        manifest.add("Main-Class: "+mc);
                    }
                    manifest.add("");

                    // compose the filename
                    File fDir = new File(dir+"dist/");
                    fDir.mkdir();
                    name = dir + "dist/" + name + ".jar";

                    File outFile = new File(name);
                    FileOutputStream bo = new FileOutputStream(name);
                    JarOutputStream jo = new JarOutputStream(bo);

                    String dirname = getDirectoryName();
                    if (!dirname.endsWith("/"))
                    {
                        dirname += "/";
                    }
                    // add the files to the array
                    Set<String> set = classes.keySet();
                    Iterator<String> itr = set.iterator();
                    int i = 0;
                    while (itr.hasNext())
                    {
                        String classname = itr.next();
                        String act = classname + ".class";
                        FileInputStream bi = new FileInputStream(dirname+"bin/"+act);
                        JarEntry je = new JarEntry(act);
                        jo.putNextEntry(je);
                        byte[] buf = new byte[1024];
                        int anz;
                        while ((anz = bi.read(buf)) != -1)
                        {
                            jo.write(buf, 0, anz);
                        }
                        bi.close();
                    }
                    // adding the manifest file
                    JarEntry je = new JarEntry("META-INF/MANIFEST.MF");
                    jo.putNextEntry(je);
                    String mf = manifest.getText();
                    jo.write(mf.getBytes(), 0, mf.getBytes().length);

                    jo.close();
                    bo.close();

                    JOptionPane.showMessageDialog(frame, "The JAR-archive has been generated ...", "Success", JOptionPane.INFORMATION_MESSAGE,Unimozer.IMG_INFO);
                 }
            }
        }
        catch (ClassNotFoundException ex)
        {
            JOptionPane.showMessageDialog(frame, "There was an error while creating the JAR-archive ...", "Error :: ClassNotFoundException", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
        }
        catch (IOException ex)
        {
            JOptionPane.showMessageDialog(frame, "There was an error while creating the JAR-archive ...", "Error :: IOException", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
        }
    }


    public void createJavaDoc(boolean showMessage)
    {
        if(save())
        {
            setChanged(false);
            String dirname = getDirectoryName();
            try
            {
                if (!dirname.endsWith(System.getProperty("file.separator")))
                {
                    dirname += System.getProperty("file.separator");
                }
                String[] args = new String[classes.size()+12];
                args[0]="-d";
                args[1]=dirname+"doc"+System.getProperty("file.separator");
                //args[1]=args[1].replaceAll(" ","%20");
                //if(args[1].contains(" ")) args[1]='"'+args[1]+'"';
                args[2]="-link";
                args[3]="http://java.sun.com/j2se/1.5.0/docs/api/";
                args[4]="-encoding";
                args[5]=Unimozer.FILE_ENCODING;
                args[6]="-docencoding";
                args[7]=Unimozer.FILE_ENCODING;
                args[8]="-charset";
                args[9]=Unimozer.FILE_ENCODING;
                args[10]="-quiet"; //"-quiet";
                args[11]="-private";
                Set<String> set = classes.keySet();
                Iterator<String> itr = set.iterator();
                int i = 12;
                while (itr.hasNext())
                {
                    String classname = itr.next();
                    args[i]=dirname+classname+".java";
                    i++;
                }
                frame.console.disconnect();
                int retres = com.sun.tools.javadoc.Main.execute("javadoc",args);
                frame.console.connect();
            }
            catch (Exception ex)
            {
                JOptionPane.showMessageDialog(frame, "Something went wrong!\n\n"+ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
            }
            catch (Error ex)
            {
                JOptionPane.showMessageDialog(frame, "Something went wrong!\n\n"+ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
            }

            save();
            if (showMessage) JOptionPane.showMessageDialog(frame, "The JavaDoc files have been generated ...", "Success", JOptionPane.INFORMATION_MESSAGE,Unimozer.IMG_INFO);
        }
    }

    public void createJavaDoc()
    {
        createJavaDoc(false);
    }

    public void javadoc()
    {
        createJavaDoc(true);
    }

    // http://www.rgagnon.com/javadetails/java-0483.html
    public boolean deleteDirectory(File path)
    {
        if( path.exists() )
        {
            File[] files = path.listFiles();
            for(int i=0; i<files.length; i++)
            {
                if(files[i].isDirectory())
                {
                    deleteDirectory(files[i]);
                }
                else
                {
                    files[i].delete();
                }
            }
        }
        return( path.delete() );
    }

    public void clean()
    {
        // get the directory
        String dirname = getDirectoryName();
        if(dirname!=null)
        {
            if (!dirname.endsWith("/"))
            {
                dirname += "/";
            }


            /*
            // delete all CLASS-files
            Set<String> set = classes.keySet();
            Iterator<String> itr = set.iterator();
            int i = 0;
            while (itr.hasNext())
            {
                String classname = itr.next();
                String act = classname + ".class";
                // also clean classes generated by BlueJ (if present)
                File file = new File(dirname+act);
                if(file.exists()) file.delete();
                file = new File(dirname+"bin/"+act);
                if(file.exists()) file.delete();
            }
            // delete the directory
            File binDir = new File(dirname+"bin/");
            binDir.delete();
            // delete the JAR-file
            // adjust the dirname
            String dir = getDirectoryName();
            if (!dir.endsWith("/"))
            {
                dir += "/";
            }

            // adjust the filename
            // adjust the filename
            String name = getDirectoryName();
            if (name.endsWith("/"))
            {
                name = name.substring(0, name.length() - 1);
            }
            name = name.substring(name.lastIndexOf("/")+1);

            // compose the filename
            File fDir = new File(dir+"dist/");
            name = dir + "dist/" + name + ".jar";
            File file = new File(name);
            //if(file.exists()) file.delete();
            if(fDir.exists()) fDir.delete();*/

            // delete all "class" and "ctxt" files (BlueJ)
            File path = new File(dirname);
            if(path.exists())
            {
                File[] files = path.listFiles();
                for(int i=0; i<files.length; i++)
                {
                    if(
                        files[i].getName().endsWith(".class")
                        ||
                        files[i].getName().endsWith(".ctxt")
                    )
                    {
                        files[i].delete();
                    }
                }
            }

            boolean d1 = deleteDirectory(new File(dirname+"bin/"));
            boolean d2 = deleteDirectory(new File(dirname+"dist/"));
            boolean d3 = deleteDirectory(new File(dirname+"doc/"));
            if (
                    d1
                    &&
                    d2
                    &&
                    d3
            )
            {
                JOptionPane.showMessageDialog(
                    frame,
                    "Project cleaned up ...",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE,
                    Unimozer.IMG_INFO
                );
            }
            else
            {
                JOptionPane.showMessageDialog(
                    frame,
                    "Project cleaned up ...",
                    "Something went wrong ...",
                    JOptionPane.ERROR_MESSAGE,
                    Unimozer.IMG_ERROR
                );
            }
        }
    }

    public void command()
    {
        String cmd = JOptionPane.showInputDialog(frame, "Please enter the command you want to run.", "Run command", JOptionPane.QUESTION_MESSAGE);
        if (cmd!=null)
        {
            try
            {
                Runtime.getInstance().executeCommand(cmd);
            }
            catch (EvalError ex)
            {
                JOptionPane.showMessageDialog(frame, "Your command returned an error:\n\n"+ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
            }
        }
    }

    private void save(String dirName)
    {
        setDirectoryName(dirName);
        this.save();
        frame.setCanSave();
    }

    private void open(String dirname)
    {
        clear();
        //allowEdit=true;
        frame.setAllowEdit(allowEdit);
        frame.setRelations(true,true,true);


        setDirectoryName(dirname);
        // load package
        String filename = directoryName+"/"+Unimozer.U_PACKAGENAME;

        // is this a Unimozer Package
        File file = new File(filename);
        if(file.exists())
        {
            StringList content = new StringList();
            content.loadFromFile(filename);
            // load files
            for(int i = 0;i<content.count();i++)
            {
                if(
                    (i<=3)
                    &&
                        (
                            content.get(i).toLowerCase().equals("true")
                            ||
                            content.get(i).toLowerCase().equals("false")
                        )
                )
                {
                    switch(i)
                    {
                        case 0:
                                //allowEdit=Boolean.parseBoolean(content.get(i));
                                frame.setAllowEdit(allowEdit);
                                break;
                        case 1:
                                showHeritage=Boolean.parseBoolean(content.get(i));
                                break;
                        case 2:
                                showComposition=Boolean.parseBoolean(content.get(i));
                                break;
                        case 3:
                                showAggregation=Boolean.parseBoolean(content.get(i));
                                frame.setRelations(showHeritage, showComposition, showAggregation);
                                break;
                    }
                }
                else
                {
                    try
                    {
                        StringList line = new StringList();
                        line.setCommaText(content.get(i));
                        //MyClass mc = new MyClass(new FileInputStream(directoryName + "/" + line.get(0) + ".java"));
                        MyClass mc = new MyClass(directoryName + "/" + line.get(0) + ".java",Unimozer.FILE_ENCODING);
                        mc.setPosition(new Point(Integer.valueOf(line.get(1)), Integer.valueOf(line.get(2))));
                        addClass(mc);
                    }
                    catch (Exception ex)
                    {
                        System.err.println(ex.getMessage());
                    }
                }
            }
        }
        else // check if we can open a BlueJ Package
        {
            String bfilename = directoryName+"/"+Unimozer.B_PACKAGENAME;

            File bfile = new File(bfilename);
            if(bfile.exists())
            {
                Properties p = new Properties();
                try
                {
                    p.load(new FileInputStream(bfilename));
                    int i = 1;
                    while(p.containsKey("target"+i+".name"))
                    {
//                        MyClass mc = new MyClass(new FileInputStream(directoryName + "/" + p.getProperty("target"+i+".name") + ".java"));
                        MyClass mc = new MyClass(directoryName + "/" + p.getProperty("target"+i+".name") + ".java",Unimozer.FILE_ENCODING);
                        mc.setPosition(new Point(Integer.valueOf(p.getProperty("target"+i+".x")),
                                                 Integer.valueOf(p.getProperty("target"+i+".y"))));
                        addClass(mc);
                        i++;
                    }
                }
                catch (Exception ex)
                {
                    MyError.display(ex);
                }
            }
            else // simply load all Java files
            {
                File dir = new File(directoryName);

                String[] children = dir.list();
                if (children == null) {
                    // Either dir does not exist or is not a directory
                } else {
                    for (int i=0; i<children.length; i++) {
                        // Get filename of file or directory
                        String ffilename = children[i];
                    }
                }

                // It is also possible to filter the list of returned files.
                // This example does not return any files that start with `.'.
                FilenameFilter filter = new FilenameFilter() {
                    public boolean accept(File dir, String name) {
                        return (!name.startsWith(".") && name.toLowerCase().endsWith(".java"));
                    }
                };
                children = dir.list(filter);

                for(int i=0;i<children.length;i++)
                {
                    try
                    {
//                        MyClass mc = new MyClass(new FileInputStream(directoryName + "/" + children[i]));
                        MyClass mc = new MyClass(directoryName + "/" + children[i],Unimozer.FILE_ENCODING);
                        addClass(mc);
                    }
                    catch (Exception ex)
                    {
                        MyError.display(ex);
                    }
                }

            }
        }

        updateEditor();
        frame.setCanSave();
        setChanged(false);
        setUML(isUML);
    }

    private boolean saveWithAskingLocation()
    {
       OpenProject op = new OpenProject(new File(getContainingDirectoryName()),false,false);
       int result = op.showSaveDialog(frame,"Open");
       if(result==OpenProject.APPROVE_OPTION)
       {
            String dirName = op.getSelectedFile().getAbsolutePath().toString();
            File myDir = new File(dirName);
            if(myDir.exists())
            {
                 JOptionPane.showMessageDialog(frame, "The selected project or directory already exists.\nPlease choose another one ..." , "New project", JOptionPane.WARNING_MESSAGE,Unimozer.IMG_WARNING);
                 return false;
            }
            else
            {
                myDir.mkdir();
                //System.out.println(dirName);
                diagram.save(dirName);
                setChanged(false);
                return true;
            }
       } return false;

    }

    public boolean askToSave()
    {
        if(diagram.getClassCount()>0 && isChanged()==true)
        {
            int answ = JOptionPane.showConfirmDialog(frame, "Do you want to save the current project?", "Save project?", JOptionPane.YES_NO_CANCEL_OPTION);
            if (answ == JOptionPane.YES_OPTION)
            {
                if(directoryName==null) return saveWithAskingLocation();
                else return save();
            }
            else if (answ == JOptionPane.NO_OPTION)
            {
                return true;
            }
            else return false;
        }
        return true;
    }

    public boolean openUnimozer()
    {
        if(askToSave()==true)
        {
            OpenProject op = new OpenProject(new File(getContainingDirectoryName()),false,false);
            int result = op.showOpenDialog(frame);
            if(result==OpenProject.APPROVE_OPTION)
            {
                String dirName = op.getSelectedFile().getAbsolutePath().toString();
                this.open(dirName);
                setChanged(false);
                setEnabled(true);
                return true;
            } else return false;
        } else return false;
    }

    public boolean saveAsUnimozer()
    {
       OpenProject op = new OpenProject(new File(getContainingDirectoryName()),false,false);
       int result = op.showSaveDialog(frame);
       if(result==OpenProject.APPROVE_OPTION)
       {
            String dirName = op.getSelectedFile().getAbsolutePath().toString();
            File myDir = new File(dirName);
            if(myDir.exists())
            {
                 JOptionPane.showMessageDialog(frame, "The selected project or directory already exists.\nPlease choose another one ..." , "New project", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                 return false;
            }
            else
            {
                myDir.mkdir();
                //System.out.println(dirName);
                this.save(dirName);
                setChanged(false);
                return true;
            }
       } return false;
    }

    public boolean newUnimozer()
    {
       if(askToSave()==true)
       {
           /*
           OpenProject op = new OpenProject(null,false,false);
           int result = op.showSaveDialog(frame);
           if(result==OpenProject.APPROVE_OPTION)
           {
                String dirName = op.getSelectedFile().getAbsolutePath().toString();
                File myDir = new File(dirName);
                if(myDir.exists())
                {
                     JOptionPane.showMessageDialog(frame, "The selected project or directory already exists.\nPlease choose another one ..." , "New project", JOptionPane.ERROR_MESSAGE,Unimozer.IMG_ERROR);
                     return false;
                }
                else
                {
            */
                    clear();
                    setChanged(false);
                    setEnabled(true);
                    repaint();
            /*
                    myDir.mkdir();
                    //System.out.println(dirName);
                    this.save(dirName);
             */
                    return true;
             /*
             }
           }
           return false;
            */
       } return false;
    }

    public void saveUnimozer()
    {
        this.save();
        setChanged(false);
    }

    public int getClassCount()
    {
        return classes.size();
    }

    //
    // (!) classes must be compiled (!)
    //
    public Vector<String> getMains() throws ClassNotFoundException
    {
        Vector<String> mains = new Vector<String>();
        Set<String> set = classes.keySet();
        Iterator<String> itr = set.iterator();
        int c = 1;
        while (itr.hasNext())
        {
            String acuClassMame =itr.next();
            MyClass acuMyClass = classes.get(acuClassMame);

            if(ModifierSet.isPublic(acuMyClass.getModifiers()))
            {
                Class<?> cla = Runtime.getInstance().load(acuMyClass.getShortName());

                Method m[] = ((Class) cla).getDeclaredMethods();

                boolean found = false;
                for (int i = 0; i < m.length; i++)
                {
                    String full = "";
                    full+= m[i].getReturnType().getSimpleName();
                    full+=" ";
                    full+= m[i].getName();
                    full+= "(";
                    Type[] tvm = m[i].getParameterTypes();
                    for(int t=0;t<tvm.length;t++)
                    {
                        String sn = tvm[t].toString();
                        sn=sn.substring(sn.lastIndexOf('.')+1,sn.length());
                        if(sn.startsWith("class")) sn=sn.substring(5).trim();
                        full+= sn+", ";
                    }
                    if(tvm.length>0) full=full.substring(0,full.length()-2);
                    full+= ")";
                    String complete = new String(Modifier.toString(m[i].getModifiers())+" "+full);
                    //System.err.println(acuClassMame+" >> "+complete);
                    if(complete.equals("public static void main(String;)")) mains.add(acuClassMame);
                }
            }
        }
        return mains;
    }


	public void exportPNG()
	{
		selectClass(null);

		JFileChooser dlgSave = new JFileChooser("Export diagram as PNG ...");
		// propose name
		String uniName = directoryName.substring(directoryName.lastIndexOf('/')+1).trim();
		dlgSave.setSelectedFile(new File(uniName));

		dlgSave.addChoosableFileFilter(new PNGFilter());
		int result = dlgSave.showSaveDialog(frame);
		if (result == JFileChooser.APPROVE_OPTION)
		{
			String filename=dlgSave.getSelectedFile().getAbsoluteFile().toString();
			if(!filename.substring(filename.length()-4, filename.length()).toLowerCase().equals(".png"))
			{
				filename+=".png";
			}

			File file = new File(filename);
			BufferedImage bi = new BufferedImage(this.getWidth(), this.getHeight(),BufferedImage.TYPE_4BYTE_ABGR);
			paint(bi.getGraphics());
			try
			{
				ImageIO.write(bi, "png", file);
			}
			catch(Exception e)
			{
				JOptionPane.showOptionDialog(frame,"Error while saving the image!","Error",JOptionPane.OK_OPTION,JOptionPane.ERROR_MESSAGE,null,null,null);
			}
		}
	}

	// Inner class is used to hold an image while on the clipboard.
	public static class ImageSelection implements Transferable
		{
			// the Image object which will be housed by the ImageSelection
			private Image image;

			public ImageSelection(Image image)
			{
				this.image = image;
			}

			// Returns the supported flavors of our implementation
			public DataFlavor[] getTransferDataFlavors()
			{
				return new DataFlavor[] {DataFlavor.imageFlavor};
			}

			// Returns true if flavor is supported
			public boolean isDataFlavorSupported(DataFlavor flavor)
			{
				return DataFlavor.imageFlavor.equals(flavor);
			}

			// Returns Image object housed by Transferable object
			public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException,IOException
			{
				if (!DataFlavor.imageFlavor.equals(flavor))
				{
					throw new UnsupportedFlavorException(flavor);
				}
				// else return the payload
				return image;
			}
		}

    public void copyToClipboardPNG()
	{
		Clipboard systemClipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		//DataFlavor pngFlavor = new DataFlavor("image/png","Portable Network Graphics");

		// get diagram
		BufferedImage image = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_INT_ARGB);
		paint(image.getGraphics());

		// put image to clipboard
		ImageSelection imageSelection = new ImageSelection(image);
		systemClipboard.setContents(imageSelection, null);
	}


    /**
     * méthode qui recherche le plus grand nombre dans une liste
     * 1) supposer que le premier élément est le plus grand
     * 2) parcourir la liste et tester les éléments restants s'il
     *    n'y a pas un autre élément plus grand et mémoriser alors
     *    celui-ci
     */
    public int findMax(int[] liste)
    {
        int max = liste[0];
        for(int i=1 ; i<liste.length ; i++)
        {
            if (liste[i]>max)
            {
                max = liste[i];
            }
        }
        return max;
    }
    
    public void addConstructor()
    {
        MyClass mc = this.getSelectedClass();
        if (mc!=null)
        {
            ConstructorEditor ce = ConstructorEditor.showModal(this.frame, "Add a new constructor");
            if (ce.OK==true)
            {
                mc.addConstructor(ce.getModifier(),ce.getParams(),ce.generateJavaDoc());
                diagram.selectClass(mc);
                updateEditor();
                setChanged(true);
                if(Unimozer.javaCompileOnTheFly)
                {
                    new Thread(new Runnable() {

                        public void run()
                        {
                            diagram.compile(null);
                        }
                    }).start();
                }

                /*
                ConstructorDeclaration cd = mc.addConstructor(ce.getModifier(),ce.getParams());

                Ini.set("javaDocConstructor", Boolean.toString(ce.generateJavaDoc()));
                if(ce.generateJavaDoc())
                {
                    String jd=
                         "\n"+
                         "     * Write a description of this constructor here."+"\n"+
                         "     * "+"\n";
                    Vector<Vector<String>> params = ce.getParams();
                    int maxLength = 0;
                    for(int i=0;i<params.size();i++)
                    {
                        int thisLength=params.get(i).get(1).length();
                        if(thisLength>maxLength) maxLength=thisLength;
                    }
                    for(int i=0;i<params.size();i++)
                    {
                        String thisName=params.get(i).get(1);
                        while (thisName.length()<maxLength) thisName+=" ";
                        jd+="     * @param "+thisName+"    a description of the parameter “"+thisName+"“\n";
                    }
                    jd+= "     ";
                    JavadocComment jdc = new JavadocComment(jd);
                    cd.setJavaDoc(jdc);
                }


                diagram.selectClass(mc);
                setChanged(true);
                 */
            }
        }
    }

    public void addMethod()
    {
        MyClass mc = this.getSelectedClass();
        if (mc!=null)
        {
            MethodEditor me = MethodEditor.showModal(this.frame,"Add a new method");
            if (me.OK==true)
            {
                mc.addMethod(me.getMethodType(),me.getMethodName(),me.getModifier(), me.getParams(),me.generateJavaDoc());
                diagram.selectClass(mc);
                updateEditor();
                setChanged(true);
                if(Unimozer.javaCompileOnTheFly)
                {
                    new Thread(new Runnable() {

                        public void run()
                        {
                            diagram.compile(null);
                        }
                    }).start();
                }

                /*
                MethodDeclaration md = mc.addMethod(me.getMethodType(),me.getMethodName(),me.getModifier(), me.getParams());

                Ini.set("javaDocMethod", Boolean.toString(me.generateJavaDoc()));
                if(me.generateJavaDoc())
                {
                    String jd=
                         "\n"+
                         "     * Write a description of method “"+me.getMethodName()+"“ here."+"\n"+
                         "     * "+"\n";
                    Vector<Vector<String>> params = me.getParams();
                    int maxLength = 0;
                    for(int i=0;i<params.size();i++)
                    {
                        int thisLength=params.get(i).get(1).length();
                        if(thisLength>maxLength) maxLength=thisLength;
                    }
                    for(int i=0;i<params.size();i++)
                    {
                        String thisName=params.get(i).get(1);
                        while (thisName.length()<maxLength) thisName+=" ";
                        jd+="     * @param "+thisName+"    a description of the parameter “"+thisName+"“\n";
                    }
                    if(!me.getMethodType().equals("void"))
                    {
                        String thisName = new String();
                        while (thisName.length()<maxLength) thisName+=" ";
                        jd+="     * @return "+thisName+"     a description of the returned result\n";
                    }
                    jd+= "     ";
                    JavadocComment jdc = new JavadocComment(jd);
                    md.setJavaDoc(jdc);
                }

                diagram.selectClass(mc);
                setChanged(true);
                 */
            }
        }
    }

    public void addField()
    {
        MyClass mc = this.getSelectedClass();
        if (mc!=null)
        {
            FieldEditor fe = FieldEditor.showModal(this.frame, "Add a new field");
            if (fe.OK==true)
            {
                mc.addField(fe.getFieldType(),fe.getFieldName(),fe.getModifier(),fe.generateJavaDoc());
                diagram.selectClass(mc);
                updateEditor();
                setChanged(true);
                if(Unimozer.javaCompileOnTheFly)
                {
                    new Thread(new Runnable() {

                        public void run()
                        {
                            diagram.compile(null);
                        }
                    }).start();
                }

                /*
                FieldDeclaration fd = mc.addField(fe.getFieldType(),fe.getFieldName(),fe.getModifier());

                Ini.set("javaDoField", Boolean.toString(fe.generateJavaDoc()));
                if(fe.generateJavaDoc())
                {
                    String jd=
                         "\n"+
                         "     * Write a description of field “"+fe.getFieldName()+"“ here."+"\n";
                    jd+= "     ";
                    JavadocComment jdc = new JavadocComment(jd);
                    fd.setJavaDoc(jdc);
                }

                diagram.selectClass(mc);
                setChanged(true);
                 */
            }
        }
    }



}
