/*
    Unimozer
    Unimozer intends to be a universal modelizer for Java™. It allows the user
    to draw UML diagrams and generates the relative Java™ code automatically
    and vice-versa.

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package lu.fisch.unimozer;

import com.apple.eawt.Application;
import com.apple.eawt.ApplicationEvent;
import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Map;
import java.util.TreeSet;
import java.util.Vector;

/**
 *
 * @author robertfisch
 */
public class Main
{

    /**
     * @param args the command line arguments
     */
    public static void addJarFile(File file) throws Exception
    {
      URL url = file.toURI().toURL();
      URLClassLoader classLoader
             = (URLClassLoader) ClassLoader.getSystemClassLoader();
      Class clazz= URLClassLoader.class;

      // Use reflection
      Method method= clazz.getDeclaredMethod("addURL", new Class[] { URL.class });
      method.setAccessible(true);
      method.invoke(classLoader, new Object[] { url });
    }

    public static void main(String[] args)
    {
        // start Unimozer
        Unimozer.messages.add("Staring Unimozer ...");

        /*
         * Task #1 >> Find <tools.jar>
         */
        Unimozer.messages.add("---");
        Unimozer.messages.add("Searching <tools.jar> ...");

        // is it in the path?
        Unimozer.messages.add("Searching in the actual path ...");
        boolean inPath = true;
        try
        {
            Class.forName("com.sun.tools.javadoc.Main");
            Unimozer.messages.add("<tools.jar> has been found somewhere in the path.");
        }
        catch (Exception ex)
        {
            inPath=false;
        }

        if (inPath==false)
        {
            // get boot folder
            String bootFolder = System.getProperty("sun.boot.library.path");
            // go back two directories
            bootFolder=bootFolder.substring(0,bootFolder.lastIndexOf(System.getProperty("file.separator")));
            bootFolder=bootFolder.substring(0,bootFolder.lastIndexOf(System.getProperty("file.separator")));

            Unimozer.messages.add("Searching in the bootfolder: "+bootFolder);

            // get all files from the boot folder
            File bootFolderfile = new File(bootFolder);
            File[] files = bootFolderfile.listFiles();
            TreeSet<String> directories = new TreeSet<String>();
            for(int i=0;i<files.length;i++)
            {
                if(files[i].isDirectory()) directories.add(files[i].getAbsolutePath());
            }
            boolean found=false;
            String JDK_directory = "";

            while(directories.size()>0 && found==false)
            {
                JDK_directory = directories.last();
                directories.remove(JDK_directory);
                File tools = new File(JDK_directory+System.getProperty("file.separator")+"lib"+System.getProperty("file.separator")+"tools.jar");
                if(tools.exists())
                {
                    // we got it!
                    found=true;
                    Unimozer.messages.add("<tools.jar> found here: "+tools.getAbsolutePath());
                    // now fix the JDK_home
                    Unimozer.JDK_home=JDK_directory;
                    // include the <tools.jar>
                    try
                    {
                        addJarFile(tools);
                    } catch (Exception ex) { ex.printStackTrace(); }
                }
            }

            // still not found?
            if (found==false)
            {
                // try to fetch the JDK_HOME env variable
                Unimozer.messages.add("Searching in JDK_HOME (if set)");
                String JDK_HOME = System.getenv("JDK_HOME");
                if (JDK_HOME!=null)
                {
                    if((new File(JDK_HOME)).exists())
                    {
                        Unimozer.messages.add("JDK_HOME has been set: "+JDK_HOME);
                        String TOOLS_filename = JDK_HOME+System.getProperty("file.separator")+"lib"+System.getProperty("file.separator")+"tools.jar";
                        File tools = new File(TOOLS_filename);
                        //  load it?
                        if (tools.exists())
                        {
                            Unimozer.messages.add("<tools.jar> found here: "+tools.getAbsolutePath());
                            // now fix the JDK_home
                            Unimozer.JDK_home=JDK_HOME;
                            // include the <tools.jar>
                            try
                            {
                                addJarFile(tools);
                            } catch (Exception ex) { ex.printStackTrace(); }
                        }
                    }
                    else
                    {
                        Unimozer.messages.add("JDK_HOME has *not* been set!");
                    }
                }

            }
        }

        /*
         * Task #2 >> find <src.zip>
         */
        Unimozer.messages.add("---");
        Unimozer.messages.add("Search for <src.zip> / <src.jar> ...");
        boolean foundSrc = false;
        if (Unimozer.JDK_home!=null)
        {
            File JDK_home = new File(Unimozer.JDK_home);
            if (JDK_home.exists())
            {
                String SRC_filename = Unimozer.JDK_home+System.getProperty("file.separator")+"src.zip";
                File SRC_file = new File(SRC_filename);
                if (SRC_file.exists())
                {
                    foundSrc=true;
                    Unimozer.JDK_source = SRC_filename;
                    Unimozer.messages.add("<src.zip> found: "+SRC_filename);
                }
            }
        }
        if (foundSrc==false)
        {
            // get boot folder
            String bootFolder = System.getProperty("sun.boot.library.path");

            // go back two directories
            bootFolder=bootFolder.substring(0,bootFolder.lastIndexOf(System.getProperty("file.separator")));
            bootFolder=bootFolder.substring(0,bootFolder.lastIndexOf(System.getProperty("file.separator")));
            if(System.getProperty("os.name").toLowerCase().startsWith("mac os x"))
            {
                bootFolder=bootFolder+System.getProperty("file.separator")+"Contents"+System.getProperty("file.separator")+"Home";
            }

            Unimozer.messages.add("Searching in the bootfolder: "+bootFolder);

            String JDK_HOME = bootFolder;
            if((new File(JDK_HOME)).exists())
            {
                Unimozer.messages.add("JDK_HOME has been set: "+JDK_HOME);
                String TOOLS_filename = JDK_HOME+System.getProperty("file.separator")+"src.zip";
                File src = new File(TOOLS_filename);
                //  load it?
                if (src.exists())
                {
                    Unimozer.messages.add("<src.zip> found here: "+src.getAbsolutePath());
                    // now fix the JDK_home
                    Unimozer.JDK_home=JDK_HOME;
                    Unimozer.JDK_source = src.getAbsolutePath();
                    foundSrc=true;
                }
            }
            else
            {
                Unimozer.messages.add("JDK_HOME has *not* been set!");
            }

        }
        if (foundSrc==false)
        {
            // get boot folder
            String bootFolder = System.getProperty("sun.boot.library.path");

            // go back two directories
            bootFolder=bootFolder.substring(0,bootFolder.lastIndexOf(System.getProperty("file.separator")));
            bootFolder=bootFolder.substring(0,bootFolder.lastIndexOf(System.getProperty("file.separator")));

            Unimozer.messages.add("Searching again in the bootfolder: "+bootFolder);

            // get all files from the boot folder
            File bootFolderfile = new File(bootFolder);
            File[] files = bootFolderfile.listFiles();
            TreeSet<String> directories = new TreeSet<String>();
            for(int i=0;i<files.length;i++)
            {
                if(files[i].isDirectory()) directories.add(files[i].getAbsolutePath());
            }
            boolean found=false;
            String JDK_directory = "";

            while(directories.size()>0 && found==false)
            {
                JDK_directory = directories.last();
                directories.remove(JDK_directory);
                File src = new File(JDK_directory+System.getProperty("file.separator")+"src.zip");
                if(src.exists())
                {
                    // we got it!
                    found=true;
                    Unimozer.messages.add("<src.zip> found here: "+src.getAbsolutePath());
                    // now fix the JDK_home
                    Unimozer.JDK_home=JDK_directory;
                    Unimozer.JDK_source = src.getAbsolutePath();
                }
            }

        }
        if (foundSrc==false)
        {
            // get boot folder
            String bootFolder = System.getProperty("sun.boot.library.path");

            // go back two directories
            bootFolder=bootFolder.substring(0,bootFolder.lastIndexOf(System.getProperty("file.separator")));
            bootFolder=bootFolder.substring(0,bootFolder.lastIndexOf(System.getProperty("file.separator")));
            bootFolder=bootFolder.replace(" (x86)","");

            Unimozer.messages.add("Searching one more time in the bootfolder: "+bootFolder);

            // get all files from the boot folder
            File bootFolderfile = new File(bootFolder);
            if(bootFolderfile.exists())
            {
                if(bootFolderfile!=null)
                {
                    File[] files = bootFolderfile.listFiles();
                    if (files!=null)
                    {
                        TreeSet<String> directories = new TreeSet<String>();
                        for(int i=0;i<files.length;i++)
                        {
                            if(files[i].isDirectory()) directories.add(files[i].getAbsolutePath());
                        }
                        boolean found=false;
                        String JDK_directory = "";

                        while(directories.size()>0 && found==false)
                        {
                            JDK_directory = directories.last();
                            directories.remove(JDK_directory);
                            File src = new File(JDK_directory+System.getProperty("file.separator")+"src.zip");
                            if(src.exists())
                            {
                                // we got it!
                                found=true;
                                Unimozer.messages.add("<src.zip> found here: "+src.getAbsolutePath());
                                // now fix the JDK_home
                                Unimozer.JDK_home=JDK_directory;
                                Unimozer.JDK_source = src.getAbsolutePath();
                            }
                        }
                    }
                    else Unimozer.messages.add("Doens not contains directories!");
                }
                else Unimozer.messages.add("Folder is null!");
             }
             else Unimozer.messages.add("Folder does not exist!");
        }
        // only for the mac
        if ( (foundSrc==false) && (System.getProperty("os.name").toLowerCase().startsWith("mac os x")))
        {
            Unimozer.messages.add("Searching in the Mac JDK folder: /Library/Java/JavaVirtualMachines");

            // get all files from it
            File bootFolderfile = new File("/Library/Java/JavaVirtualMachines/");
            File[] files = bootFolderfile.listFiles();
            if(files!=null)
            {
                TreeSet<String> directories = new TreeSet<String>();
                for(int i=0;i<files.length;i++)
                {
                    if(files[i].isDirectory())
                        directories.add(files[i].getAbsolutePath());
                }
                boolean found=false;
                String JDK_directory = "";

                while(directories.size()>0 && found==false)
                {
                    JDK_directory = directories.last();
                    directories.remove(JDK_directory);
                    File src = new File(JDK_directory+System.getProperty("file.separator")+"Contents"+System.getProperty("file.separator")+"Home"+System.getProperty("file.separator")+"src.jar");
                    if(src.exists())
                    {
                        // we got it!
                        found=true;
                        Unimozer.messages.add("<src.jar> found here: "+src.getAbsolutePath());
                        // now fix the JDK_home
                        Unimozer.JDK_home=JDK_directory;
                        Unimozer.JDK_source = src.getAbsolutePath();
                    }
                }
            }

        }
        // still not found?
        if (foundSrc==false)
        {
            // try to fetch the JDK_HOME env variable
            Unimozer.messages.add("Searching in JDK_HOME (if set)");
            String JDK_HOME = System.getenv("JDK_HOME");
            if (JDK_HOME!=null)
            {
                if((new File(JDK_HOME)).exists())
                {
                    Unimozer.messages.add("JDK_HOME has been set: "+JDK_HOME);
                    String TOOLS_filename = JDK_HOME+System.getProperty("file.separator")+"src.zip";
                    File src = new File(TOOLS_filename);
                    //  load it?
                    if (src.exists())
                    {
                        Unimozer.messages.add("<src.zip> found here: "+src.getAbsolutePath());
                        // now fix the JDK_home
                        Unimozer.JDK_home=JDK_HOME;
                        Unimozer.JDK_source = src.getAbsolutePath();
                    }
                }
                else
                {
                    Unimozer.messages.add("JDK_HOME has *not* been set!");
                }
            }

        }

        Unimozer.messages.add("---");
        Unimozer.messages.add("JDK_home = "+Unimozer.JDK_home);

        /*if (Unimozer.JDK_home!=null)
        {
            Unimozer.messages.add("---");
            Unimozer.messages.add("Resetting java.home ("+System.getProperty("java.home")+")");
            System.setProperty("java.home", Unimozer.JDK_home);
        }*/


/*
        //for (java.util.Map.Entry s : System.getProperties().entrySet())
        //System.out.println(s.getKey()+": "+s.getValue());        // get the JDK_HOME directory

        //System.out.println(System.getProperty("java.version"));
        //System.out.println(System.getProperty("java.home"));

        //
        // trying to find the most recent JDK in Windows,
        // but only if there class is not yet in the path
        //
        Unimozer.messages.add("Searching <tools.jar> ...");
        boolean inPath = true;
        try
        {
            Class.forName("com.sun.tools.javadoc.Main");
            Unimozer.messages.add("<tools.jar> has been found somewhere in the path.");
        }
        catch (Exception ex) 
        {
            inPath=false;
            Unimozer.messages.add("<tools.jar> has not been found in the path. Searching for JDK ...");
        }

        // get boot folder
        String bootFolder = System.getProperty("sun.boot.library.path");
        Unimozer.messages.add("Bootfolder = "+bootFolder);

        // go back two directories
        bootFolder=bootFolder.substring(0,bootFolder.lastIndexOf(System.getProperty("file.separator")));
        bootFolder=bootFolder.substring(0,bootFolder.lastIndexOf(System.getProperty("file.separator")));

        // get all files from the boot folder
        File bootFolderfile = new File(bootFolder);
        File[] files = bootFolderfile.listFiles();
        TreeSet<String> directories = new TreeSet<String>();
        for(int i=0;i<files.length;i++)
        {
            if(files[i].isDirectory()) directories.add(files[i].getAbsolutePath());
        }
        boolean found=false;
        String JDK_directory = "";

        while(directories.size()>0 && found==false)
        {
            JDK_directory = directories.last();
            directories.remove(JDK_directory);
            File tools = new File(JDK_directory+System.getProperty("file.separator")+"lib"+System.getProperty("file.separator")+"tools.jar");
            if(tools.exists())
            {
                found=true;
            } 
        }

        if (found==true)
        {
            Unimozer.messages.add("<tools.jar> has been found in the boot folder: "+JDK_directory);
        }
        else
        {
            Unimozer.messages.add("<tools.jar> has *not* been found in the boot folder: "+JDK_directory);
        }

        // is the JDK_HOME env set?
        String JDK_HOME = System.getenv("JDK_HOME");
        if (JDK_HOME!=null)
        {
            if((new File(JDK_HOME)).exists())
                Unimozer.messages.add("JDK_HOME has been set: "+JDK_HOME);
            else
                Unimozer.messages.add("JDK_HOME has *not* been set!");
        }

        // try to acces this directory anyway
        String TOOLS_filename = JDK_HOME+System.getProperty("file.separator")+"lib"+System.getProperty("file.separator")+"tools.jar";
        File TOOLS_file = new File(TOOLS_filename);

        if(!JDK_directory.equals(""))
        {
            Unimozer.messages.add("JDK_directory is not empty ...");
            if(!TOOLS_file.exists())
            {
                if (inPath==false)
                {
                    Unimozer.messages.add("JDK_HOME has been set but contains no <tools.jar>!");
                    Unimozer.messages.add("Searching in startup path: "+JDK_directory);
                    //System.out.println("JDK_HOME has not been set, but a JDK has been found @ "+JDK_directory);
                    TOOLS_filename = JDK_directory+System.getProperty("file.separator")+"lib"+System.getProperty("file.separator")+"tools.jar";
                    TOOLS_file = new File(TOOLS_filename);
                    if(TOOLS_file.exists())
                    {
                        Unimozer.messages.add("<tools.jar> has been found: "+TOOLS_filename);
                    }
                }
            }
            if((new File(JDK_directory)).exists())
            {
                Unimozer.JDK_home=JDK_directory;
                Unimozer.messages.add("JDK_HOME is now: "+JDK_HOME);
            }
        }
        else
        {
            Unimozer.JDK_home=JDK_HOME;
            Unimozer.messages.add("JDK_HOME is set to: "+JDK_HOME);
        }

        // if a JDK has been detected, add the tools.jar to the classpath
        if (inPath==false)
        if(TOOLS_file.exists())
        {
            try
            {
                addJarFile(new File(TOOLS_filename));
                //ClassPathHacker.addFile(TOOLS_filename);
            }
            catch (Exception ex)
            {
                ex.printStackTrace();
                Unimozer.messages.add("<tools.jar> has not been found in the startup path either.");
            }
        }
        */

        try
        {
            Class.forName("com.sun.tools.javac.api.JavacTool");
            Unimozer.javaCompilerDetected=true;
        }
        catch (ClassNotFoundException ex)
        {
            Unimozer.messages.add("The Java compiler cannot be loaded ...");
            Unimozer.javaCompilerDetected=false;
        }


        final Mainform mainform = new Mainform();
        mainform.setIconImage(new javax.swing.ImageIcon(mainform.getClass().getResource("/lu/fisch/icons/unimozer.png")).getImage());

        try
        {
                String s = new String();
                for(int i=0;i<args.length;i++)
                {
                        s+=args[i];
                }
                 mainform.setVisible(true);
        }
        catch (Exception e)
        {
        }

        //System.out.println(Unimozer.messages.getText());

        /*
         * These are MAC specific things
         */
        if(System.getProperty("os.name").toLowerCase().startsWith("mac os x"))
        {
         
            System.setProperty("apple.laf.useScreenMenuBar", "true");
            System.setProperty("apple.awt.graphics.UseQuartz", "true");

            Application application = Application.getApplication();
            application.setDockIconImage(mainform.getIconImage());

            try
            {
                application.setEnabledPreferencesMenu(true);
                application.addApplicationListener(new com.apple.eawt.ApplicationAdapter()
                {
                    @Override
                    public void handleAbout(ApplicationEvent e)
                    {
                        mainform.getDiagram().about();
                        e.setHandled(true);
                    }

                    @Override
                    public void handleOpenApplication(ApplicationEvent e)
                    {
                    }

                    @Override
                    public void handleOpenFile(ApplicationEvent e)
                    {
                        if(e.getFilename()!=null)
                        {
                            //System.out.println("Opening file: "+e.getFilename());
                            //System.out.println("Opening package: "+(new File(e.getFilename()).getParent()));
                            mainform.diagram.openUnimozer(e.getFilename());
                            //mainform.diagram.openNSD(e.getFilename());
                        }
                    }

                    @Override
                    public void handlePreferences(ApplicationEvent e)
                    {
                        //mainform.diagram.preferencesNSD();
                    }

                    @Override
                    public void handlePrintFile(ApplicationEvent e)
                    {
                        mainform.getDiagram().printDiagram();
                    }

                    @Override
                    public void handleQuit(ApplicationEvent e)
                    {
                        //mainform.saveToINI();
                        mainform.closeWindow();
                    }
               });
            }
            catch (Exception e)
            {
                //e.printStackTrace();
            }
        }
        /**/

    }




}
