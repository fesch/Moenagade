/*
    Unimozer
    Unimozer intends to be a universal modelizer for Java™. It allows the user
    to draw UML diagrams and generates the relative Java™ code automatically
    and vice-versa.

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package lu.fisch.unimozer;

import com.apple.eawt.Application;
import com.apple.eawt.ApplicationEvent;
import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.TreeSet;

/**
 *
 * @author robertfisch
 */
public class Main
{

    /**
     * @param args the command line arguments
     */
    public static void addJarFile(File file) throws Exception
    {
      URL url = file.toURI().toURL();
      URLClassLoader classLoader
             = (URLClassLoader) ClassLoader.getSystemClassLoader();
      Class clazz= URLClassLoader.class;

      // Use reflection
      Method method= clazz.getDeclaredMethod("addURL", new Class[] { URL.class });
      method.setAccessible(true);
      method.invoke(classLoader, new Object[] { url });
    }

    public static void main(String[] args)
    {
        Unimozer.messages.add("Staring Unimozer ...");
        //for (java.util.Map.Entry s : System.getProperties().entrySet())
        //System.out.println(s.getKey()+": "+s.getValue());        // get the JDK_HOME directory

        //System.out.println(System.getProperty("java.version"));
        //System.out.println(System.getProperty("java.home"));

        //
        // trying to find the most recent JDK in Windows,
        // but only if there class is not yet in the path
        //
        Unimozer.messages.add("Searching <tools.jar> ...");
        boolean inPath = true;
        try
        {
            Class.forName("com.sun.tools.javadoc.Main");
            Unimozer.messages.add("<tools.jar> has been found somewhere in the path.");
        }
        catch (Exception ex) 
        {
            inPath=false;
            Unimozer.messages.add("<tools.jar> has not been found in the path. Searching for JDK ...");
        }

        if (inPath==false)
        {

            // get boot folder
            String bootFolder = System.getProperty("sun.boot.library.path");
            // go back two directories
            //bootFolder+=System.getProperty("file.separator")+".."+System.getProperty("file.separator")+"..";
            bootFolder=bootFolder.substring(0,bootFolder.lastIndexOf(System.getProperty("file.separator")));
            bootFolder=bootFolder.substring(0,bootFolder.lastIndexOf(System.getProperty("file.separator")));
            //System.err.println(bootFolder);
            // get contained files
            File bootFolderfile = new File(bootFolder);
            File[] files = bootFolderfile.listFiles();
            TreeSet<String> directories = new TreeSet<String>();
            for(int i=0;i<files.length;i++)
            {
                if(files[i].isDirectory()) directories.add(files[i].getAbsolutePath());
            }
            boolean found=false;
            String JDK_directory = "";

            while(directories.size()>0 && found==false)
            {
                JDK_directory = directories.last();
                directories.remove(JDK_directory);
                File tools = new File(JDK_directory+System.getProperty("file.separator")+"lib"+System.getProperty("file.separator")+"tools.jar");
                if(tools.exists())
                {
                    //System.out.println(">> "+tools.getAbsolutePath());
                    found=true;
                } else JDK_directory="";
            }


            String JDK_HOME = System.getenv("JDK_HOME");
            String TOOLS_filename = JDK_HOME+System.getProperty("file.separator")+"lib"+System.getProperty("file.separator")+"tools.jar";
            File TOOLS_file = new File(TOOLS_filename);
            Unimozer.messages.add("JDK_HOME has been set and contains <tools.jar>.");

            if(!TOOLS_file.exists() && !JDK_directory.equals(""))
            {
                Unimozer.messages.add("JDK_HOME has been set but contains no <tools.jar>. Searching in startup path ...");
                //System.out.println("JDK_HOME has not been set, but a JDK has been found @ "+JDK_directory);
                TOOLS_filename = JDK_directory+System.getProperty("file.separator")+"lib"+System.getProperty("file.separator")+"tools.jar";
                TOOLS_file = new File(TOOLS_filename);
            }

            // if a JDK has been detected, add the tools.jar to the classpath
            if(TOOLS_file.exists())
            {
                try
                {
                    addJarFile(new File(TOOLS_filename));
                    //ClassPathHacker.addFile(TOOLS_filename);
                }
                catch (Exception ex)
                {
                    ex.printStackTrace();
                    Unimozer.messages.add("<tools.jar> has not been found in the startup path either.");
                }
            }
            //else System.out.println("No JDK detected an JDK_HOME not set!");
        }
        try
        {
            Class.forName("com.sun.tools.javac.api.JavacTool");
            Unimozer.javaCompilerDetected=true;
        }
        catch (ClassNotFoundException ex)
        {
            Unimozer.messages.add("The Java compiler cannot be loaded ...");
            Unimozer.javaCompilerDetected=false;
        }


        final Mainform mainform = new Mainform();
        mainform.setIconImage(new javax.swing.ImageIcon(mainform.getClass().getResource("/lu/fisch/icons/unimozer.png")).getImage());

        try
        {
                String s = new String();
                for(int i=0;i<args.length;i++)
                {
                        s+=args[i];
                }
                 mainform.setVisible(true);
        }
        catch (Exception e)
        {
        }

        /*
         * These are MAC specific things
         */
        if(System.getProperty("os.name").toLowerCase().startsWith("mac os x"))
        {
         
            System.setProperty("apple.laf.useScreenMenuBar", "true");
            System.setProperty("apple.awt.graphics.UseQuartz", "true");

            Application application = Application.getApplication();
            application.setDockIconImage(mainform.getIconImage());

            try
            {
                application.setEnabledPreferencesMenu(true);
                application.addApplicationListener(new com.apple.eawt.ApplicationAdapter()
                {
                    @Override
                    public void handleAbout(ApplicationEvent e)
                    {
                        mainform.getDiagram().about();
                        e.setHandled(true);
                    }

                    @Override
                    public void handleOpenApplication(ApplicationEvent e)
                    {
                    }

                    @Override
                    public void handleOpenFile(ApplicationEvent e)
                    {
                        if(e.getFilename()!=null)
                        {
                            //mainform.diagram.openNSD(e.getFilename());
                        }
                    }

                    @Override
                    public void handlePreferences(ApplicationEvent e)
                    {
                        //mainform.diagram.preferencesNSD();
                    }

                    @Override
                    public void handlePrintFile(ApplicationEvent e)
                    {
                        mainform.getDiagram().printDiagram();
                    }

                    @Override
                    public void handleQuit(ApplicationEvent e)
                    {
                        //mainform.saveToINI();
                        mainform.closeWindow();
                    }
               });
            }
            catch (Exception e)
            {
                //e.printStackTrace();
            }
        }
        /**/

    }




}
