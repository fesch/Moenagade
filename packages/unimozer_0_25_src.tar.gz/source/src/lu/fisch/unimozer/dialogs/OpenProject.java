 /*
    Unimozer
    Unimozer intends to be a universal modelizer for Java™. It allows the user
    to draw UML diagrams and generates the relative Java™ code automatically
    and vice-versa.

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
 * Heavily modified version of:
 * program BlueJ
 * package bluej.utility
 * author  Michael Kolling
 * author  Axel Schmolitzky
 * author  Markus Ostman
 * version $Id: PackageChooser.java 6347 2009-05-20 15:22:43Z polle $ * version $Id: Terminal.java 6215 2009-03-30 13:28:25Z polle $
 */

/*
 This file is part of the BlueJ program.
 Copyright (C) 1999-2009  Michael Kolling and John Rosenberg

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

 This file is subject to the Classpath exception as provided in the
 LICENSE.txt file that accompanied this code.
 */


package lu.fisch.unimozer.dialogs;


import bluej.utility.JavaNames;
import bluej.utility.filefilter.DirectoryFilter;
import bluej.utility.filefilter.JavaSourceFilter;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.io.File;

import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.plaf.FileChooserUI;
import javax.swing.plaf.basic.BasicFileChooserUI;
import lu.fisch.unimozer.Mainform;


public class OpenProject extends JFileChooser
{
    final Icon classIcon = new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_class.png"));
    final Icon packageIcon = new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/ico_turtle.png"));

  
    /**
     * Create a new PackageChooser.
     *
     * @param startDirectory 	the directory to start the package selection in.
     * @param preview           whether to show the package structure preview pane
     * @param showArchives      whether to allow choosing jar and zip files
     */
    public OpenProject(File startDirectory, boolean showArchives)
    {
        super(startDirectory);
/*
        if (showArchives) {
            setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        }
        else {
            setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        }*/
        //setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);


        setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        setFileView(new PackageFileView());
        
        cleanField();
    }

    @Override
    public boolean accept(File f)
    {
        if (f.isDirectory())
        {
            return true;
        }
        else
            return false;
        /*
        String fname = f.getName();
        return fname.endsWith(".jar") || fname.endsWith(".JAR") ||
                fname.endsWith(".zip") || fname.endsWith(".ZIP");
         */
    }

    @Override
    public void setSelectedFile(File f)
    {
        String content = new String();
        FileChooserUI myUi = getUI();
        if (myUi instanceof BasicFileChooserUI) {
            BasicFileChooserUI mui = (BasicFileChooserUI) myUi;
            content = mui.getFileName();
        }
        super.setSelectedFile(f);
        if (myUi instanceof BasicFileChooserUI) {
            BasicFileChooserUI mui = (BasicFileChooserUI) myUi;
            mui.setFileName(content);
        }
    }

    /**
     *  A directory was double-clicked. If this is a BlueJ package, consider
     *  this a package selection and accept it as the "Open" action, otherwise
     *  just traverse into the directory.
     */
    @Override
    public void setCurrentDirectory(File dir)   // redefined
    {
        // get the actual content of the fielname field
        String content = new String();
        FileChooserUI myUi = getUI();
        if (myUi instanceof BasicFileChooserUI) {
            BasicFileChooserUI mui = (BasicFileChooserUI) myUi;
            content = mui.getFileName();
        }

        if ( PackageFile.exists(dir) || BlueJPackageFile.exists(dir) )
        {
            setSelectedFile(dir);
            super.approveSelection();
        }
        else
        {
            super.setCurrentDirectory(dir);
            // reset the content of the filename field
            if (myUi instanceof BasicFileChooserUI) {
                BasicFileChooserUI mui = (BasicFileChooserUI) myUi;
                mui.setFileName(content);
            }
        }
    }

    // clean entry
    private void cleanField()
    {
        FileChooserUI myUi = getUI();
        if (myUi instanceof BasicFileChooserUI) {
            BasicFileChooserUI mui = (BasicFileChooserUI) myUi;
            mui.setFileName("");
        }
    }

    /**
     * Approve the selection. We have this mainly so that derived classes
     * can call it...
     */
    protected void approved()
    {
        super.approveSelection();
    }

    public int showSaveDialog(Mainform frame, String string)
    {
        return this.showDialog(frame, string);
    }

}
