/*
    Unimozer
    Unimozer intends to be a universal modelizer for Java™. It allows the user
    to draw UML diagrams and generates the relative Java™ code automatically
    and vice-versa.

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package lu.fisch.unimozer;
 
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.tools.ToolProvider;
import lu.fisch.structorizer.gui.PrintPreview;
import lu.fisch.unimozer.console.Console;
import org.fife.print.RPrintUtilities;

/**
 *
 * @author robertfisch
 */
public class Mainform extends JFrame
{
    lu.fisch.structorizer.gui.Mainform structorizer = null;

    /** Creates new form Unimozer */
    public Mainform()
    {
        initComponents();

        // keystrokes
        miNew.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        miSave.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        miOpen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        miPrintDiagram.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P,Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
	miAbout.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1,0));
	miRun.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F6,0));
	miCompile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F9,0));
	miMake.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F10,0));
	miJar.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F11,0));
	miJavaDoc.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F12,0));
	miQuit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        

        this.setLayout(new AKDockLayout());
        
        this.getContentPane().removeAll();

        this.getContentPane().add(tbFile,AKDockLayout.NORTH);
        this.getContentPane().add(tbMake,AKDockLayout.NORTH);
        this.getContentPane().add(tbElements,AKDockLayout.NORTH);
        this.getContentPane().add(tbFontSize,AKDockLayout.NORTH);

        miToolbarFile.setSelected(true);
        miToolbarUML.setSelected(true);
        miToolbarRun.setSelected(false);
        miToolbarFont.setSelected(true);
        updateToolbars();
        
        this.getContentPane().add(pnlBody,AKDockLayout.CENTER);
        this.getContentPane().validate();


        diagram.setEditor(codeEditor);
        diagram.setFrame(this);
        diagram.setObjectizer(objectizer);
        diagram.setStatus(lblStatus);
        codeEditor.setDiagram(diagram);
        codeEditor.setStatus(lblStatus);
        objectizer.setDiagram(diagram); 
        objectizer.setFrame(this);

        this.setTitle(Unimozer.E_NAME);
        this.setDefaultCloseOperation(Mainform.DO_NOTHING_ON_CLOSE);

        /*System.setOut(new PrintStream(new JTextAreaOutputStream(txtOut)));
        System.setErr(new PrintStream(new JTextAreaOutputStream(txtErr)));
        /*
        System.setIn(terminal.in);
        System.setOut(new PrintStream(terminal.out));
        System.setErr(new PrintStream(terminal.err));
        /**/
 /*
        final TextAreaReader tar = new TextAreaReader(txtOut);
		Runnable r1 = new Runnable() {
			public void run() {
				while (true) {
					int code = tar.read();
					System.err.println("read: " + code);
				}
			}
		};
		Runnable r2 = new Runnable() {
			public void run() {
				while (true) {
					String line = tar.readLine();
					System.err.println("read line: " + line);
				}
			}
		};
		Thread t1 = new Thread(r1);
		Thread t2 = new Thread(r2);
		t1.start();
		t2.start();
        System.setIn(tar.toInputStream());
*/
/*
        Runtime.getInstance().interpreter.setConsole(console);
        new Thread( Runtime.getInstance().interpreter ).start();
        System.setIn(console.getInputStream());


        Runtime.getInstance().setOut(new PrintStream(new JTextAreaOutputStream(txtOut)));
        Runtime.getInstance().setErr(new PrintStream(new JTextAreaOutputStream(txtErr)));*/
        //Runtime.getInstance(console).setConsole(console);

        String message = "Unimozer was unable to find a properly installed JDK. Please make\n"+
                         "shure that the environment variable \"JDK_HOME\" points to the\n"+
                         "installation folder of your JDK.\n"+
                         "\n"+
                         "Unimozer can run without an installed JDK but its compiling\n"+
                         "functionality will be limited.\n"+
                         "\n"+
                         "For now, the internal Janino compiler will be used for compilation,\n"+
                         "which allows you to compile Java 1.4 compliant code with some\n"+
                         "limited functionalities of Java 1.5 ...";
        try
        {
            if(ToolProvider.getSystemJavaCompiler()==null)
            {
                JOptionPane.showMessageDialog(this, message , "Compiler", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        catch (NoClassDefFoundError ex)
        {
            JOptionPane.showMessageDialog(this, message , "Compiler", JOptionPane.INFORMATION_MESSAGE);
        }

        try
        {
            Class.forName("com.sun.tools.javadoc.Main");
            //com.sun.tools.javadoc.Main.execute("",new String[1]);
        }
        catch (ClassNotFoundException ex) //
        {
            miJavaDoc.setVisible(false);
            speJavaDoc.setVisible(false);
            Unimozer.javaDocDetected=false;
        }
        catch (NoClassDefFoundError ex)//
        {
            miJavaDoc.setVisible(false);
            speJavaDoc.setVisible(false);

        }

        //creating structorizer
        /*
        structorizer=new lu.fisch.structorizer.gui.Mainform();
        // change the default closing behaviour
        structorizer.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        diagram.setStructorizer(structorizer);
         * */

        // create NSD-diagram
        lu.fisch.structorizer.gui.Diagram nsd = new lu.fisch.structorizer.gui.Diagram(null,"---[ please select a method ]---");
        spNSD.add(nsd);
        spNSD.setViewportView(nsd);
        diagram.setNsd(nsd);

        /*
         * load settings from INI-file
         */
        Ini ini = Ini.getInstance();
        try
        {
            ini.load();
        }
        catch (FileNotFoundException ex)
        {
           ex.printStackTrace();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }

        // visual style
        if(ini.getProperty("umlStandard", "true").equals("true"))
        {
            diagram.setUML(true);
            miDiagramStandardJava.setSelected(false);
            miDiagramStandardUML.setSelected(true);
        }
        else
        {
            diagram.setUML(false);
            miDiagramStandardJava.setSelected(true);
            miDiagramStandardUML.setSelected(false);
        }

        // toolbars
        miToolbarFile.setSelected(ini.getProperty("toolbarFile","true").equals("true"));
        miToolbarFont.setSelected(ini.getProperty("toolbarFont","true").equals("true"));
        miToolbarRun.setSelected(ini.getProperty("toolbarRun","false").equals("true"));
        miToolbarUML.setSelected(ini.getProperty("toolbarUML","true").equals("true"));
        //miShowJavadoc.setSelected(ini.getProperty("showComments","true").equals("true"));
        // initial directory name
        diagram.setContainingDirectoryName(ini.getProperty("lastDirename", System.getProperty("user.home")));
        //default encoding
        Unimozer.FILE_ENCODING=ini.getProperty("defaultEncoding",Unimozer.FILE_ENCODING);
        // encoding
        miEncodingUTF8.setSelected(Unimozer.FILE_ENCODING.equals("UTF-8"));
        miEncodingWindows1252.setSelected(Unimozer.FILE_ENCODING.equals("windows-1252"));
        // window
        int top = Integer.valueOf(ini.getProperty("top","0")).intValue();
        int left = Integer.valueOf(ini.getProperty("left","0")).intValue();
        int width = Integer.valueOf(ini.getProperty("width","750")).intValue();
        int height = Integer.valueOf(ini.getProperty("height","550")).intValue();
        setPreferredSize(new Dimension(width,height));
        setSize(width,height);
        setLocation(new Point(top,left));
        validate();

        // sliders
        splitty_1.setDividerLocation(Integer.valueOf(ini.getProperty("splitty_1", "350")));
        splitty_2.setDividerLocation(Integer.valueOf(ini.getProperty("splitty_2", "500")));
        splitty_3.setDividerLocation(Integer.valueOf(ini.getProperty("splitty_3", "400")));
        splitty_4.setDividerLocation(Integer.valueOf(ini.getProperty("splitty_4", "400")));


        updateToolbars();

        setTitleNew();
    }

    /*
    public boolean showComments()
    {
        return miShowJavadoc.isSelected();
    }
    */

    public Diagram getDiagram()
    {
        return diagram;
    }

    public void setCanSave()
    {
        speSave.setEnabled(true);
        miSave.setEnabled(true);

        setTitleNew();
    }

    public void setButtons(boolean b)
    {
        b = b && miAllowEdit.isSelected();

        diagram.setAllowEdit(miAllowEdit.isSelected());

        speAddField.setEnabled(b);
        speAddConstructor.setEnabled(b);
        speAddMethod.setEnabled(b);

        miAddField.setEnabled(b);
        miAddConstructor.setEnabled(b);
        miAddMethod.setEnabled(b);

        setTitleNew();
    }

    public void setTitleNew()
    {
        if(diagram.getDirectoryName()!=null)
        {
            String name = diagram.getDirectoryName();
            name = name.substring(name.lastIndexOf('/')+1).trim(); 
            if(diagram.isChanged()) name+=" [changed]";

            this.setTitle(Unimozer.E_NAME+" - "+name);
        }
        else this.setTitle(Unimozer.E_NAME+" - [new]");
    }

/*
    private void addField()
    {
        MyClass mc = diagram.getSelectedClass();
        if (mc!=null)
        {
            FieldEditor fe = FieldEditor.showModal(this, "Add a new class");
            if (fe.OK==true)
            {
                mc.addField(fe.getFieldType(),fe.getFieldName(),fe.getModifier());
                diagram.selectClass(mc);
            }
        }
    }

    private void addConstructor()
    {
        MyClass mc = diagram.getSelectedClass();
        if (mc!=null)
        {
            ConstructorEditor ce = ConstructorEditor.showModal(this, "Add a new constructor");
            if (ce.OK==true)
            {
                mc.addConstructor(ce.getModifier(),ce.getParams());
                diagram.selectClass(mc);
            }
        }
    }

    private void addMethod()
    {
        MyClass mc = diagram.getSelectedClass();
        if (mc!=null)
        {
            MethodEditor me = MethodEditor.showModal(this,"Add a new method");
            if (me.OK==true)
            {
                mc.addMethod(me.getMethodType(),me.getMethodName(),me.getModifier(), me.getParams());
                diagram.selectClass(mc);
            }
        }
    }
*/
    public void setAllowEdit(boolean b)
    {
        miAllowEdit.setSelected(b);
    }

    public void setRelations(boolean heritage, boolean composition, boolean aggregation)
    {
        miShowHeritage.setSelected(heritage);
        miShowComposition.setSelected(composition);
        miShowAggregation.setSelected(aggregation);
        updateDiagramElements();
    }

    private void updateDiagramElements()
    {
        diagram.setShowHeritage(miShowHeritage.isSelected());
        diagram.setShowComposition(miShowComposition.isSelected());
        diagram.setShowAggregation(miShowAggregation.isSelected());
        diagram.repaint();
    }

    private void updateToolbars()
    {
        this.getContentPane().remove(tbFile);
        this.getContentPane().remove(tbMake);
        this.getContentPane().remove(tbElements);
        this.getContentPane().remove(tbFontSize);

        if(miToolbarFile.isSelected())
        {
            this.getContentPane().add(tbFile,AKDockLayout.NORTH);
        }
        if(miToolbarRun.isSelected())
        {
            this.getContentPane().add(tbMake,AKDockLayout.NORTH);
        }
        if(miToolbarUML.isSelected())
        {
            this.getContentPane().add(tbElements,AKDockLayout.NORTH);
        }
        if(miToolbarFont.isSelected())
        {
            this.getContentPane().add(tbFontSize,AKDockLayout.NORTH);
        }
        this.getContentPane().repaint();
    }


    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */ 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        outPopup = new javax.swing.JPopupMenu();
        popClear = new javax.swing.JMenuItem();
        tbElements = new javax.swing.JToolBar();
        speAddClass = new javax.swing.JButton();
        speAddConstructor = new javax.swing.JButton();
        speAddMethod = new javax.swing.JButton();
        speAddField = new javax.swing.JButton();
        pnlBody = new javax.swing.JPanel();
        splitty_1 = new javax.swing.JSplitPane();
        splitty_4 = new javax.swing.JSplitPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        console = new lu.fisch.unimozer.console.Console();
        splitty_2 = new javax.swing.JSplitPane();
        jPanel1 = new javax.swing.JPanel();
        lblStatus = new javax.swing.JLabel();
        codeEditor = new lu.fisch.unimozer.CodeEditor();
        spNSD = new javax.swing.JScrollPane();
        splitty_3 = new javax.swing.JSplitPane();
        objectizer = new lu.fisch.unimozer.Objectizer();
        scrollDiagram = new javax.swing.JScrollPane();
        diagram = new lu.fisch.unimozer.Diagram();
        tbFile = new javax.swing.JToolBar();
        speNew = new javax.swing.JButton();
        speOpen = new javax.swing.JButton();
        speSave = new javax.swing.JButton();
        tbMake = new javax.swing.JToolBar();
        speRun = new javax.swing.JButton();
        speCommand = new javax.swing.JButton();
        speCompile = new javax.swing.JButton();
        speMake = new javax.swing.JButton();
        speJar = new javax.swing.JButton();
        speJavaDoc = new javax.swing.JButton();
        speClean = new javax.swing.JButton();
        tbFontSize = new javax.swing.JToolBar();
        speFontDown = new javax.swing.JButton();
        speFontUp = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        mFile = new javax.swing.JMenu();
        miNew = new javax.swing.JMenuItem();
        miOpen = new javax.swing.JMenuItem();
        miSave = new javax.swing.JMenuItem();
        miSaveAs = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        miPrintDiagram = new javax.swing.JMenuItem();
        jSeparator7 = new javax.swing.JPopupMenu.Separator();
        miQuit = new javax.swing.JMenuItem();
        mProject = new javax.swing.JMenu();
        miRun = new javax.swing.JMenuItem();
        miCommand = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JSeparator();
        miCompile = new javax.swing.JMenuItem();
        miMake = new javax.swing.JMenuItem();
        miJar = new javax.swing.JMenuItem();
        miJavaDoc = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JSeparator();
        miClean = new javax.swing.JMenuItem();
        mEdit = new javax.swing.JMenu();
        miClipboardPNG = new javax.swing.JMenuItem();
        mView = new javax.swing.JMenu();
        miToolbars = new javax.swing.JMenu();
        miToolbarFile = new javax.swing.JCheckBoxMenuItem();
        miToolbarUML = new javax.swing.JCheckBoxMenuItem();
        miToolbarRun = new javax.swing.JCheckBoxMenuItem();
        miToolbarFont = new javax.swing.JCheckBoxMenuItem();
        miDiagramStandard = new javax.swing.JMenu();
        miDiagramStandardUML = new javax.swing.JCheckBoxMenuItem();
        miDiagramStandardJava = new javax.swing.JCheckBoxMenuItem();
        mDiagram = new javax.swing.JMenu();
        miAllowEdit = new javax.swing.JCheckBoxMenuItem();
        jSeparator6 = new javax.swing.JSeparator();
        miAddClass = new javax.swing.JMenuItem();
        miAddConstructor = new javax.swing.JMenuItem();
        miAddMethod = new javax.swing.JMenuItem();
        miAddField = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        miShowHide = new javax.swing.JMenu();
        miShowHeritage = new javax.swing.JCheckBoxMenuItem();
        miShowComposition = new javax.swing.JCheckBoxMenuItem();
        miShowAggregation = new javax.swing.JCheckBoxMenuItem();
        jSeparator5 = new javax.swing.JSeparator();
        miExportPNG = new javax.swing.JMenuItem();
        mOptions = new javax.swing.JMenu();
        miEncoding = new javax.swing.JMenu();
        miEncodingUTF8 = new javax.swing.JRadioButtonMenuItem();
        miEncodingWindows1252 = new javax.swing.JRadioButtonMenuItem();
        mHelp = new javax.swing.JMenu();
        miAbout = new javax.swing.JMenuItem();

        popClear.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/gen_clear.png"))); // NOI18N
        popClear.setText("Clear");
        popClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                popClearActionPerformed(evt);
            }
        });
        outPopup.add(popClear);

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        tbElements.setRollover(true);

        speAddClass.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_class.png"))); // NOI18N
        speAddClass.setToolTipText("Add a class ...");
        speAddClass.setFocusable(false);
        speAddClass.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speAddClass.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speAddClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speAddClassActionPerformed(evt);
            }
        });
        tbElements.add(speAddClass);

        speAddConstructor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_constructor.png"))); // NOI18N
        speAddConstructor.setToolTipText("Add a constructor ...");
        speAddConstructor.setEnabled(false);
        speAddConstructor.setFocusable(false);
        speAddConstructor.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speAddConstructor.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speAddConstructor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speAddConstructorActionPerformed(evt);
            }
        });
        tbElements.add(speAddConstructor);

        speAddMethod.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_method.png"))); // NOI18N
        speAddMethod.setToolTipText("Add a method ...");
        speAddMethod.setEnabled(false);
        speAddMethod.setFocusable(false);
        speAddMethod.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speAddMethod.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speAddMethod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speAddMethodActionPerformed(evt);
            }
        });
        tbElements.add(speAddMethod);

        speAddField.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_field.png"))); // NOI18N
        speAddField.setToolTipText("Add a field ...");
        speAddField.setEnabled(false);
        speAddField.setFocusable(false);
        speAddField.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speAddField.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speAddField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speAddFieldActionPerformed(evt);
            }
        });
        tbElements.add(speAddField);

        pnlBody.setBackground(new java.awt.Color(204, 255, 204));

        splitty_1.setDividerLocation(350);
        splitty_1.setResizeWeight(0.7);
        splitty_1.setContinuousLayout(true);

        splitty_4.setDividerLocation(400);
        splitty_4.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
        splitty_4.setResizeWeight(1.0);

        console.setColumns(20);
        console.setRows(5);
        console.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                consoleMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(console);

        splitty_4.setRightComponent(jScrollPane1);

        splitty_2.setDividerLocation(600);
        splitty_2.setResizeWeight(1.0);

        jPanel1.setLayout(new java.awt.BorderLayout());

        lblStatus.setText("...");
        lblStatus.setOpaque(true);
        jPanel1.add(lblStatus, java.awt.BorderLayout.PAGE_END);
        jPanel1.add(codeEditor, java.awt.BorderLayout.CENTER);

        splitty_2.setLeftComponent(jPanel1);

        spNSD.setMinimumSize(new java.awt.Dimension(0, 0));
        splitty_2.setRightComponent(spNSD);

        splitty_4.setLeftComponent(splitty_2);

        splitty_1.setRightComponent(splitty_4);

        splitty_3.setDividerLocation(400);
        splitty_3.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
        splitty_3.setResizeWeight(1.0);
        splitty_3.setContinuousLayout(true);

        objectizer.setDiagram(diagram);

        org.jdesktop.layout.GroupLayout objectizerLayout = new org.jdesktop.layout.GroupLayout(objectizer);
        objectizer.setLayout(objectizerLayout);
        objectizerLayout.setHorizontalGroup(
            objectizerLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 344, Short.MAX_VALUE)
        );
        objectizerLayout.setVerticalGroup(
            objectizerLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 107, Short.MAX_VALUE)
        );

        splitty_3.setRightComponent(objectizer);

        diagram.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                diagramComponentResized(evt);
            }
        });

        org.jdesktop.layout.GroupLayout diagramLayout = new org.jdesktop.layout.GroupLayout(diagram);
        diagram.setLayout(diagramLayout);
        diagramLayout.setHorizontalGroup(
            diagramLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 340, Short.MAX_VALUE)
        );
        diagramLayout.setVerticalGroup(
            diagramLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 394, Short.MAX_VALUE)
        );

        scrollDiagram.setViewportView(diagram);

        splitty_3.setLeftComponent(scrollDiagram);

        splitty_1.setLeftComponent(splitty_3);

        org.jdesktop.layout.GroupLayout pnlBodyLayout = new org.jdesktop.layout.GroupLayout(pnlBody);
        pnlBody.setLayout(pnlBodyLayout);
        pnlBodyLayout.setHorizontalGroup(
            pnlBodyLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, splitty_1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 866, Short.MAX_VALUE)
        );
        pnlBodyLayout.setVerticalGroup(
            pnlBodyLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(splitty_1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 522, Short.MAX_VALUE)
        );

        tbFile.setRollover(true);

        speNew.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/gen_new_project.png"))); // NOI18N
        speNew.setToolTipText("Create a new project ...");
        speNew.setFocusable(false);
        speNew.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speNew.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speNewActionPerformed(evt);
            }
        });
        tbFile.add(speNew);

        speOpen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/gen_open_project.png"))); // NOI18N
        speOpen.setToolTipText("Open an existing project ...");
        speOpen.setFocusable(false);
        speOpen.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speOpen.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speOpenActionPerformed(evt);
            }
        });
        tbFile.add(speOpen);

        speSave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/gen_save.png"))); // NOI18N
        speSave.setToolTipText("Save the current project");
        speSave.setEnabled(false);
        speSave.setFocusable(false);
        speSave.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speSave.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speSaveActionPerformed(evt);
            }
        });
        tbFile.add(speSave);

        tbMake.setRollover(true);

        speRun.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/netbeans_run.png"))); // NOI18N
        speRun.setToolTipText("Run the project's main class.");
        speRun.setFocusable(false);
        speRun.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speRun.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speRun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speRunActionPerformed(evt);
            }
        });
        tbMake.add(speRun);

        speCommand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/iconfinder_command_gpl_gnome_project.png"))); // NOI18N
        speCommand.setToolTipText("Execute a command ...");
        speCommand.setFocusable(false);
        speCommand.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speCommand.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speCommand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speCommandActionPerformed(evt);
            }
        });
        tbMake.add(speCommand);

        speCompile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/gen_proc.png"))); // NOI18N
        speCompile.setToolTipText("Compile all classes in memory.");
        speCompile.setFocusable(false);
        speCompile.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speCompile.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speCompile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speCompileActionPerformed(evt);
            }
        });
        tbMake.add(speCompile);

        speMake.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/java_make.png"))); // NOI18N
        speMake.setToolTipText("Write class files to the disk.");
        speMake.setFocusable(false);
        speMake.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speMake.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speMake.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speMakeActionPerformed(evt);
            }
        });
        tbMake.add(speMake);

        speJar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/netbeans_build.png"))); // NOI18N
        speJar.setToolTipText("Create JAR bundle ...");
        speJar.setFocusable(false);
        speJar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speJar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speJar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speJarActionPerformed(evt);
            }
        });
        tbMake.add(speJar);

        speJavaDoc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/iconfinder_doc_lgpl_david_vignoni.png"))); // NOI18N
        speJavaDoc.setToolTipText("Create Java-DOC");
        speJavaDoc.setFocusable(false);
        speJavaDoc.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speJavaDoc.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speJavaDoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speJavaDocActionPerformed(evt);
            }
        });
        tbMake.add(speJavaDoc);

        speClean.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/netbeans_clean.png"))); // NOI18N
        speClean.setToolTipText("Delete the compiled files.");
        speClean.setFocusable(false);
        speClean.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speClean.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speClean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speCleanActionPerformed(evt);
            }
        });
        tbMake.add(speClean);

        tbFontSize.setRollover(true);

        speFontDown.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/font_down.png"))); // NOI18N
        speFontDown.setToolTipText("Decrease the font size ...");
        speFontDown.setFocusable(false);
        speFontDown.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speFontDown.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speFontDown.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speFontDownActionPerformed(evt);
            }
        });
        tbFontSize.add(speFontDown);

        speFontUp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/font_up.png"))); // NOI18N
        speFontUp.setToolTipText("Increase the font size ...");
        speFontUp.setFocusable(false);
        speFontUp.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        speFontUp.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        speFontUp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                speFontUpActionPerformed(evt);
            }
        });
        tbFontSize.add(speFontUp);

        mFile.setText("File");

        miNew.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/gen_new_project.png"))); // NOI18N
        miNew.setText("New");
        miNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miNewActionPerformed(evt);
            }
        });
        mFile.add(miNew);

        miOpen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/gen_open_project.png"))); // NOI18N
        miOpen.setText("Open ...");
        miOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miOpenActionPerformed(evt);
            }
        });
        mFile.add(miOpen);

        miSave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/gen_save.png"))); // NOI18N
        miSave.setText("Save");
        miSave.setEnabled(false);
        miSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miSaveActionPerformed(evt);
            }
        });
        mFile.add(miSave);

        miSaveAs.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/gen_save.png"))); // NOI18N
        miSaveAs.setText("Save as ...");
        miSaveAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miSaveAsActionPerformed(evt);
            }
        });
        mFile.add(miSaveAs);
        mFile.add(jSeparator2);

        miPrintDiagram.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/print.png"))); // NOI18N
        miPrintDiagram.setText("Print ...");
        miPrintDiagram.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miPrintDiagramActionPerformed(evt);
            }
        });
        mFile.add(miPrintDiagram);
        mFile.add(jSeparator7);

        miQuit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        miQuit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/gen_run.png"))); // NOI18N
        miQuit.setText("Quit");
        miQuit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miQuitActionPerformed(evt);
            }
        });
        mFile.add(miQuit);

        jMenuBar1.add(mFile);

        mProject.setText("Project");

        miRun.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/netbeans_run.png"))); // NOI18N
        miRun.setText("Run");
        miRun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miRunActionPerformed(evt);
            }
        });
        mProject.add(miRun);

        miCommand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/iconfinder_command_gpl_gnome_project.png"))); // NOI18N
        miCommand.setText("Command");
        miCommand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miCommandActionPerformed(evt);
            }
        });
        mProject.add(miCommand);
        mProject.add(jSeparator4);

        miCompile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/gen_proc.png"))); // NOI18N
        miCompile.setText("Compile");
        miCompile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miCompileActionPerformed(evt);
            }
        });
        mProject.add(miCompile);

        miMake.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/java_make.png"))); // NOI18N
        miMake.setText("Make");
        miMake.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miMakeActionPerformed(evt);
            }
        });
        mProject.add(miMake);

        miJar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/netbeans_build.png"))); // NOI18N
        miJar.setText("Create JAR");
        miJar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miJarActionPerformed(evt);
            }
        });
        mProject.add(miJar);

        miJavaDoc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/iconfinder_doc_lgpl_david_vignoni.png"))); // NOI18N
        miJavaDoc.setText("Create JavaDoc");
        miJavaDoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miJavaDocActionPerformed(evt);
            }
        });
        mProject.add(miJavaDoc);
        mProject.add(jSeparator3);

        miClean.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/netbeans_clean.png"))); // NOI18N
        miClean.setText("Clean");
        miClean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miCleanActionPerformed(evt);
            }
        });
        mProject.add(miClean);

        jMenuBar1.add(mProject);

        mEdit.setText("Edit");

        miClipboardPNG.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/export_image.png"))); // NOI18N
        miClipboardPNG.setText("Copy diagram");
        miClipboardPNG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miClipboardPNGActionPerformed(evt);
            }
        });
        mEdit.add(miClipboardPNG);

        jMenuBar1.add(mEdit);

        mView.setText("View");

        miToolbars.setText("Toolbars");

        miToolbarFile.setSelected(true);
        miToolbarFile.setText("File");
        miToolbarFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miToolbarFileActionPerformed(evt);
            }
        });
        miToolbars.add(miToolbarFile);

        miToolbarUML.setSelected(true);
        miToolbarUML.setText("UML");
        miToolbarUML.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miToolbarUMLActionPerformed(evt);
            }
        });
        miToolbars.add(miToolbarUML);

        miToolbarRun.setSelected(true);
        miToolbarRun.setText("Run");
        miToolbarRun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miToolbarRunActionPerformed(evt);
            }
        });
        miToolbars.add(miToolbarRun);

        miToolbarFont.setSelected(true);
        miToolbarFont.setText("Font");
        miToolbarFont.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miToolbarFontActionPerformed(evt);
            }
        });
        miToolbars.add(miToolbarFont);

        mView.add(miToolbars);

        miDiagramStandard.setText("Diagram standard");

        miDiagramStandardUML.setSelected(true);
        miDiagramStandardUML.setText("UML");
        miDiagramStandardUML.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aDiagramStandardUML(evt);
            }
        });
        miDiagramStandard.add(miDiagramStandardUML);

        miDiagramStandardJava.setText("Java");
        miDiagramStandardJava.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aDiagramStandardJava(evt);
            }
        });
        miDiagramStandard.add(miDiagramStandardJava);

        mView.add(miDiagramStandard);

        jMenuBar1.add(mView);

        mDiagram.setText("Diagram");

        miAllowEdit.setSelected(true);
        miAllowEdit.setText("Allow editing");
        miAllowEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miAllowEditActionPerformed(evt);
            }
        });
        mDiagram.add(miAllowEdit);
        mDiagram.add(jSeparator6);

        miAddClass.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_class.png"))); // NOI18N
        miAddClass.setText("Add class ...");
        miAddClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miAddClassActionPerformed(evt);
            }
        });
        mDiagram.add(miAddClass);

        miAddConstructor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_constructor.png"))); // NOI18N
        miAddConstructor.setText("Add constructor ...");
        miAddConstructor.setEnabled(false);
        miAddConstructor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miAddConstructorActionPerformed(evt);
            }
        });
        mDiagram.add(miAddConstructor);

        miAddMethod.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_method.png"))); // NOI18N
        miAddMethod.setText("Add method ...");
        miAddMethod.setEnabled(false);
        miAddMethod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miAddMethodActionPerformed(evt);
            }
        });
        mDiagram.add(miAddMethod);

        miAddField.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/uml_field.png"))); // NOI18N
        miAddField.setText("Add field ...");
        miAddField.setEnabled(false);
        miAddField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miAddFieldActionPerformed(evt);
            }
        });
        mDiagram.add(miAddField);
        mDiagram.add(jSeparator1);

        miShowHide.setText("Show / hide elements");

        miShowHeritage.setSelected(true);
        miShowHeritage.setText("Heritage");
        miShowHeritage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miShowHeritageActionPerformed(evt);
            }
        });
        miShowHide.add(miShowHeritage);

        miShowComposition.setSelected(true);
        miShowComposition.setText("Composition");
        miShowComposition.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miShowCompositionActionPerformed(evt);
            }
        });
        miShowHide.add(miShowComposition);

        miShowAggregation.setSelected(true);
        miShowAggregation.setText("Aggregation");
        miShowAggregation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miShowAggregationActionPerformed(evt);
            }
        });
        miShowHide.add(miShowAggregation);

        mDiagram.add(miShowHide);
        mDiagram.add(jSeparator5);

        miExportPNG.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/export_image.png"))); // NOI18N
        miExportPNG.setText("Export as PNG ...");
        miExportPNG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miExportPNGActionPerformed(evt);
            }
        });
        mDiagram.add(miExportPNG);

        jMenuBar1.add(mDiagram);

        mOptions.setText("Options");

        miEncoding.setText("Encoding");

        miEncodingUTF8.setSelected(true);
        miEncodingUTF8.setText("UTF-8");
        miEncodingUTF8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miEncodingUTF8ActionPerformed(evt);
            }
        });
        miEncoding.add(miEncodingUTF8);

        miEncodingWindows1252.setSelected(true);
        miEncodingWindows1252.setText("windows-1252");
        miEncodingWindows1252.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miEncodingWindows1252ActionPerformed(evt);
            }
        });
        miEncoding.add(miEncodingWindows1252);

        mOptions.add(miEncoding);

        jMenuBar1.add(mOptions);

        mHelp.setText("Help");

        miAbout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu/fisch/icons/ico_turtle.png"))); // NOI18N
        miAbout.setText("About");
        miAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miAboutActionPerformed(evt);
            }
        });
        mHelp.add(miAbout);

        jMenuBar1.add(mHelp);

        setJMenuBar(jMenuBar1);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(12, 12, 12)
                .add(tbElements, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(34, 34, 34)
                .add(tbFile, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(tbMake, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(52, 52, 52)
                .add(tbFontSize, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(238, Short.MAX_VALUE))
            .add(pnlBody, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .addContainerGap()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(tbElements, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(tbFile, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(layout.createSequentialGroup()
                        .add(16, 16, 16)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(tbFontSize, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(tbMake, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .add(47, 47, 47)
                .add(pnlBody, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void speAddClassActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speAddClassActionPerformed
    {//GEN-HEADEREND:event_speAddClassActionPerformed
        diagram.addClass();
    }//GEN-LAST:event_speAddClassActionPerformed

    private void speAddFieldActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speAddFieldActionPerformed
    {//GEN-HEADEREND:event_speAddFieldActionPerformed
        diagram.addField();
    }//GEN-LAST:event_speAddFieldActionPerformed

    private void speAddMethodActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speAddMethodActionPerformed
    {//GEN-HEADEREND:event_speAddMethodActionPerformed
        diagram.addMethod();
}//GEN-LAST:event_speAddMethodActionPerformed

    private void diagramComponentResized(java.awt.event.ComponentEvent evt)//GEN-FIRST:event_diagramComponentResized
    {//GEN-HEADEREND:event_diagramComponentResized
    }//GEN-LAST:event_diagramComponentResized

    private void miAboutActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miAboutActionPerformed
    {//GEN-HEADEREND:event_miAboutActionPerformed
        diagram.about();
    }//GEN-LAST:event_miAboutActionPerformed

    private void miQuitActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miQuitActionPerformed
    {//GEN-HEADEREND:event_miQuitActionPerformed
        formWindowClosing(null);
    }//GEN-LAST:event_miQuitActionPerformed

    private void speAddConstructorActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speAddConstructorActionPerformed
    {//GEN-HEADEREND:event_speAddConstructorActionPerformed
        diagram.addConstructor();
}//GEN-LAST:event_speAddConstructorActionPerformed

    private void speOpenActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speOpenActionPerformed
    {//GEN-HEADEREND:event_speOpenActionPerformed
        diagram.openUnimozer();
        setTitleNew();
}//GEN-LAST:event_speOpenActionPerformed

    private void speNewActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speNewActionPerformed
    {//GEN-HEADEREND:event_speNewActionPerformed
        diagram.newUnimozer();
        setTitleNew();
    }//GEN-LAST:event_speNewActionPerformed

    private void speSaveActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speSaveActionPerformed
    {//GEN-HEADEREND:event_speSaveActionPerformed
        diagram.saveUnimozer();
        setTitleNew();
    }//GEN-LAST:event_speSaveActionPerformed

    private void miNewActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miNewActionPerformed
    {//GEN-HEADEREND:event_miNewActionPerformed
        diagram.newUnimozer();
        setTitleNew();
    }//GEN-LAST:event_miNewActionPerformed

    private void miOpenActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miOpenActionPerformed
    {//GEN-HEADEREND:event_miOpenActionPerformed
        diagram.openUnimozer();
        setTitleNew();
    }//GEN-LAST:event_miOpenActionPerformed

    private void miSaveActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miSaveActionPerformed
    {//GEN-HEADEREND:event_miSaveActionPerformed
        diagram.saveUnimozer();
        setTitleNew();
    }//GEN-LAST:event_miSaveActionPerformed

    private void miSaveAsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miSaveAsActionPerformed
    {//GEN-HEADEREND:event_miSaveAsActionPerformed
        diagram.saveAsUnimozer();
        setTitleNew();
    }//GEN-LAST:event_miSaveAsActionPerformed

    private void miAddClassActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miAddClassActionPerformed
    {//GEN-HEADEREND:event_miAddClassActionPerformed
        diagram.addClass();
    }//GEN-LAST:event_miAddClassActionPerformed

    private void miAddFieldActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miAddFieldActionPerformed
    {//GEN-HEADEREND:event_miAddFieldActionPerformed
        if(miAllowEdit.isSelected()) diagram.addField();
    }//GEN-LAST:event_miAddFieldActionPerformed

    private void miAddConstructorActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miAddConstructorActionPerformed
    {//GEN-HEADEREND:event_miAddConstructorActionPerformed
        if(miAllowEdit.isSelected()) diagram.addConstructor();
    }//GEN-LAST:event_miAddConstructorActionPerformed

    private void miAddMethodActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miAddMethodActionPerformed
    {//GEN-HEADEREND:event_miAddMethodActionPerformed
        if(miAllowEdit.isSelected()) diagram.addMethod();
    }//GEN-LAST:event_miAddMethodActionPerformed

    private void miExportPNGActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miExportPNGActionPerformed
    {//GEN-HEADEREND:event_miExportPNGActionPerformed
        diagram.exportPNG();
    }//GEN-LAST:event_miExportPNGActionPerformed

    private void miClipboardPNGActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miClipboardPNGActionPerformed
    {//GEN-HEADEREND:event_miClipboardPNGActionPerformed
        diagram.copyToClipboardPNG();
    }//GEN-LAST:event_miClipboardPNGActionPerformed

    private void popClearActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_popClearActionPerformed
    {//GEN-HEADEREND:event_popClearActionPerformed
        console.clear();
}//GEN-LAST:event_popClearActionPerformed

    private void formWindowClosed(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosed
    {//GEN-HEADEREND:event_formWindowClosed
    }//GEN-LAST:event_formWindowClosed

    private void miCompileActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miCompileActionPerformed
    {//GEN-HEADEREND:event_miCompileActionPerformed
        console.clear();
        diagram.compile(null);
    }//GEN-LAST:event_miCompileActionPerformed

    private void miMakeActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miMakeActionPerformed
    {//GEN-HEADEREND:event_miMakeActionPerformed
        console.clear();
        diagram.make();
    }//GEN-LAST:event_miMakeActionPerformed

    private void speCompileActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speCompileActionPerformed
    {//GEN-HEADEREND:event_speCompileActionPerformed
        console.clear();
        diagram.compile(null);
}//GEN-LAST:event_speCompileActionPerformed

    private void speMakeActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speMakeActionPerformed
    {//GEN-HEADEREND:event_speMakeActionPerformed
        console.clear();
        diagram.make();
}//GEN-LAST:event_speMakeActionPerformed

    private void miJarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miJarActionPerformed
    {//GEN-HEADEREND:event_miJarActionPerformed
       diagram.jar();
    }//GEN-LAST:event_miJarActionPerformed

    private void speJarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speJarActionPerformed
    {//GEN-HEADEREND:event_speJarActionPerformed
        diagram.jar();
}//GEN-LAST:event_speJarActionPerformed

    private void speRunActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speRunActionPerformed
    {//GEN-HEADEREND:event_speRunActionPerformed
        diagram.run();
}//GEN-LAST:event_speRunActionPerformed

    private void miRunActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miRunActionPerformed
    {//GEN-HEADEREND:event_miRunActionPerformed
        diagram.run();
    }//GEN-LAST:event_miRunActionPerformed

    private void speCleanActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speCleanActionPerformed
    {//GEN-HEADEREND:event_speCleanActionPerformed
        diagram.clean();
}//GEN-LAST:event_speCleanActionPerformed

    private void miCleanActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miCleanActionPerformed
    {//GEN-HEADEREND:event_miCleanActionPerformed
        diagram.clean();
    }//GEN-LAST:event_miCleanActionPerformed

    private void miToolbarFileActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miToolbarFileActionPerformed
    {//GEN-HEADEREND:event_miToolbarFileActionPerformed
        updateToolbars();
    }//GEN-LAST:event_miToolbarFileActionPerformed

    private void miToolbarUMLActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miToolbarUMLActionPerformed
    {//GEN-HEADEREND:event_miToolbarUMLActionPerformed
        updateToolbars();
    }//GEN-LAST:event_miToolbarUMLActionPerformed

    private void miToolbarRunActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miToolbarRunActionPerformed
    {//GEN-HEADEREND:event_miToolbarRunActionPerformed
        updateToolbars();
    }//GEN-LAST:event_miToolbarRunActionPerformed

    private void speCommandActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speCommandActionPerformed
    {//GEN-HEADEREND:event_speCommandActionPerformed
        diagram.command();
}//GEN-LAST:event_speCommandActionPerformed

    private void miCommandActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miCommandActionPerformed
    {//GEN-HEADEREND:event_miCommandActionPerformed
        diagram.command();
    }//GEN-LAST:event_miCommandActionPerformed

    private void miShowHeritageActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miShowHeritageActionPerformed
    {//GEN-HEADEREND:event_miShowHeritageActionPerformed
        updateDiagramElements();
}//GEN-LAST:event_miShowHeritageActionPerformed

    private void miShowAggregationActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miShowAggregationActionPerformed
    {//GEN-HEADEREND:event_miShowAggregationActionPerformed
        updateDiagramElements();
}//GEN-LAST:event_miShowAggregationActionPerformed

    private void miShowCompositionActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miShowCompositionActionPerformed
    {//GEN-HEADEREND:event_miShowCompositionActionPerformed
        updateDiagramElements();
}//GEN-LAST:event_miShowCompositionActionPerformed

    private void speJavaDocActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speJavaDocActionPerformed
    {//GEN-HEADEREND:event_speJavaDocActionPerformed
        diagram.javadoc();
}//GEN-LAST:event_speJavaDocActionPerformed

    private void miJavaDocActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miJavaDocActionPerformed
    {//GEN-HEADEREND:event_miJavaDocActionPerformed
        diagram.javadoc();
}//GEN-LAST:event_miJavaDocActionPerformed

    private void miAllowEditActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miAllowEditActionPerformed
    {//GEN-HEADEREND:event_miAllowEditActionPerformed
        //name = JOptionPane.showInputDialog(frame, "Please enter the name for you new instance of “"+mouseClass.getShortName()+"“", "Create object", JOptionPane.QUESTION_MESSAGE);
        if(miAllowEdit.isSelected()==true)
        { // ugeschallt
            int res = JOptionPane.showConfirmDialog(this,
                                          "You have activated to edit the diagram directely.\n"+
                                          "This means that your source code will be parsed and\n"+
                                          "rebuild and thus that a lot of comments will probably\n"+
                                          "be lost!\n"+
                                          "\n"+
                                          "Do you still want to conitnue?",
                                          "Allow editing the diagram?",
                                          JOptionPane.YES_NO_OPTION,
                                          JOptionPane.QUESTION_MESSAGE
                                          );
           if(res==JOptionPane.NO_OPTION) miAllowEdit.setSelected(false);
        }
        else
        { // ausgeschallt
            int res = JOptionPane.showConfirmDialog(this,
                                          "You have disabled the direct diagram editor. This allows\n"+
                                          "you to add more comments inside your source code but you\n"+
                                          "can no longer edit the diagram directly.\n"+
                                          "\n"+
                                          "Once this options is activated for a project, it is heavily\n"+
                                          "recommended to not switch it on again!\n"+
                                          "\n"+
                                          "Do you still want to conitnue?",
                                          "Allow editing the diagram?",
                                          JOptionPane.YES_NO_OPTION,
                                          JOptionPane.QUESTION_MESSAGE
                                          );
           if(res==JOptionPane.NO_OPTION) miAllowEdit.setSelected(true);
        }
        setButtons(speAddClass.isEnabled());
    }//GEN-LAST:event_miAllowEditActionPerformed

    private void speFontDownActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speFontDownActionPerformed
    {//GEN-HEADEREND:event_speFontDownActionPerformed
       if(Unimozer.DRAW_FONT_SIZE>10) Unimozer.DRAW_FONT_SIZE--;
       diagram.repaint();
}//GEN-LAST:event_speFontDownActionPerformed

    private void speFontUpActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_speFontUpActionPerformed
    {//GEN-HEADEREND:event_speFontUpActionPerformed
       if(Unimozer.DRAW_FONT_SIZE<15) Unimozer.DRAW_FONT_SIZE++;
       diagram.repaint();
}//GEN-LAST:event_speFontUpActionPerformed

    private void miToolbarFontActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miToolbarFontActionPerformed
    {//GEN-HEADEREND:event_miToolbarFontActionPerformed
        updateToolbars();
}//GEN-LAST:event_miToolbarFontActionPerformed

    private void aDiagramStandardUML(java.awt.event.ActionEvent evt)//GEN-FIRST:event_aDiagramStandardUML
    {//GEN-HEADEREND:event_aDiagramStandardUML
        miDiagramStandardUML.setSelected(true);
        miDiagramStandardJava.setSelected(false);
        diagram.setUML(true);
        diagram.repaint();
    }//GEN-LAST:event_aDiagramStandardUML

    private void aDiagramStandardJava(java.awt.event.ActionEvent evt)//GEN-FIRST:event_aDiagramStandardJava
    {//GEN-HEADEREND:event_aDiagramStandardJava
        miDiagramStandardUML.setSelected(false);
        miDiagramStandardJava.setSelected(true);
        diagram.setUML(false);
        diagram.repaint();
    }//GEN-LAST:event_aDiagramStandardJava

    private void formWindowClosing(java.awt.event.WindowEvent evt)//GEN-FIRST:event_formWindowClosing
    {//GEN-HEADEREND:event_formWindowClosing
        /*
         * Save settings to the INI file
         */
        try
        {
            objectizer.removeAllObjects();
            Ini ini = Ini.getInstance();
            ini.load();
            ini.setProperty("umlStandard", Boolean.toString(diagram.isUML()));
            ini.setProperty("toolbarFile", Boolean.toString(miToolbarFile.isSelected()));
            ini.setProperty("toolbarFont", Boolean.toString(miToolbarFont.isSelected()));
            ini.setProperty("toolbarRun", Boolean.toString(miToolbarRun.isSelected()));
            ini.setProperty("toolbarUML", Boolean.toString(miToolbarUML.isSelected()));
            //ini.setProperty("showComments", Boolean.toString(miShowJavadoc.isSelected()));
            ini.setProperty("lastDirename", diagram.getContainingDirectoryName());
            ini.setProperty("defaultEncoding", Unimozer.FILE_ENCODING);
            // window
            // position
            ini.setProperty("top",Integer.toString(getLocationOnScreen().x));
            ini.setProperty("left",Integer.toString(getLocationOnScreen().y));
            ini.setProperty("width",Integer.toString(getWidth()));
            ini.setProperty("height",Integer.toString(getHeight()));
            // sliders
            ini.setProperty("splitty_1",Integer.toString(splitty_1.getDividerLocation()));
            ini.setProperty("splitty_2",Integer.toString(splitty_2.getDividerLocation()));
            ini.setProperty("splitty_3",Integer.toString(splitty_3.getDividerLocation()));
            ini.setProperty("splitty_4",Integer.toString(splitty_4.getDividerLocation()));

            ini.save();
        }
        catch (FileNotFoundException ex)
        {
            ex.printStackTrace();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }

        /*
         * Save diagram?
         */
        if(diagram.isChanged())
        {
            if(diagram.askToSave()) System.exit(0);
        }
        else System.exit(0);

    }//GEN-LAST:event_formWindowClosing
 
    public Console getConsole()
    {
        return console;
    }

    private void consoleMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_consoleMouseClicked
    {//GEN-HEADEREND:event_consoleMouseClicked
        if(evt.getButton()==MouseEvent.BUTTON3) outPopup.show(console, evt.getX(), evt.getY());
    }//GEN-LAST:event_consoleMouseClicked

    private void miEncodingUTF8ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miEncodingUTF8ActionPerformed
    {//GEN-HEADEREND:event_miEncodingUTF8ActionPerformed
        miEncodingUTF8.setSelected(true);
        miEncodingWindows1252.setSelected(false);
        Unimozer.FILE_ENCODING="UTF-8";
    }//GEN-LAST:event_miEncodingUTF8ActionPerformed

    private void miEncodingWindows1252ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miEncodingWindows1252ActionPerformed
    {//GEN-HEADEREND:event_miEncodingWindows1252ActionPerformed
        miEncodingWindows1252.setSelected(true);
        miEncodingUTF8.setSelected(false);
        Unimozer.FILE_ENCODING="windows-1252";
    }//GEN-LAST:event_miEncodingWindows1252ActionPerformed

    private void miPrintDiagramActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_miPrintDiagramActionPerformed
    {//GEN-HEADEREND:event_miPrintDiagramActionPerformed
        diagram.printDiagram();
    }//GEN-LAST:event_miPrintDiagramActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private lu.fisch.unimozer.CodeEditor codeEditor;
    private lu.fisch.unimozer.console.Console console;
    private lu.fisch.unimozer.Diagram diagram;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JPopupMenu.Separator jSeparator7;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JMenu mDiagram;
    private javax.swing.JMenu mEdit;
    private javax.swing.JMenu mFile;
    private javax.swing.JMenu mHelp;
    private javax.swing.JMenu mOptions;
    private javax.swing.JMenu mProject;
    private javax.swing.JMenu mView;
    private javax.swing.JMenuItem miAbout;
    private javax.swing.JMenuItem miAddClass;
    private javax.swing.JMenuItem miAddConstructor;
    private javax.swing.JMenuItem miAddField;
    private javax.swing.JMenuItem miAddMethod;
    private javax.swing.JCheckBoxMenuItem miAllowEdit;
    private javax.swing.JMenuItem miClean;
    private javax.swing.JMenuItem miClipboardPNG;
    private javax.swing.JMenuItem miCommand;
    private javax.swing.JMenuItem miCompile;
    private javax.swing.JMenu miDiagramStandard;
    private javax.swing.JCheckBoxMenuItem miDiagramStandardJava;
    private javax.swing.JCheckBoxMenuItem miDiagramStandardUML;
    private javax.swing.JMenu miEncoding;
    private javax.swing.JRadioButtonMenuItem miEncodingUTF8;
    private javax.swing.JRadioButtonMenuItem miEncodingWindows1252;
    private javax.swing.JMenuItem miExportPNG;
    private javax.swing.JMenuItem miJar;
    private javax.swing.JMenuItem miJavaDoc;
    private javax.swing.JMenuItem miMake;
    private javax.swing.JMenuItem miNew;
    private javax.swing.JMenuItem miOpen;
    private javax.swing.JMenuItem miPrintDiagram;
    private javax.swing.JMenuItem miQuit;
    private javax.swing.JMenuItem miRun;
    private javax.swing.JMenuItem miSave;
    private javax.swing.JMenuItem miSaveAs;
    private javax.swing.JCheckBoxMenuItem miShowAggregation;
    private javax.swing.JCheckBoxMenuItem miShowComposition;
    private javax.swing.JCheckBoxMenuItem miShowHeritage;
    private javax.swing.JMenu miShowHide;
    private javax.swing.JCheckBoxMenuItem miToolbarFile;
    private javax.swing.JCheckBoxMenuItem miToolbarFont;
    private javax.swing.JCheckBoxMenuItem miToolbarRun;
    private javax.swing.JCheckBoxMenuItem miToolbarUML;
    private javax.swing.JMenu miToolbars;
    private lu.fisch.unimozer.Objectizer objectizer;
    private javax.swing.JPopupMenu outPopup;
    private javax.swing.JPanel pnlBody;
    private javax.swing.JMenuItem popClear;
    private javax.swing.JScrollPane scrollDiagram;
    private javax.swing.JScrollPane spNSD;
    private javax.swing.JButton speAddClass;
    private javax.swing.JButton speAddConstructor;
    private javax.swing.JButton speAddField;
    private javax.swing.JButton speAddMethod;
    private javax.swing.JButton speClean;
    private javax.swing.JButton speCommand;
    private javax.swing.JButton speCompile;
    private javax.swing.JButton speFontDown;
    private javax.swing.JButton speFontUp;
    private javax.swing.JButton speJar;
    private javax.swing.JButton speJavaDoc;
    private javax.swing.JButton speMake;
    private javax.swing.JButton speNew;
    private javax.swing.JButton speOpen;
    private javax.swing.JButton speRun;
    private javax.swing.JButton speSave;
    private javax.swing.JSplitPane splitty_1;
    private javax.swing.JSplitPane splitty_2;
    private javax.swing.JSplitPane splitty_3;
    private javax.swing.JSplitPane splitty_4;
    private javax.swing.JToolBar tbElements;
    private javax.swing.JToolBar tbFile;
    private javax.swing.JToolBar tbFontSize;
    private javax.swing.JToolBar tbMake;
    // End of variables declaration//GEN-END:variables

}
