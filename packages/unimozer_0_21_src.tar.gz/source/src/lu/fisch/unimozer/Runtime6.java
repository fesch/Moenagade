/*
    Unimozer
    Unimozer intends to be a universal modelizer for Java™. It allows the user
    to draw UML diagrams and generates the relative Java™ code automatically
    and vice-versa.

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package lu.fisch.unimozer;

import bsh.Interpreter;
import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaCompiler.CompilationTask;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import lu.fisch.unimozer.compilation.ByteClassLoader;
import lu.fisch.unimozer.compilation.ByteJavaFileManager;
import lu.fisch.unimozer.compilation.JavaSourceFromString;

/**
 *
 * @author robertfisch
 */
public class Runtime6
{
    private JavaCompiler compiler = null;
    private ByteClassLoader classLoader =  null;
    private Interpreter interpreter = new Interpreter();

    protected static Runtime6 runtime = null;

    private Runtime6()
    {
        compiler =  javax.tools.ToolProvider.getSystemJavaCompiler();
    }

    public static Runtime6 getInstance(Interpreter interpreter)
    {
        if (runtime==null) runtime = new Runtime6();
        runtime.interpreter=interpreter;
        return runtime;
    }

    // the input always contains <Classname, Javacode>
    void compileToPath(File[] files, String path, String target) throws ClassNotFoundException
    {
            // create a diagnostic collector to collect eventually errors
            DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<JavaFileObject>();
            // create a standard manager for the Java file objects
            StandardJavaFileManager fileMan = compiler.getStandardFileManager(diagnostics, null, null);

            // create the iterable from the list
            Iterable<? extends JavaFileObject> compilationUnits = fileMan.getJavaFileObjectsFromFiles(Arrays.asList(files));

            // create a store for the compiled code
            Map<String, JavaFileObject> store = new HashMap<String, JavaFileObject>();

            // set compileroptions for target JVM
            //System.err.println(path+"bin/");
            String[] options = new String[]{"-d",path};
            Iterable<String> myOptions = null;
            if(target!=null) 
             {
                options = new String[]{"-d",path,"-source", target,"-target", target};
            }
            myOptions = Arrays.asList(options);
            //for(int i=0;i<options.length;i++) System.err.print(options[i]+" // ");
            // compile the file
            CompilationTask task = compiler.getTask(null, fileMan, diagnostics, myOptions , null, compilationUnits);

            boolean success = task.call();
            String error = new String();
            for (Diagnostic diagnostic : diagnostics.getDiagnostics())
            {
                error+=diagnostic.getMessage(null)+"\n";
            }
            //System.out.println("Success: " + success);
            if(success==true)
            {
                // debug
                //System.out.println("Loading: "+this.getShortName());
                // create the class loader
                classLoader = new ByteClassLoader(store);
                // load the specified class
                //Class<?> cl = classLoader.loadClass(this.getShortName());
            }
            else
            {
                error=error.replaceAll("string:///", "");
                error=error.replaceAll("\\.java", "");
                throw new ClassNotFoundException(error.trim());
            }
    }

    // the input always contains <Classname, Javacode>
    void compile(Hashtable<String, String> codes) throws ClassNotFoundException
    {
            // create a diagnostic collector to collect eventually errors
            DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<JavaFileObject>();
            // get the code for all dependant classes and put it in a list
            JavaFileObject[] sources = new JavaFileObject[codes.size()];
            Set<String> set = codes.keySet();
            Iterator<String> itr = set.iterator();
            int i = 0;
            while (itr.hasNext())
            {
                String filename = itr.next();
                String content = (String) codes.get(filename);
                sources[i]=new JavaSourceFromString(filename, content);
                i++;
            }
            // create the iterable from the list
            Iterable<? extends javax.tools.JavaFileObject> compilationUnits = Arrays.asList(sources);

            // create a store for the compiled code
            Map<String, JavaFileObject> store = new HashMap<String, JavaFileObject>();
            // create a standard manager for the Java file objects
            StandardJavaFileManager fileMan = compiler.getStandardFileManager(diagnostics, null, null);
            //fileMan.getL
            // forward most calls to the standard Java file manager but put the
            // compiled classes into the store with ByteJavaFileManager
            ByteJavaFileManager jfm = new ByteJavaFileManager(fileMan, store);

            // compile the file
            CompilationTask task = compiler.getTask(null, jfm, diagnostics, null, null, compilationUnits);

            boolean success = task.call();
            String error = new String();
            for (Diagnostic diagnostic : diagnostics.getDiagnostics())
            {
              //System.out.println(diagnostic.getCode());
              //System.out.println(diagnostic.getKind());
              //System.out.println(diagnostic.getPosition());
              //System.out.println(diagnostic.getStartPosition());
              //System.out.println(diagnostic.getEndPosition());
                error+=diagnostic.getMessage(null)+"\n";
              //System.out.println(diagnostic.getSource());
              //System.out.println(diagnostic.getMessage(null));
            }
            //System.out.println("Success: " + success);
            if(success==true)
            {
                // debug
                //System.out.println("Loading: "+this.getShortName());
                // create the class loader
                classLoader = new ByteClassLoader(store);
                // load the specified class
                //Class<?> cl = classLoader.loadClass(this.getShortName());
            }
            else
            {
                error=error.replaceAll("string:///", "");
                error=error.replaceAll("\\.java", "");
                throw new ClassNotFoundException(error.trim());
            }
    }

    public Class<?> load(String classname) throws ClassNotFoundException
    {
        try
        {
            interpreter.setClassLoader(classLoader);
            return classLoader.loadClass(classname);
        }
        catch (ClassNotFoundException ex)
        {
            // if a class is not found, it's because it has not been compiled correctely :-(
            if(ex.getCause()==null) throw ex;
            throw new ClassNotFoundException(ex.getCause().getMessage(), ex.getCause());
        }

    }
}
