/*
/*
    Unimozer
    Unimozer intends to be a universal modelizer for Java™. It allows the user
    to draw UML diagrams and generates the relative Java™ code automatically
    and vice-versa.

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package lu.fisch.unimozer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.io.IOException;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rsyntaxtextarea.SyntaxConstants;
import org.fife.ui.rtextarea.RTextScrollPane;

/**
 *
 * @author robertfisch
 */
public class CodeEditor extends JPanel implements KeyListener, MouseMotionListener, DocumentListener, Printable, ActionListener, HyperlinkListener
{
    private RSyntaxTextArea codeArea = null;
    private RTextScrollPane codeAreaScroll = null;
    private long keyTimeout = 0;

    private Diagram diagram = null;
    private CodeCode code = new CodeCode();
    private JLabel status = null;
    private JPanel topPanel = null;
    private JLabel myClassname = null;
    private JComboBox showWhat = null;
    private JTextPane javaDoc = null;
    private JScrollPane javaDocScroll = null;


    public CodeEditor()
    {
        super();
        this.setLayout(new BorderLayout());
        codeArea = new RSyntaxTextArea();
        codeArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_JAVA);
        codeArea.addKeyListener(this);
        codeArea.addMouseMotionListener(this);
        codeArea.setEnabled(false);
        codeArea.setEditable(false);
        codeArea.setTabSize(4);
        codeArea.getDocument().addDocumentListener(this);

        //codeArea.setParser(new JavaParser());
        //codeArea.set

        codeAreaScroll = new RTextScrollPane(codeArea);


        //codeArea.setParser(org.fife.ui.rsyntaxtextarea.Parser));
        //codeArea.setMatchedBracketBGColor(new Color(196,196,0));

        this.add(codeAreaScroll,BorderLayout.CENTER);

        // -- top panel --
        topPanel = new JPanel(new BorderLayout());
        topPanel.setPreferredSize(new Dimension(codeAreaScroll.getWidth(),24));
        topPanel.setBackground(Color.decode("#ffffaa"));

        myClassname = new JLabel();
        myClassname.setFont(new Font(myClassname.getFont().getFontName(),Font.BOLD,myClassname.getFont().getSize()));
        topPanel.add(myClassname,BorderLayout.WEST);

        showWhat = new JComboBox();
        showWhat.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Source Code","Documentation" }));
        showWhat.setEditable(false);
        showWhat.addActionListener(this);
        topPanel.add(showWhat,BorderLayout.EAST);

        this.add(topPanel,BorderLayout.NORTH);

        javaDoc = new JTextPane();
        javaDoc.setContentType("text/html");
        javaDoc.setEditable(false);
        javaDoc.setVisible(true);
        javaDoc.addHyperlinkListener(this);

        javaDocScroll = new JScrollPane(javaDoc);
        javaDocScroll.setVisible(false);
    }

    public void setClassName(String classname)
    {
        if(!classname.trim().equals("")) myClassname.setText(" "+classname+".java");
        else myClassname.setText("");
    }

    public void setDiagram(Diagram diagram)
    {
        this.diagram=diagram;
    }

    @Override
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
        codeArea.setEnabled(b);
        codeArea.setEditable(b);
    }



    public void setCode(String code)
    {
        if(showWhat.getSelectedIndex()!=0) showWhat.setSelectedIndex(0);
        codeArea.setText(code);
        codeArea.setCaretPosition(0);
        setEnabled(true);
    }

    public void focusGained(FocusEvent e)
    {
        //System.out.println("Lost");
    }

    public void focusLost(FocusEvent e)
    {
    }

    public void keyTyped(KeyEvent e)
    {
    }

    public void keyPressed(KeyEvent e)
    {
    }

    public void keyReleased(KeyEvent e)
    {
        /*
        // this block is a bad work-around for the
        // problem that the autoindentation set the
        // caret to a non existing position
        if(e.getKeyCode() == KeyEvent.VK_ENTER)
        {
            //codeArea.convertTabsToSpaces();
        }

        if(diagram!=null)
        {
            MyClass mc = diagram.getSelectedClass();
            if(mc!=null)
            {
                //long isNow = Calendar.getInstance().getTimeInMillis();
                //if(isNow>keyTimeout+1000)
                //{
                    //mc.loadFromString(codeArea.getText());

                    if (
                               (e.getKeyCode()!=KeyEvent.VK_ALT)
                               &&
                               (e.getKeyCode()!=KeyEvent.VK_ALT_GRAPH)
                               &&
                               (e.getKeyCode()!=KeyEvent.VK_CAPS_LOCK)
                               &&
                               (e.getKeyCode()!=KeyEvent.VK_DOWN)
                               &&
                               (e.getKeyCode()!=KeyEvent.VK_UP)
                               &&
                               (e.getKeyCode()!=KeyEvent.VK_LEFT)
                               &&
                               (e.getKeyCode()!=KeyEvent.VK_RIGHT)
                               &&

                       )
                    {

                    }
                    JOptionPane.showMessageDialog(null,e.getKeyCode());
                    // if we hit the "save" button, no change is done!
                
                    if(e.getModifiers()==Toolkit.getDefaultToolkit().getMenuShortcutKeyMask() && e.getKeyCode()==KeyEvent.VK_S)
                    {
                        //JOptionPane.showMessageDialog(null,"Ctrl-S");
                        //diagram.setChanged(false);
                    }
                    else // update from the code in any other situation
                    {
                        getCode().setCode(codeArea.getText());
                        diagram.setEnabled(false);
                        status.setBackground(Color.ORANGE);
                        status.setText("Checking syntax ...");
                        diagram.updateFromCode();
                    }
                    //diagram.loadClassFromString(mc, codeArea.getText());
                    //diagram.clean(mc);
                    //diagram.repaint();
                    //keyTimeout = isNow;
                //}
            }
        }
         /**/
    }

    public void mouseDragged(MouseEvent e)
    {

    }

    public void mouseMoved(MouseEvent e)
    {
        //keyReleased(null);
    }

    /**
     * @return the code
     */
    public CodeCode getCode()
    {
        return code;
    }

    /**
     * @return the status
     */
    public JLabel getStatus()
    {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(JLabel status)
    {
        this.status = status;
    }


    public void insertUpdate(DocumentEvent e)
    {
    }

    public void removeUpdate(DocumentEvent e)
    {
    }

    public void changedUpdate(DocumentEvent e)
    {
        if(diagram!=null)
        {
            MyClass mc = diagram.getSelectedClass();
            if(mc!=null)
            {
                getCode().setCode(codeArea.getText());
                diagram.setEnabled(false);
                status.setBackground(Color.ORANGE);
                status.setText("Checking syntax ...");
                diagram.updateFromCode();
            }
        }
    }

    public int print(Graphics grphcs, PageFormat pf, int i) throws PrinterException
    {
        return codeArea.print(grphcs, pf, i);
    }

    public void actionPerformed(ActionEvent ae)
    {
        if (showWhat.getSelectedIndex()==1 && !myClassname.getText().trim().equals(""))
        {
            if (!javaDocScroll.isVisible())
            if (Unimozer.javaDocDetected)
            {
                status.setText("Generating documentation ...");
                status.repaint();
                this.repaint();

                this.remove(codeAreaScroll);
                this.remove(javaDocScroll);
                codeAreaScroll.setVisible(false);
                this.add(javaDocScroll,BorderLayout.CENTER);
                javaDocScroll.setVisible(true);

                Thread t = diagram.javadoc(false);
                try
                {
                    t.join();
                }
                catch (InterruptedException ex)
                {
                    ex.printStackTrace();
                }
                status.setText("Loading documentation ...");
                status.repaint();
                this.repaint();
                String filename = "file:///"+diagram.getDirectoryName()+System.getProperty("file.separator")+"doc"+System.getProperty("file.separator")+myClassname.getText().trim().replaceAll(".java", ".html");
                try
                {
                    javaDoc.setPage(filename);
                }
                catch (IOException ex)
                {
                    ex.printStackTrace();
                }

                status.setText(" ");
                status.repaint();
            }
            else
            {
                javaDoc.setText("<html><blockquote><h1>Sorry</h1><br>Unimozer was not able to detect a valid JDK installation,<br>so it can't create JavaDoc documentation.</blockquote></html>");
                javaDoc.repaint();

                this.remove(codeAreaScroll);
                this.remove(javaDocScroll);
                codeAreaScroll.setVisible(false);
                this.add(javaDocScroll,BorderLayout.CENTER);
                javaDocScroll.setVisible(true);

            }

            // this is a very bad and ugly tweak to make things drawing correctely!
            Container con = javaDocScroll.getParent();
            while(! (con instanceof JSplitPane)) con=con.getParent();
            ((JSplitPane) con).setDividerLocation(((JSplitPane) con).getDividerLocation());

            javaDocScroll.repaint();
            javaDoc.repaint();
        }
        else if(!codeAreaScroll.isVisible())
        {
            this.remove(codeAreaScroll);
            this.remove(javaDocScroll);
            codeAreaScroll.setVisible(true);
            this.add(codeAreaScroll,BorderLayout.CENTER);
            javaDocScroll.setVisible(false);
            codeAreaScroll.setBounds(javaDocScroll.getBounds());
            codeAreaScroll.setPreferredSize(javaDocScroll.getPreferredSize());

            // this is a very bad and ugly tweak to make things drawing correctely!
            Container con = codeAreaScroll.getParent();
            while(! (con instanceof JSplitPane)) con=con.getParent();
            ((JSplitPane) con).setDividerLocation(((JSplitPane) con).getDividerLocation());

            codeAreaScroll.repaint();
            codeArea.repaint();
        }
    }

    public void hyperlinkUpdate(HyperlinkEvent e)
    {
        HyperlinkEvent.EventType type = e.getEventType();
        if (type == HyperlinkEvent.EventType.ENTERED)
        {
            status.setText(e.getURL().toString());
        }
        else if (type == HyperlinkEvent.EventType.EXITED)
        {
            status.setText(" ");
        }
        else
        {
            ((JTextPane) javaDoc).setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            try
            {
                javaDoc.setPage(e.getURL());
            }
            catch (Exception ex)
            {

            }

        }
    }


 }
