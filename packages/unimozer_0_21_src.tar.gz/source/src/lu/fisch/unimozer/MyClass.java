/*
    Unimozer
    Unimozer intends to be a universal modelizer for Java™. It allows the user
    to draw UML diagrams and generates the relative Java™ code automatically
    and vice-versa.

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package lu.fisch.unimozer;


import japa.parser.ASTHelper;
import japa.parser.JavaParser;
import japa.parser.ParseException;
import japa.parser.ast.CompilationUnit;
import japa.parser.ast.body.ClassOrInterfaceDeclaration;
import japa.parser.ast.body.ConstructorDeclaration;
import japa.parser.ast.body.FieldDeclaration;
import japa.parser.ast.body.MethodDeclaration;
import japa.parser.ast.body.ModifierSet;
import japa.parser.ast.body.Parameter;
import japa.parser.ast.body.TypeDeclaration;
import japa.parser.ast.stmt.BlockStmt;
import japa.parser.ast.type.ClassOrInterfaceType;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Vector;
import lu.fisch.structorizer.elements.Root;
import lu.fisch.unimozer.dialogs.ClassEditor;
import lu.fisch.unimozer.visitors.ClassVisitor;
import lu.fisch.unimozer.visitors.ClassChanger;
import lu.fisch.unimozer.visitors.ConstructorChanger;
import lu.fisch.unimozer.visitors.FieldChanger;
import lu.fisch.unimozer.visitors.FieldVisitor;
import lu.fisch.unimozer.visitors.MethodChanger;
import lu.fisch.unimozer.visitors.MethodVisitor;
import lu.fisch.unimozer.visitors.StructorizerVisitor;
import lu.fisch.unimozer.visitors.UsageVisitor;
import lu.fisch.unimozer.visitors.MyDumpVisitor;
import lu.fisch.utils.StringList;
import org.mozilla.intl.chardet.* ;


/**
 *
 * @author robertfisch
 */
public class MyClass
{
    public static final int PAD = 8;
    public static final String NO_SYNTAX_ERRORS = "No syntax errors";
    
    private CompilationUnit cu;

    private Point position = new Point(0,0);
    private int width = 0;
    private int height = 0;
    private boolean selected = false;
    private boolean compiled = false;

    private MyClass extendsMyClass = null;
    private Vector<MyClass> usesMyClass = new Vector<MyClass>();
    private String extendsClass = new String();

    private Vector<Element> classes = new Vector<Element>();
    //private Vector<Element> constructors = new Vector<Element>();
    private Vector<Element> methods = new Vector<Element>();
    private Vector<Element> fields = new Vector<Element>();
    
    private StringList content = new StringList();

    private lu.fisch.structorizer.gui.Diagram nsd = null;

    private boolean isUML = true;

    /*
    public boolean hasMethod(String name)
    {
        boolean found = false;
        for(int i=0;i<methods.size();i++)
        {
            if( ((MethodDeclaration) methods.get(i).getNode()).getName().equals(name)) found=true;
        }
        return found;
    }
     */

    public MyClass(String name)
    {
        cu = new CompilationUnit();
        // create the type declaration
        ClassOrInterfaceDeclaration type = new ClassOrInterfaceDeclaration(ModifierSet.PUBLIC, false, name);
        ASTHelper.addTypeDeclaration(cu, type);
        content = StringList.explode(getJavaCode(),"\n");
        inspect();
    }

    public MyClass(ClassEditor ce)
    {
        cu = new CompilationUnit();
        // create the type declaration
        ClassOrInterfaceDeclaration type = new ClassOrInterfaceDeclaration(ce.getModifier(), false, ce.getClassName());
        ASTHelper.addTypeDeclaration(cu, type);
        if(!ce.getExtends().equals(""))
        {
            Vector<ClassOrInterfaceType> list = new Vector<ClassOrInterfaceType>();
            list.add(new ClassOrInterfaceType(ce.getExtends()));
            this.setExtendsClass(ce.getExtends());
            type.setExtends(list);
        }
        content = StringList.explode(getJavaCode(),"\n");
        inspect();
    }/**/

    private MyClass(FileInputStream fis) throws FileNotFoundException, ParseException, IOException
    {

        StringBuffer buffer = new StringBuffer();
        Reader in = null;
        try
        {
            InputStreamReader isr = new InputStreamReader(fis,Unimozer.FILE_ENCODING);
            in = new BufferedReader(isr);
            int ch;
            while ((ch = in.read()) > -1)
            {
                buffer.append((char)ch);
            }

            content = StringList.explode(buffer.toString(),"\n");
            cu = JavaParser.parse(new ByteArrayInputStream(getContent().getText().getBytes()));
        }
        finally
        {
            in.close();
        }

        /*
        try
        {
            content = new StringList();
            BufferedReader br = new BufferedReader(new InputStreamReader(in,Charset.));
            String line = br.readLine();
            while(line!=null)
            {
                System.out.println(line);
                content.add(line);
                line = br.readLine();
            }

            cu = JavaParser.parse(new ByteArrayInputStream(content.getText().getBytes()));
            // parse the file
            //cu = JavaParser.parse(in);
        }
        finally
        {
            in.close();
        }
        */
        inspect();
    }

    public MyClass(String filename, String defaultEncoding) throws FileNotFoundException, ParseException, IOException, URISyntaxException
    {
        /*
         * detected used caracter encoding
         */
	// Initalize the nsDetector() ;
	int lang = nsPSMDetector.UNIMOZER ;
	nsDetector det = new nsDetector(lang) ;

	// Set an observer...
	// The Notify() will be called when a matching charset is found.

	det.Init(new nsICharsetDetectionObserver()
        {
		public void Notify(String charset)
                {
		    HtmlCharsetDetector.found = true ;
		    //System.out.println("CHARSET = " + charset);
		}
    	});

        File f = new File(filename);

	URL url = f.toURI().toURL();
	BufferedInputStream imp = new BufferedInputStream(url.openStream());

	byte[] buf = new byte[1024] ;
	int len;
	boolean done = false ;
	boolean isAscii = true ;

	while( (len=imp.read(buf,0,buf.length)) != -1)
        {

		// Check if the stream is only ascii.
		if (isAscii)
		    isAscii = det.isAscii(buf,len);

		// DoIt if non-ascii and not done yet.
		if (!isAscii && !done)
 		    done = det.DoIt(buf,len, false);
	}
	det.DataEnd();

        boolean found = false;
        String encoding = new String(Unimozer.FILE_ENCODING);

	if (isAscii)
        {
	   //System.out.println("CHARSET = ASCII");
           encoding="US-ASCII";
	   found = true ;
	}

	if (!found)
        {
	   String prob[] = det.getProbableCharsets() ;
	   //for(int i=0; i<prob.length; i++)
           //{
	   //	System.out.println("Probable Charset = " + prob[i]);
	   //}
           if(prob.length>0)
           {
                encoding=prob[0];
           }
           else
           {
                encoding=defaultEncoding;
           }
	}

        loadFromFileInputStream(new FileInputStream(filename),encoding);
    }

    public MyClass(FileInputStream fis, String encoding) throws FileNotFoundException, ParseException, IOException
    {
        loadFromFileInputStream(fis,encoding);
    }

    private void loadFromFileInputStream(FileInputStream fis, String encoding) throws FileNotFoundException, ParseException, IOException
    {
        StringBuffer buffer = new StringBuffer();
        Reader in = null;
        try
        {
            InputStreamReader isr = new InputStreamReader(fis,encoding);
            in = new BufferedReader(isr);
            int ch;
            while ((ch = in.read()) > -1)
            {
                buffer.append((char)ch);
            }

            content = StringList.explode(buffer.toString(),"\n");
            cu = JavaParser.parse(new ByteArrayInputStream(getContent().getText().getBytes()));
        }
        finally
        {
            in.close();
        }

        inspect();

    }

    public String loadFromString(String code)
    {
/*
        try
        {
            com.sun.tools.javac.util.Context context = new com.sun.tools.javac.util.Context();
            context.put(JavaFileManager.class, ToolProvider.getSystemJavaCompiler().getStandardFileManager(null,null,null));
            com.sun.tools.javac.parser.Scanner.Factory scannerFactory = com.sun.tools.javac.parser.Scanner.Factory.instance(context);
            com.sun.tools.javac.parser.Lexer lexer = scannerFactory.newScanner(code);
            com.sun.tools.javac.parser.Parser.Factory parserFactory = com.sun.tools.javac.parser.Parser.Factory.instance(context);
            com.sun.tools.javac.parser.Parser parser = parserFactory.newParser(lexer, true, false);
            
            System.err.println(parser.compilationUnit().getTree().toString());

            //System.err.println(parser.compilationUnit().toString());
            System.out.println(parser.compilationUnit().getTree().toString());
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        catch (Error ex)
        {
            ex.printStackTrace();
        }
*/
        setContent(StringList.explode(code, "\n"));
        //System.err.println("--- code is ---");
        //System.err.println(code);
        //System.err.println("--- content is ---");
        //System.err.println(content.getText());

        boolean OK = false;
        String ret = NO_SYNTAX_ERRORS;
        try
        {
            cu = JavaParser.parse(new ByteArrayInputStream(code.getBytes()));
            OK = true;
        }
        catch (ParseException ex)
        {
            ret = ex.getMessage();
        }
        catch (Error ex)
        {
            ret = ex.getMessage();
        }
        inspect();
        return ret;

    }

    public void update(Element ele, String name, int modifiers, String extendsClass)
    {
        ClassChanger cnc = new ClassChanger((ClassOrInterfaceDeclaration) ele.getNode(), name, modifiers, extendsClass);
        cnc.visit(cu, null);
        inspect();
    }

    public void update(Element ele, String fieldType, String fieldName, int modifier)
    {
        FieldChanger fnc = new FieldChanger((FieldDeclaration) ele.getNode(), fieldType, fieldName, modifier);
        fnc.visit(cu, null);
        inspect();
    }

    void update(Element ele, String methodType, String methodName, int modifier, Vector<Vector<String>> params)
    {
        MethodChanger mnc = new MethodChanger((MethodDeclaration) ele.getNode(), methodType, methodName, modifier, params);
        mnc.visit(cu, null);
        inspect();
    }

    void update(Element ele, int modifier, Vector<Vector<String>> params)
    {
        ConstructorChanger cnc = new ConstructorChanger((ConstructorDeclaration) ele.getNode(), modifier, params);
        cnc.visit(cu, null);
        inspect();
    }

    public ClassOrInterfaceDeclaration getNode()
    {
        if(classes.size()>0)
        {
            return (ClassOrInterfaceDeclaration) classes.get(0).getNode();
        }
        else return null;
    }

    public int getModifiers()
    {
        if(classes.size()>0)
        {
            return ((ClassOrInterfaceDeclaration) classes.get(0).getNode()).getModifiers();
        }
        else return 0;
    }

    public String getExtendsClass()
    {
        ClassVisitor cv = new ClassVisitor();
        cv.visit(cu,null);
        return cv.getExtendsClass();
    }

    private String insert(String what, String s, int start)
    { 
        return s.substring(0,start-1)+what+s.substring(start-1,s.length()); 
    }

    public String getJavaCode()
    {
        return cu.toString();
    }

    public String getJavaCodeCommentless()
    {
        MyDumpVisitor visitor = new MyDumpVisitor();
        cu.accept(visitor, null);
        return visitor.getSource();
    }

    public String getName()
    {
        ClassVisitor cv = new ClassVisitor();
        cv.visit(cu,null);
        return cv.getName();
    }

    public StringList getUsesWho()
    {
        UsageVisitor cv = new UsageVisitor();
        cv.visit(cu,null);
        return cv.getUesedClasses();
    }

    public String getShortName()
    {
        return ((ClassOrInterfaceDeclaration) classes.get(0).getNode()).getName();
    }

    void addField(String fieldType, String fieldName, int modifier)
    {
        FieldDeclaration fd = ASTHelper.createFieldDeclaration(modifier,new ClassOrInterfaceType(fieldType),fieldName);
        TypeDeclaration thisClassType = cu.getTypes().get(0);
        ASTHelper.addMember(thisClassType, fd);
        inspect();
    }

    MethodDeclaration addMethod(String methodType, String methodName, int modifier, Vector<Vector<String>> params)
    {
        // add the method
        MethodDeclaration md = new MethodDeclaration(modifier, new ClassOrInterfaceType(methodType), methodName);
        TypeDeclaration thisClassType = cu.getTypes().get(0);
        ASTHelper.addMember(thisClassType, md);
        // add the parameters
        for(Vector<String> param : params)
        {
            Parameter pd = ASTHelper.createParameter(new ClassOrInterfaceType((String) param.get(0)), (String) param.get(1));
            //pd.setVarArgs(true);
            ASTHelper.addParameter(md,pd);
        }
        // add a body to the method
        BlockStmt block = new BlockStmt();
        md.setBody(block);

        inspect();
        return md;
    }

    void addConstructor(int modifier, Vector<Vector<String>> params)
    {
        // add the method
        ConstructorDeclaration cd = new ConstructorDeclaration(modifier, getShortName());
        TypeDeclaration thisClassType = cu.getTypes().get(0);
        ASTHelper.addMember(thisClassType, cd);
        // add the parameters
        for(Vector<String> param : params)
        {
            Parameter pd = ASTHelper.createParameter(new ClassOrInterfaceType((String) param.get(0)), (String) param.get(1));
            //pd.setVarArgs(true);
            ASTHelper.addParameter(cd, pd);
        } 
        // add a body to the method
        cd.setBlock(new BlockStmt());

        inspect();
    }


    public String getFullSignatureBySignature(String sign)
    {
        String ret = "";
        for(Element ele : methods)
        {
            if(ele.getSignature().equals(sign)) ret=ele.getShortName();
        }
        if(ret.equals("") && extendsMyClass!=null) ret=extendsMyClass.getFullSignatureBySignature(sign);
        return ret;
    }

    public String getCompleteSignatureBySignature(String sign)
    {
        String ret = "";
        //System.out.println("Looking for: "+sign);
        for(Element ele : methods)
        {
            //System.out.println("Having: "+ele.getSignature());
            if(ele.getSignature().equals(sign)) ret=ele.getName();
        }
        if(ret.equals("") && extendsMyClass!=null) ret=extendsMyClass.getCompleteSignatureBySignature(sign);
        return ret;
    }

    public String getSignatureByFullSignature(String sign)
    {
        String ret = "";
        for(Element ele : methods)
        {
            if(ele.getShortName().equals(sign)) ret=ele.getSignature();
        }
        if(ret.equals("") && extendsMyClass!=null) ret=extendsMyClass.getSignatureByFullSignature(sign);
        return ret;
    }

    public LinkedHashMap<String,String> getInputsBySignature(String sign)
    {
        LinkedHashMap<String,String> ret = new LinkedHashMap<String,String>();
        //System.out.println("Looking for: "+sign);
        for(Element ele : methods)
        {
            //System.out.println("Having: "+ele.getSignature());
            if(ele.getSignature().equals(sign)) ret=ele.getParams();
        }
        if(ret.size()==0 && extendsMyClass!=null) ret=extendsMyClass.getInputsBySignature(sign);
        return ret;
    }

    public String getJavaDocBySignature(String sign)
    {
        String ret = "";
        //System.out.println("Looking for: "+sign);
        for(Element ele : methods)
        {
            //System.out.println("Having: "+ele.getSignature());
            if(ele.getSignature().equals(sign)) ret=ele.getJavaDoc();
            if(ret==null) ret="";
        }
        if(ret.length()==0 && extendsMyClass!=null) ret=extendsMyClass.getJavaDocBySignature(sign);
        return ret;
    }

    private void deselectAll()
    {
        for(Element ele : classes) { ele.setSelected(false); }
        for(Element ele : fields) { ele.setSelected(false); }
        for(Element ele : methods) { ele.setSelected(false); }
    }

    public Element getSelected()
    {
        Element sel = null;
        for(Element ele : classes) { if(ele.isSelected()) sel=ele; }
        for(Element ele : fields) { if(ele.isSelected()) sel=ele; }
        for(Element ele : methods) { if(ele.isSelected()) sel=ele; }
        return sel;
    }

    public void inspect()
    {
        /*
        if(getSelected()!=null)
        {
            getSelected().getName();

            StructorizerVisitor sv = new StructorizerVisitor(getSelected().getName());
            sv.visit(cu,null);


            // create editor
            lu.fisch.structorizer.gui.Mainform form;
            form=new lu.fisch.structorizer.gui.Mainform();

            // change the default closing behaviour
            form.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            // affect the new diagram to the editor
            form.diagram.root=sv.root;
            // redraw the diagram
            form.diagram.redraw();
            form.setVisible(true);
        }
        */

        // get the old selected element
        String selectedSignature = null;
        if(getSelected()!=null) selectedSignature=getSelected().getName();

        // class
        ClassVisitor cv = new ClassVisitor();
        cv.visit(cu,null);
        classes=cv.getElements();
        // fields
        FieldVisitor fv = new FieldVisitor();
        fv.visit(cu,null);
        fields=fv.getElements();
        // methods
        MethodVisitor mv = new MethodVisitor();
        mv.visit(cu,getContent());
        methods=mv.getElements();
        //constructors=mv.getConstructors();
        setCompiled(false);

        // reselect the element that has been updated
        // works only if the signature of the element has not been changed!
        for(Element ele : classes) { ele.setUML(isUML); if(ele.getName().equals(selectedSignature)) ele.setSelected(true); }
        for(Element ele : fields)  { ele.setUML(isUML); if(ele.getName().equals(selectedSignature)) ele.setSelected(true); }
        for(Element ele : methods) { ele.setUML(isUML); if(ele.getName().equals(selectedSignature)) ele.setSelected(true); }

        updateNSD();
    }

    public void draw(Graphics graphics)
    {
        Graphics2D g = (Graphics2D) graphics;
        Color drawColor = new Color(255,245,235);
        if(selected==true)
        {
            drawColor = Color.YELLOW;
        }
        else if(isCompiled()==true)
        {
            drawColor = new Color(235,255,235);
        }


        // inspect the class

        // dertermine ervery values
        int totalHeight = 0;
        int maxWidth = 0;
        int classesHeight = 0*PAD;
        int fieldsHeight = 0*PAD;
        int methodsHeight = 0*PAD;

        for(Element ele : classes)
        {
            //g.setFont(new Font(g.getFont().getFontName(),Font.BOLD,g.getFont().getSize()));
            int h = (int) g.getFont().getStringBounds(ele.getPrintName(), g.getFontRenderContext()).getHeight()+PAD;
            int w = (int) g.getFont().getStringBounds(ele.getPrintName(), g.getFontRenderContext()).getWidth()+Element.ICONSIZE;
            //g.setFont(new Font(g.getFont().getFontName(),0,g.getFont().getSize()));

            ele.setHeight(h);
            ele.setPosition(new Point(position.x,position.y+totalHeight));
            if (w>maxWidth) maxWidth=w;
            classesHeight+=h;
            totalHeight+=h;
        }
        totalHeight+=0*PAD;
        for(Element ele : fields)
        {
            int h = (int) g.getFont().getStringBounds(ele.getPrintName(), g.getFontRenderContext()).getHeight()+PAD;
            int w = (int) g.getFont().getStringBounds(ele.getPrintName(), g.getFontRenderContext()).getWidth()+Element.ICONSIZE;
            ele.setHeight(h);
            ele.setPosition(new Point(position.x,position.y+totalHeight));
            if (w>maxWidth) maxWidth=w;
            fieldsHeight+=h;
            totalHeight+=h;
        }
        totalHeight+=0*PAD;
        if(fieldsHeight==0) totalHeight+= fieldsHeight = PAD;
        for(Element ele : methods)
        {
            int h = (int) g.getFont().getStringBounds(ele.getPrintName(), g.getFontRenderContext()).getHeight()+PAD;
            int w = (int) g.getFont().getStringBounds(ele.getPrintName(), g.getFontRenderContext()).getWidth()+Element.ICONSIZE;
            ele.setHeight(h);
            ele.setPosition(new Point(position.x,position.y+totalHeight));
            if (w>maxWidth) maxWidth=w;
            methodsHeight+=h;
            totalHeight+=h;
        }
        totalHeight+=0;
        if(methodsHeight==0) totalHeight+= methodsHeight = PAD;

        this.width=maxWidth+2*PAD;
        this.height=totalHeight;

        // set widths
        for(Element ele : classes) { ele.setWidth(this.getWidth()); }
        for(Element ele : fields) { ele.setWidth(this.getWidth()); }
        for(Element ele : methods) { ele.setWidth(this.getWidth()); }

        // draw background
        g.setColor(drawColor);
        g.fillRect(position.x,position.y,this.getWidth(), this.getHeight());

        g.setColor(drawColor);
        for(Element ele : classes) { ele.draw(g); }
        for(Element ele : fields) { ele.draw(g); }
        for(Element ele : methods) { ele.draw(g); }

        // draw boxes
        g.setColor(Color.BLACK);
        g.drawRect(position.x,position.y,this.getWidth(),classesHeight);
        g.drawRect(position.x,position.y+classesHeight,this.getWidth(),fieldsHeight);
        g.drawRect(position.x,position.y+classesHeight+fieldsHeight,this.getWidth(),methodsHeight);
        if(isCompiled()==true)
        {
            g.drawRect(position.x-2,position.y-2,this.getWidth()+4,this.getHeight()+4);
        }
    }

    public boolean isInside(Point pt)
    {
        return (position.x<=pt.x && pt.x<=position.x+getWidth() &&
                position.y<=pt.y && pt.y<=position.y+getHeight());
    }

    public Point getRelative(Point pt)
    {
        if (isInside(pt))
        {
            return new Point(pt.x-position.x,
                             pt.y-position.y);
        }
        else return new Point(0,0);
    }

    /**
     * @return the position
     */
    public Point getPosition()
    {
        return position;
    }

    /**
     * @param position the position to set
     */
    public void setPosition(Point position)
    {
        this.position = position;
    }

    /**
     * @return the selected
     */
    public boolean isSelected()
    {
        return selected;
    }

    /**
     * @param selected the selected to set
     */
    public void deselect()
    {
        deselectAll();
        this.selected = false;
    }

    public void select(Point pt)
    {
        deselectAll();
        this.selected = true;
        if(pt!=null)
        {
            for(Element ele : classes) { ele.setSelected(ele.isInside(pt)); }
            for(Element ele : fields) { ele.setSelected(ele.isInside(pt)); }
            for(Element ele : methods) { ele.setSelected(ele.isInside(pt)); }
        }
    }

    public Element getHover(Point pt)
    {
        Element ret = null;
        if(pt!=null)
        {
            for(Element ele : classes) { if (ele.isInside(pt)) ret=ele; }
            for(Element ele : fields) { if (ele.isInside(pt)) ret=ele; }
            for(Element ele : methods) { if (ele.isInside(pt)) ret=ele; }
        }
        return ret;
    }



    public StringList getFieldTypes()
    {
        StringList sl = new StringList();

        for(Element ele : fields)
        {
            String type =((FieldDeclaration)ele.getNode()).getType().toString();
            //System.err.println(type);
            sl.addIfNew(Unimozer.getTypesOf(type));
        }

        return sl;
    }
 
    /**
     * @return the width
     */
    public int getWidth()
    {
        return width;
    }

    /**
     * @return the height
     */
    public int getHeight()
    {
        return height;
    }

    /**
     * @return the compiled
     */
    public boolean isCompiled()
    {
        return compiled;
    }

    /**
     * @return the extendsMyClass
     */
    public MyClass getExtendsMyClass()
    {
        return extendsMyClass;
    }

    /**
     * @param extendsMyClass the extendsMyClass to set
     */
    public void setExtendsMyClass(MyClass extendsMyClass)
    {
        this.extendsMyClass = extendsMyClass;
    }

    /**
     * @param compiled the compiled to set
     */
    public void setCompiled(boolean compiled)
    {
        this.compiled = compiled;
    }

    /**
     * @param extendsClass the extendsClass to set
     */
    public void setExtendsClass(String extendsClass)
    {
        this.extendsClass = extendsClass;
    }

    /**
     * @return the usesMyClass
     */
    public Vector<MyClass> getUsesMyClass()
    {
        return usesMyClass;
    }

    /**
     * @param usesMyClass the usesMyClass to set
     */
    public void setUsesMyClass(Vector<MyClass> usesMyClass)
    {
        this.usesMyClass = usesMyClass;
    }

    /**
     * @return the connector
     */
    public StringList getContent()
    {
        return content;
    }

    /**
     * @param content the content to set
     */
    public void setContent(StringList content)
    {
        this.content = content;
    }

    /*public void updateNSD(lu.fisch.structorizer.gui.Mainform form)
    {
        if(getSelected()!=null && form!=null)
        {
            getSelected().getName();

            StructorizerVisitor sv = new StructorizerVisitor(getSelected().getName());
            sv.visit(cu,null);

            // affect the new diagram to the editor
            form.diagram.root=sv.root;
            // redraw the diagram
            form.diagram.redraw();
            form.setVisible(true);
        }
    }*/

    public static Root setErrorNSD()
    {
        Root root = new Root();
        root.setText("---[ please select a method ]---");
        return root;
    }

    void updateNSD(lu.fisch.structorizer.gui.Diagram nsd)
    {
        this.nsd=nsd;
        if(nsd!=null)
        {
            boolean ERROR = false;
            if(getSelected()!=null)
            {
                getSelected().getName();

                if ((getSelected().getType()==Element.METHOD) || (getSelected().getType()==Element.CONSTRUCTOR))
                {
                    StructorizerVisitor sv = new StructorizerVisitor(getSelected().getName());
                    sv.visit(cu,null);

                    // affect the new diagram to the editor
                    nsd.root=sv.root;
                    // redraw the diagram
                    //nsd.redraw();
                    // redraw the parent
                    nsd.getParent().getParent().repaint();
                }
                else ERROR=true;
            }
            else ERROR=true;

            if(ERROR)
            {
                nsd.root=setErrorNSD();
                nsd.getParent().getParent().repaint();
            }
        }
    }

    private void updateNSD()
    {
        updateNSD(nsd);
    }

    /**
     * @return the isUML
     */
    public boolean isUML()
    {
        return isUML;
    }

    /**
     * @param isUML the isUML to set
     */
    public void setUML(boolean isUML)
    {
        this.isUML = isUML;
        for(Element ele : classes)
        {
            ele.setUML(isUML);
        }
        for(Element ele : fields)
        {
            ele.setUML(isUML);
        }
        for(Element ele : methods)
        {
            ele.setUML(isUML);
        }
    }


    /**
     * @return the constructors
     */
    /*
    public Vector<Element> getConstructors()
    {
        return constructors;
    }
    */
}
