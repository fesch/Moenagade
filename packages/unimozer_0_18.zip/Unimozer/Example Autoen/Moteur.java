public class Moteur
{

    public void makeSound() 
    {
        System.out.println("Brum, brum ...");
    }

}
