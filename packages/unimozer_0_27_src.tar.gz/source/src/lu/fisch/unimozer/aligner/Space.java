package lu.fisch.unimozer.aligner;

/**
 * Write a description of class "Intervall" here.
 * 
 * @author     robertfisch
 * @version    08/05/2012 15:02:56
 */

import java.awt.Point;
import java.awt.Dimension;

public interface Space
{
	public int getX();
	public int getY();

	public int getWidth();
	public int getHeight();
}