public class Voiture
{

    int nombreDePneu = 4;

    int nombreDePortes = 5;

    int puissance = 140;

    public Moteur moteur = new Moteur();

    public Voiture() 
    {
    }


    public Voiture(int puisaance) 
    {
        this.puissance = puissance;
    }


    public void dessiner() 
    {
        System.out.println("      /-------\\");
        System.out.println("/----/         \\---\\");
        System.out.println("|                  <");
        System.out.println("\\-----O-------O----/");
    }

}
