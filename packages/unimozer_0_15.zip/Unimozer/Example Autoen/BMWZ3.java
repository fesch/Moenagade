public class BMWZ3 extends Voiture
{

    public void dessiner() 
    {
        System.out.println(" _______");
        System.out.println("/       \\---<");
        System.out.println("\\-O----O----/");
    }

}
