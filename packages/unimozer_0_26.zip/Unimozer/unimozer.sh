#!/bin/sh
# Version 1.0.1

# Todo:
# The wrapper should
# 1. use an absolute path to Unimozer.jar
# 2. locate JDK: 
#   * first check if $JAVA_HOME is set, if not
#   * try to follow symbol links starting from /usr/bin/javac to find the default JDK
#   * try some usual places to find a suitable JDK
#   * try 'locate' to find lib/tools.jar
#   * if all fails promt a message 
#     "Can not find Java Development Kit JDK. Please 
#        install JDK SE version >= 1.6 and/or set $JAVA_HOME to it" 

java -cp "Unimozer.jar:$(locate /lib/tools.jar|sort|tail -n 1)" lu.fisch.unimozer.Main "$@"
