/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moenagade.base;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.KeyEventDispatcher;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

/**
 *
 * @author robert.fisch
 */
public abstract class Entity implements KeyListener {
    
    private String imageFile = "";
    private Image image = null;
    
    private Point location = new Point(0,0);
    
    public Entity() {
        loadImage("entity.png");
    }
    
    public void loadImage(String filename)
    {
        imageFile = "/moenagade/images/"+filename;
        // load image
        try 
        {
            image = ImageIO.read(this.getClass().getResource(imageFile));
        } 
        catch (IOException ex) 
        {
            ex.printStackTrace();
        }
    }

    public void draw(Graphics g)
    {
        if(image!=null)
        {
            g.drawImage(image, location.x, location.y, null);
        }
    }

    @Override
    public void keyTyped(KeyEvent ke) {
        
    }

    @Override
    public void keyPressed(KeyEvent ke) {
        
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        
    }
    
    public void moveLeft(int pixels)
    {
        location.x-=pixels;
    }
    
    public void moveRight(int pixels)
    {
        location.x+=pixels;
    }

    public void moveUp(int pixels)
    {
        location.y-=pixels;
    }
    
    public void moveDown(int pixels)
    {
        location.y+=pixels;
    }

    public void setX(int x)
    {
        location.x=x;
    }
    
    public void setY(int y)
    {
        location.y=y;
    }
}