package moenagade;

import java.awt.event.KeyEvent;
import moenagade.*;
import moenagade.base.*;
import moenagade.worlds.*;
import moenagade.entities.*;

public class Project extends moenagade.base.MainFrame
{
    /*
     * Code for when created
     */
    protected void onCreate()
    {
        setWindowSize(750, 450);
        setWorld(new Besch());
    }

    
    public static void main(String args[]) { java.awt.EventQueue.invokeLater(new Runnable() { public void run() { new Project().setVisible(true); } }); }
    
}