package moenagade.worlds;

import java.awt.event.KeyEvent;
import moenagade.*;
import moenagade.base.*;
import moenagade.worlds.*;
import moenagade.entities.*;

public class Besch extends moenagade.base.World
{
    /*
     * Code for when created
     */
    protected void onCreate()
    {
        loadImage("besch.png");
        addEntity(new Pol());
    }

}