package moenagade.entities;

import java.awt.event.KeyEvent;
import moenagade.*;
import moenagade.base.*;
import moenagade.worlds.*;
import moenagade.entities.*;

public class Pol extends moenagade.base.Entity
{
    /*
     * Code for when a key has been pressed
     */
    public void keyPressed(KeyEvent keyEvent)
    {
        if (keyEvent.getKeyCode() == 37)
        {
            loadImage("entityRet.png");
            moveLeft(10);
        }
        else if (keyEvent.getKeyCode() == 38)
        {
            moveUp(10);
        }
        else if (keyEvent.getKeyCode() == 39)
        {
            loadImage("entity.png");
            moveRight(10);
        }
        else if (keyEvent.getKeyCode() == 40)
        {
            moveDown(10);
        }
    }

}